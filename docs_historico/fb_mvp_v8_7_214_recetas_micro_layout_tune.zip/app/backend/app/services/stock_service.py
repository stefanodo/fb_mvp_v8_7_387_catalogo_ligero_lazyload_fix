from datetime import datetime
from typing import Optional

from fastapi.responses import JSONResponse

from app.core import db
from app.services.units_service import to_base_qty, minmax_to_base


def create_stock_movement(center_id: int, warehouse_id: int, item_id: int, movement_type: str, qty_value: float, qty_unit: str, note: str = ''):
    if float(qty_value or 0) <= 0:
        return JSONResponse({'ok': False, 'error': 'Cantidad debe ser > 0'}, status_code=400)

    conn = db()
    cur = conn.cursor()
    wh = cur.execute('SELECT center_id FROM warehouses WHERE id=?', (warehouse_id,)).fetchone()
    if not wh:
        conn.close()
        return JSONResponse({'ok': False, 'error': 'Almacén inválido'}, status_code=400)
    if int(wh['center_id'] or 0) != int(center_id or 0):
        conn.close()
        return JSONResponse({'ok': False, 'error': 'El almacén no pertenece al local seleccionado'}, status_code=400)
    item = cur.execute('SELECT unit FROM items WHERE id=?', (item_id,)).fetchone()
    if not item:
        conn.close()
        return JSONResponse({'ok': False, 'error': 'Artículo inválido'}, status_code=400)

    base_unit = item['unit']
    qty_base = to_base_qty(float(qty_value or 0.0), qty_unit, base_unit)
    mt = (movement_type or '').upper().strip()
    if mt not in {'ENTRADA', 'SALIDA', 'IN', 'OUT'}:
        conn.close()
        return JSONResponse({'ok': False, 'error': 'Tipo de movimiento inválido'}, status_code=400)

    cur.execute(
        """INSERT INTO movements(center_id,warehouse_id,item_id,movement_type,qty,unit,created_at,note)
           VALUES(?,?,?,?,?,?,?,?)""",
        (center_id, warehouse_id, item_id, mt, qty_base, base_unit,
         datetime.now().isoformat(timespec='seconds'), note)
    )
    conn.commit()
    conn.close()
    return {'ok': True, 'message': 'Movimiento guardado'}


def save_item_minmax(item_id: int, min_qty: float, max_qty: float, min_unit: str, max_unit: str, center_id: Optional[str] = '', warehouse_id: Optional[str] = ''):
    conn = db()
    cur = conn.cursor()
    item = cur.execute('SELECT unit FROM items WHERE id=?', (item_id,)).fetchone()
    if not item:
        conn.close()
        raise LookupError('Artículo inválido')
    base_unit = item['unit']
    min_base = minmax_to_base(float(min_qty or 0.0), min_unit, base_unit)
    max_base = minmax_to_base(float(max_qty or 0.0), max_unit, base_unit)
    if min_base < 0 or max_base < 0 or max_base < min_base:
        conn.close()
        raise ValueError('Rango inválido')

    if str(center_id).isdigit() and str(warehouse_id).isdigit():
        cur.execute(
            """INSERT INTO item_location_prefs(center_id,warehouse_id,item_id,min_qty,max_qty)
               VALUES(?,?,?,?,?)
               ON CONFLICT(center_id,warehouse_id,item_id)
               DO UPDATE SET min_qty=excluded.min_qty,max_qty=excluded.max_qty""",
            (int(center_id), int(warehouse_id), item_id, min_base, max_base)
        )
    else:
        cur.execute('UPDATE items SET min_qty=?, max_qty=? WHERE id=?', (min_base, max_base, item_id))
    conn.commit()
    conn.close()
    return {'ok': True, 'min_base': min_base, 'max_base': max_base}
