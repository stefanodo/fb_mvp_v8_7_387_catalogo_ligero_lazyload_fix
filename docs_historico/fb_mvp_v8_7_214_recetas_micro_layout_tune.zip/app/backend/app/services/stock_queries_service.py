from app.core import db


def stock_page_url(*, center_id:int=0, ok:str|None=None, err:str|None=None, anchor:str='stock') -> str:
    params = [f"page=stock", f"center_id={int(center_id or 0)}"]
    if ok:
        params.append(f"{ok}=1")
    if err:
        params.append(f"err={err}")
    return f"/?{'&'.join(params)}#{anchor}"


def resolve_item_id_strict(item_id, item_query:str=''):
    conn = db()
    cur = conn.cursor()
    row = None
    if str(item_id or '').isdigit():
        row = cur.execute('SELECT id FROM items WHERE id=?', (int(item_id),)).fetchone()
    if not row and (item_query or '').strip():
        row = cur.execute('SELECT id FROM items WHERE lower(trim(name))=lower(trim(?)) LIMIT 1', ((item_query or '').strip(),)).fetchone()
    conn.close()
    return int(row['id']) if row else None
