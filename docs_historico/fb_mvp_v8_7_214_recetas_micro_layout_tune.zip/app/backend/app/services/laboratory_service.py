from app.core import _parse_float, normalize_price_to_base, suggest_item_waste_pct, upper_name, normalize_stock_area


def normalize_item_payload(name: str, unit: str, current_price: str = "0", current_price_unit: str = "", waste_default_pct: str = "", stock_area: str = "") -> dict:
    u = (unit or "").strip()
    cpu = (current_price_unit or "").strip() or u
    price = normalize_price_to_base(_parse_float(current_price, 0.0), u, cpu)
    item_name = upper_name(name)
    waste_txt = (waste_default_pct or "").strip()
    waste_def = (_parse_float(waste_txt, suggest_item_waste_pct(item_name, u))
                 if waste_txt != "" else suggest_item_waste_pct(item_name, u))
    return {
        "name": item_name,
        "unit": u,
        "current_price": float(price or 0),
        "current_price_unit": cpu,
        "waste_default_pct": float(waste_def or 0),
        "stock_area": normalize_stock_area(stock_area),
    }


def normalize_supplier_payload(name: str, phone: str = "", email: str = "") -> dict:
    return {
        "name": (name or "").strip(),
        "phone": (phone or "").strip(),
        "email": (email or "").strip(),
    }
