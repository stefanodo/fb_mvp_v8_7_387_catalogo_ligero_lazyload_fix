from urllib.parse import urlencode


def normalize_order_note(note: str = "") -> str:
    return (note or "").strip()


def normalize_supplier_name(name: str = "") -> str:
    return (name or "").strip()


def order_page_url(center_id: int | None = None, oid: int | None = None, anchor: str = "orderDetailPanel", **params) -> str:
    query = {"page": "pedidos"}
    if center_id:
        query["center_id"] = int(center_id)
    if oid:
        query["oid"] = int(oid)
    for key, value in params.items():
        if value is None or value == "":
            continue
        query[key] = value
    url = f"/?{urlencode(query)}"
    if anchor:
        url += f"#{anchor}"
    return url


def parse_optional_int(raw_value) -> int | None:
    try:
        value = str(raw_value or "").strip()
        return int(value) if value else None
    except Exception:
        return None
