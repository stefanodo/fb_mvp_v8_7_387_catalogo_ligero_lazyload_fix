from app.core import production_with_lines


def get_production_detail(cur, production_id):
    if not str(production_id or '').isdigit():
        return None
    return production_with_lines(cur, int(production_id))


def list_productions(cur, center_id=None, show_archived: bool = False, production_group_filter: str = ""):
    status_clause = "p.status='ARCHIVED'" if show_archived else "COALESCE(p.status,'') <> 'ARCHIVED'"
    group_filter = (production_group_filter or '').strip()
    group_clause = " AND COALESCE(p.production_group,'Otros')=?" if group_filter else ""
    extra = [group_filter] if group_filter else []
    if center_id:
        rows = cur.execute(
            f"""SELECT p.id,p.center_id,p.warehouse_id,p.status,p.created_at,p.note,
                       COALESCE(p.production_group,'Otros') production_group,
                       c.name center_name,w.name warehouse_name
                  FROM productions p
                  JOIN centers c ON c.id=p.center_id
                  JOIN warehouses w ON w.id=p.warehouse_id
                 WHERE p.center_id=? AND {status_clause}{group_clause}
                 ORDER BY p.id DESC""",
            tuple([int(center_id)] + extra),
        ).fetchall()
    else:
        rows = cur.execute(
            f"""SELECT p.id,p.center_id,p.warehouse_id,p.status,p.created_at,p.note,
                       COALESCE(p.production_group,'Otros') production_group,
                       c.name center_name,w.name warehouse_name
                  FROM productions p
                  JOIN centers c ON c.id=p.center_id
                  JOIN warehouses w ON w.id=p.warehouse_id
                 WHERE {status_clause}{group_clause}
                 ORDER BY p.id DESC""",
            tuple(extra),
        ).fetchall()
    return [{k: r[k] for k in r.keys()} for r in rows]
