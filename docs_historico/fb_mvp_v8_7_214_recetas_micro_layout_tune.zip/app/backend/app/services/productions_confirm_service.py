from datetime import datetime


def update_production_note(cur, production_id: int, note: str = "") -> dict | None:
    p = cur.execute("SELECT status,center_id FROM productions WHERE id=?", (production_id,)).fetchone()
    if not p or p["status"] != "DRAFT":
        return None
    cur.execute("UPDATE productions SET note=? WHERE id=?", (((note or "").strip()), production_id))
    return {"center_id": p["center_id"]}


def delete_draft_production(cur, production_id: int) -> dict | None:
    p = cur.execute("SELECT status,center_id FROM productions WHERE id=?", (production_id,)).fetchone()
    if not p or p["status"] != "DRAFT":
        return None
    cur.execute("DELETE FROM production_lines WHERE production_id=?", (production_id,))
    cur.execute("DELETE FROM productions WHERE id=?", (production_id,))
    return {"center_id": p["center_id"]}


def reopen_production(cur, production_id: int) -> dict | None:
    p = cur.execute("SELECT status,center_id FROM productions WHERE id=?", (production_id,)).fetchone()
    if not p:
        return None
    # HOTFIX auditoría: no reabrir confirmadas mientras no exista reversión contable segura.
    # Reabrir hoy permite volver a confirmar y duplicar movimientos de stock.
    if p["status"] == "CONFIRMED":
        return None
    return {"center_id": p["center_id"]}


def confirm_production(cur, production_id: int) -> dict | None:
    p = cur.execute("SELECT * FROM productions WHERE id=?", (production_id,)).fetchone()
    if not p or p["status"] != "DRAFT":
        return None
    lines = cur.execute("SELECT * FROM production_lines WHERE production_id=? ORDER BY id", (production_id,)).fetchall()
    if not lines:
        return None
    now = datetime.utcnow().isoformat()
    note = (p["note"] or "").strip()
    base_note = f"PRODUCCIÓN #{production_id}" + (f" · {note}" if note else "")
    for ln in lines:
        mv_type = "SALIDA" if ln["line_type"] == "OUT" else "ENTRADA"
        item = cur.execute("SELECT unit FROM items WHERE id=?", (ln["item_id"],)).fetchone()
        unit = (item["unit"] if item else "") or "ud"
        cur.execute(
            """INSERT INTO movements(center_id,warehouse_id,item_id,movement_type,qty,unit,created_at,note)
               VALUES(?,?,?,?,?,?,?,?)""",
            (p["center_id"], p["warehouse_id"], ln["item_id"], mv_type, float(ln["qty_base"]), unit, now, base_note),
        )
    cur.execute("UPDATE productions SET status='CONFIRMED' WHERE id=?", (production_id,))
    return {"center_id": p["center_id"], "line_count": len(lines)}


def archive_production(cur, production_id: int) -> dict | None:
    p = cur.execute("SELECT status,center_id FROM productions WHERE id=?", (production_id,)).fetchone()
    if not p or p["status"] != "CONFIRMED":
        return None
    cur.execute("UPDATE productions SET status='ARCHIVED' WHERE id=?", (production_id,))
    return {"center_id": p["center_id"]}


def restore_archived_production(cur, production_id: int) -> dict | None:
    p = cur.execute("SELECT status,center_id FROM productions WHERE id=?", (production_id,)).fetchone()
    if not p or p["status"] != "ARCHIVED":
        return None
    cur.execute("UPDATE productions SET status='CONFIRMED' WHERE id=?", (production_id,))
    return {"center_id": p["center_id"]}
