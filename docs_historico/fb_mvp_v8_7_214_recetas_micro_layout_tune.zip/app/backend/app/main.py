# ==============================================================================
# F&B MVP · main.py — Punto de entrada limpio
# Versión modular v8.7.175
# Cada bloque funcional está en su propio router:
#   stock · recetas · producciones · pedidos · albaranes · laboratorio · admin
# El OCR engine está aislado en app/ocr/engine.py
# ==============================================================================
from fastapi import FastAPI, Request, Form
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.middleware.base import BaseHTTPMiddleware
from typing import Optional
import sqlite3
import re
import time

from app.core import (
    # DB y configuración
    db, init_db, ensure_columns, _retry_db_write, _is_db_locked_error,
    APP_DIR, UPLOADS_DIR, BUILD_ID,
    # Constantes de negocio
    CATEGORY_CODES, SUBCATEGORIES, ALLERGENS_UE,
    # Formato y utilidades
    human_qty, fmt_dt, status_label, fmt_num, fmt_price,
    display_price_from_base, preferred_price_unit, preferred_display_qty,
    _ocr_state_label, _parse_float, _cache_bust_token, _norm_text,
    # Datos del dashboard
    get_dashboard_data, recipe_visible_in_center,
    STOCK_AREAS, stock_area_label, normalize_stock_area,
    get_production_stocks,
    recipe_with_calc, production_with_lines, order_with_lines,
    _supplier_options_for_item, cleanup_receipt_photos,
    # Recetas
    next_recipe_code, _parse_scope,
    # Albaranes OCR display
    _ocr_postfix_product_cleanup, _ocr_lock_path,
    # Limpieza startup
    _clear_pending_receipts_runtime,
)

# --- Routers ---
from app.productions_panel import create_batch_productions
from app.services.productions_view_service import get_production_detail, list_productions
from app.services.productions_constants_service import production_groups, production_units
from app.routers import stock, recetas, producciones, pedidos, albaranes, laboratorio, admin, inventario

# ==============================================================================
# APP
# ==============================================================================

app = FastAPI(title=f"F&B MVP {BUILD_ID}")


class NoStoreMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        response = await call_next(request)
        try:
            path = request.url.path or ""
            ctype = (response.headers.get("content-type") or "").lower()
            if request.method == "GET" and (path == "/" or "text/html" in ctype):
                response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
                response.headers["Pragma"] = "no-cache"
                response.headers["Expires"] = "0"
        except Exception:
            pass
        return response


app.add_middleware(NoStoreMiddleware)

# --- Montar routers ---
app.include_router(stock.router)
app.include_router(recetas.router)
app.include_router(producciones.router)
app.include_router(pedidos.router)
app.include_router(albaranes.router)
app.include_router(laboratorio.router)
app.include_router(admin.router)
app.include_router(inventario.router)

# --- Archivos estáticos ---
app.mount("/static", StaticFiles(directory=str(APP_DIR / "static")), name="static")
app.mount("/uploads", StaticFiles(directory=str(UPLOADS_DIR)), name="uploads")

# --- Templates ---
templates = Jinja2Templates(directory=str(APP_DIR / "templates"))
templates.env.globals.update(
    human_qty=human_qty,
    fmt_dt=fmt_dt,
    status_label=status_label,
    fmt_num=fmt_num,
    fmt_price=fmt_price,
    display_price_from_base=display_price_from_base,
    preferred_price_unit=preferred_price_unit,
    ocr_state_label=_ocr_state_label,
)


def _normalize_search_text(value: str) -> str:
    return _norm_text(value or '').strip().lower()


def _jinja_search_test(value, pattern) -> bool:
    return _normalize_search_text(pattern) in _normalize_search_text(value)


templates.env.tests['search'] = _jinja_search_test


def _fmt_qty(value, decimals: int = 3):
    try:
        if value is None:
            return "0"
        v = float(value)
    except Exception:
        return str(value)
    if abs(v - round(v)) < 1e-9:
        return str(int(round(v)))
    return f"{v:.{decimals}f}".rstrip("0").rstrip(".")


templates.env.filters["fmt_qty"] = _fmt_qty


def _jinja_search(value, pattern):
    try:
        import unicodedata
        def _norm(v):
            txt = str(v or '').strip().lower()
            txt = unicodedata.normalize('NFKD', txt)
            return ''.join(ch for ch in txt if not unicodedata.combining(ch))
        v = _norm(value)
        p = _norm(pattern)
        if not p:
            return True
        return p in v
    except Exception:
        return False


templates.env.tests["search"] = _jinja_search


# ==============================================================================
# STARTUP
# ==============================================================================

@app.on_event("startup")
def startup():
    try:
        _clear_pending_receipts_runtime()
    except Exception as exc:
        print(f"STARTUP_CLEAR_PENDING_SKIP reason={exc}")
    last_exc = None
    for attempt in range(8):
        try:
            init_db()
            return
        except sqlite3.OperationalError as exc:
            last_exc = exc
            if not _is_db_locked_error(exc):
                raise
            print(f"STARTUP_DB_LOCKED attempt={attempt+1}/8")
            time.sleep(0.6 * (attempt + 1))
    print(f"STARTUP_DB_LOCKED_SKIP reason={last_exc}")




def _norm_warehouse_name(value: str) -> str:
    return (value or '').strip().lower().replace('á', 'a')


def _preferred_warehouse_names_for_raw_family(fam: str) -> set[str]:
    fam = (fam or '').strip().lower()
    if fam in {'verduras', 'carnes', 'pescados', 'lacteos_huevos', 'congelados'}:
        return {'camara'}
    if fam in {'secos', 'limpieza'}:
        return {'economato'}
    return set()


def _inventory_raw_family(name: str, stock_area: str = ""):
    n = (name or "").lower()
    area = normalize_stock_area(stock_area or "")
    meat = ["pollo","ternera","vacuno","cerdo","solomillo","costilla","hamburg","secreto","presa","carrillera","chuleta","entrecot","cordero","bacon","panceta","jamon","jamón","chorizo"]
    fish = ["lubina","merluza","atun","atún","salmon","salmón","bacalao","pescado","sepia","calamar","langost","gamba","pulpo","mejillon","mejillón","marisco","dorada","almeja","ostra","navaja","berberecho","chirla","vieira"]
    dairy = ["huevo","huevos","leche","nata","queso","mantequilla","yogur","yogurt","mozzarella","parmesano","cheddar"]
    veg = ["tomate","lechuga","cebolla","ceboll","pimiento","pepino","cilantro","jalape","espinaca","zanahoria","patata","papa","berenjena","calabacin","calabacín","aguacate","brocoli","brócoli","col","repollo","hierba","menta","albahaca","cebollino","seta","champi","ajo","perejil","lima","limon","limón"]
    if area == 'LIMPIEZA':
        return 'limpieza'
    if area == 'CONGELADOS':
        return 'congelados'
    if area == 'SECOS':
        return 'secos'
    if any(k in n for k in fish):
        return 'pescados'
    if any(k in n for k in meat):
        return 'carnes'
    if any(k in n for k in dairy):
        return 'lacteos_huevos'
    if any(k in n for k in veg):
        return 'verduras'
    if area == 'FRESCOS':
        return 'verduras'
    if area == 'SIN_CLASIFICACION':
        return 'otros'
    return 'otros'


def _inventory_production_family(prod_group: str, name: str = "", recipe_subcategory: str = "", recipe_category: str = ""):
    g = (prod_group or "").strip().lower()
    n = (name or "").strip().lower()
    rs = (recipe_subcategory or "").strip().lower()
    rc = (recipe_category or "").strip().lower()

    def map_family(v: str):
        v = (v or "").strip().lower()
        if not v or v == "sin definir":
            return ""
        if "salsa" in v or "demi" in v or "alioli" in v or "vinagreta" in v:
            return "salsas"
        if "frío" in v or "frio" in v or "ensalad" in v:
            return "frio"
        if "caliente" in v:
            return "caliente"
        if "guarn" in v or "arroz" in v or "patata" in v:
            return "guarniciones"
        if "postr" in v or "tarta" in v or "bizcocho" in v or "crema" in v:
            return "postres"
        if "otro" in v:
            return "otros"
        return ""

    # Excepción operativa: si el nombre o la categoría general dicen claramente que es salsa,
    # no debe caer en Caliente por una subcategoría heredada/conflictiva.
    sauce_hint = any(k in (n + ' ' + rc + ' ' + g) for k in ['salsa', 'demi', 'alioli', 'vinagreta'])
    if sauce_hint:
        return 'salsas'

    fam = map_family(rs) or map_family(rc) or map_family(g)
    if fam:
        return fam
    if 'pico de gallo' in n or 'guacamole' in n or 'ensalad' in n:
        return 'frio'
    if 'tarta' in n or 'bizcocho' in n or 'crema' in n:
        return 'postres'
    if 'arroz' in n or 'patata' in n:
        return 'guarniciones'
    return 'otros'


def _inventory_counts_map(session_id: int):
    if not session_id:
        return {}
    conn = db(); cur = conn.cursor()
    rows = cur.execute("SELECT * FROM inventory_counts WHERE session_id=? ORDER BY id", (int(session_id),)).fetchall()
    conn.close()
    out = {}
    for r in rows:
        d = {k: r[k] for k in r.keys()}
        key = f"{d.get('source_type') or 'raw'}:{int(d.get('item_id') or 0)}:{d.get('family_key') or ''}:{int(d.get('warehouse_id') or 0)}"
        out[key] = d
    return out




def _inventory_allowed_modes_for_warehouse_name(warehouse_name: str | None):
    n = (warehouse_name or '').strip().lower()
    if n in ('economato',):
        return {'limpieza', 'libres'}
    if n in ('cocina', 'camara', 'cámara'):
        return {'materias_primas', 'producciones', 'libres'}
    return {'materias_primas', 'producciones', 'limpieza', 'libres'}




def _default_warehouse_name_for_stock_area(stock_area: str) -> str | None:
    area = normalize_stock_area(stock_area or '')
    if area == 'LIMPIEZA':
        return 'economato'
    if area == 'SECOS':
        return 'economato'
    if area == 'FRESCOS':
        return 'cámara'
    if area == 'CONGELADOS':
        return 'cámara'
    return None

def _build_inventory_context(*, center_id, warehouses, stocks, production_stocks, request):
    inv_mode = (request.query_params.get('inv_mode') or 'materias_primas').strip().lower()
    if inv_mode not in {'materias_primas','producciones','limpieza','libres'}:
        inv_mode = 'materias_primas'
    inv_family = (request.query_params.get('inv_family') or ('verduras' if inv_mode=='materias_primas' else 'frio')).strip().lower()
    raw_valid = {'verduras','carnes','pescados','lacteos_huevos','secos','congelados','limpieza','otros'}
    prod_valid = {'frio','caliente','salsas','postres','guarniciones','otros'}
    if inv_mode=='materias_primas' and inv_family not in raw_valid: inv_family='verduras'
    if inv_mode=='producciones' and inv_family not in prod_valid: inv_family='frio'
    if inv_mode=='limpieza': inv_family='limpieza'
    if inv_mode=='libres': inv_family='libres'

    conn = db(); cur = conn.cursor()
    ensure_columns(cur)
    current_session = None
    sid_q = request.query_params.get('inv_session_id') or ''
    if str(sid_q).isdigit():
        row = cur.execute("SELECT * FROM inventory_sessions WHERE id=?", (int(sid_q),)).fetchone()
        if row:
            current_session = {k: row[k] for k in row.keys()}
    if current_session is None:
        row = cur.execute("SELECT * FROM inventory_sessions WHERE center_id=? AND status IN ('DRAFT','COUNTING') ORDER BY id DESC LIMIT 1", (int(center_id or 0),)).fetchone()
        if row:
            current_session = {k: row[k] for k in row.keys()}
    if current_session is None:
        warehouse_id = 0
        cur.execute("INSERT INTO inventory_sessions(center_id,warehouse_id,session_type,status,created_at,note) VALUES(?,?,?,?,datetime('now'),'')", (int(center_id or 0), int(warehouse_id or 0), 'MIXTO', 'DRAFT'))
        conn.commit()
        row = cur.execute("SELECT * FROM inventory_sessions WHERE id=?", (int(cur.lastrowid),)).fetchone()
        current_session = {k: row[k] for k in row.keys()}
    conn.close()

    # Si la vista entra sin inv_session_id explícito, no preseleccionar responsable en la UI.
    if not str(sid_q).isdigit():
        current_session['responsible_user_id'] = 0
        current_session['responsible_name'] = ''
        current_session['note'] = ''

    counts_map = _inventory_counts_map(int(current_session.get('id') or 0))
    selected_wh = int(current_session.get('warehouse_id') or 0)
    warehouse_lookup = {0: 'Todos'}
    for _w in warehouses:
        try:
            _wid = int((_w['id'] if hasattr(_w, 'keys') else _w.get('id')) or 0)
        except Exception:
            _wid = 0
        _name = str((_w['name'] if hasattr(_w, 'keys') else _w.get('name')) or '').strip()
        if _name:
            warehouse_lookup[_wid] = _name
    current_session['warehouse_name'] = warehouse_lookup.get(selected_wh, 'Todos')
    allowed_modes = _inventory_allowed_modes_for_warehouse_name(current_session.get('warehouse_name'))
    if inv_mode not in allowed_modes:
        inv_mode = 'limpieza' if 'limpieza' in allowed_modes else 'materias_primas'
        if inv_mode == 'producciones' and inv_family not in prod_valid:
            inv_family = 'frio'
        elif inv_mode == 'materias_primas' and inv_family not in raw_valid:
            inv_family = 'verduras'
        elif inv_mode == 'limpieza':
            inv_family = 'limpieza'
        elif inv_mode == 'libres':
            inv_family = 'libres'
    seen_warehouse_ids = set()
    seen_warehouse_names = {'todos'}
    warehouse_options = [{'id': 0, 'name': 'Todos'}]
    for w in warehouses:
        row = {k: w[k] for k in w.keys()} if hasattr(w, 'keys') else dict(w)
        try:
            wid = int(row.get('id') or 0)
        except Exception:
            wid = 0
        wname = str(row.get('name') or '').strip() or f'Almacén {wid}'
        if len(wname) < 2 and wid != 0:
            continue
        wkey = wname.lower()
        if wid in seen_warehouse_ids or wkey in seen_warehouse_names:
            continue
        seen_warehouse_ids.add(wid)
        seen_warehouse_names.add(wkey)
        row['name'] = wname
        warehouse_options.append(row)
    selected_wh_name_norm = _norm_warehouse_name(current_session.get('warehouse_name'))
    raw_groups = {k: [] for k in ['verduras','carnes','pescados','lacteos_huevos','secos','congelados','limpieza','otros']}
    for s in stocks:
        try:
            whid = int(s.get('warehouse_id') or 0)
        except Exception:
            whid = 0
        fam = _inventory_raw_family(s.get('item_name') or '', s.get('stock_area') or '')
        wh_name_norm = _norm_warehouse_name(s.get('warehouse_name') or '')
        preferred_names = _preferred_warehouse_names_for_raw_family(fam)
        if selected_wh and whid != selected_wh:
            continue
        # Si la familia tiene un almacén operativo preferente, el inventario debe
        # respetarlo de forma estricta para no contaminar Cámara con Cocina ni viceversa.
        if preferred_names:
            if selected_wh_name_norm not in {'', 'todos'} and selected_wh_name_norm not in preferred_names:
                continue
            if wh_name_norm not in preferred_names:
                continue
        has_activity = bool((s.get('last_move_at') or '').strip()) or float(s.get('stock_qty') or 0) != 0
        default_wh = _default_warehouse_name_for_stock_area(s.get('stock_area') or '')
        default_norm = _norm_warehouse_name(default_wh or '')
        is_default_position = bool(default_norm) and wh_name_norm == default_norm
        if preferred_names and wh_name_norm in preferred_names:
            is_default_position = True
        if fam == 'limpieza':
            if selected_wh == 0 and whid == 0:
                continue
        else:
            if not has_activity and not is_default_position:
                continue
        key = f"raw:{int(s.get('item_id') or 0)}:{fam}:{whid}"
        cnt = counts_map.get(key) or {}
        raw_groups[fam].append({
            'key': key,
            'item_id': int(s.get('item_id') or 0),
            'item_name': s.get('item_name') or '',
            'warehouse_id': whid,
            'warehouse_name': s.get('warehouse_name') or '',
            'base_unit': s.get('unit') or 'ud',
            'theoretical_qty': float(s.get('stock_qty') or 0),
            'physical_qty': float(cnt.get('physical_qty') or 0),
            'count_unit': (cnt.get('count_unit') or s.get('unit') or 'ud'),
            'is_checked': int(cnt.get('is_checked') or 0),
            'note': cnt.get('note') or '',
            'unit_cost_snapshot': float(s.get('current_price') or 0),
        })
    if raw_groups.get('limpieza'):
        cleaned = []
        seen_pairs = set()
        for r in raw_groups['limpieza']:
            pair = (r['item_id'], r['warehouse_id'])
            if pair in seen_pairs:
                continue
            seen_pairs.add(pair)
            cleaned.append(r)
        raw_groups['limpieza'] = cleaned
    for fam in raw_groups:
        raw_groups[fam].sort(key=lambda x: ((x['theoretical_qty']<=0), x['item_name'].lower()))

    prod_groups = {k: [] for k in ['frio','caliente','salsas','postres','guarniciones','otros']}
    prod_id_groups = {}
    recipe_meta = {}
    if production_stocks:
        conn = db(); cur = conn.cursor()
        ids = sorted({int(p.get('last_prod_id') or 0) for p in production_stocks if int(p.get('last_prod_id') or 0) > 0})
        if ids:
            qs = ','.join('?'*len(ids))
            rows = cur.execute(f"SELECT id, COALESCE(production_group,'Otros') production_group FROM productions WHERE id IN ({qs})", ids).fetchall()
            prod_id_groups = {int(r['id']): (r['production_group'] or 'Otros') for r in rows}
        recipe_names = sorted({str(p.get('recipe_name') or p.get('item_name') or '').strip().lower() for p in production_stocks if str(p.get('recipe_name') or p.get('item_name') or '').strip()})
        if recipe_names:
            qs = ','.join('?'*len(recipe_names))
            rows = cur.execute(f"SELECT lower(trim(name)) k, COALESCE(subcategory,'') subcategory, COALESCE(category,'') category FROM recipes WHERE lower(trim(name)) IN ({qs})", recipe_names).fetchall()
            recipe_meta = {str(r['k']): {'subcategory': (r['subcategory'] or ''), 'category': (r['category'] or '')} for r in rows}
        conn.close()
    for p in production_stocks:
        try:
            whid = int(p.get('warehouse_id') or 0)
        except Exception:
            whid = 0
        if selected_wh and whid != selected_wh:
            continue
        pg = prod_id_groups.get(int(p.get('last_prod_id') or 0), '')
        recipe_key = str(p.get('recipe_name') or p.get('item_name') or '').strip().lower()
        recipe_meta_row = recipe_meta.get(recipe_key, {})
        recipe_sub = recipe_meta_row.get('subcategory', '')
        recipe_cat = recipe_meta_row.get('category', '')
        fam = _inventory_production_family(pg, p.get('item_name') or '', recipe_sub, recipe_cat)
        key = f"production:{int(p.get('item_id') or 0)}:{fam}:{whid}"
        cnt = counts_map.get(key) or {}
        prod_groups[fam].append({
            'key': key, 'item_id': int(p.get('item_id') or 0), 'item_name': p.get('item_name') or '',
            'warehouse_id': whid, 'warehouse_name': p.get('warehouse_name') or '',
            'base_unit': p.get('unit') or 'ud', 'theoretical_qty': float(p.get('stock_qty') or 0),
            'physical_qty': float(cnt.get('physical_qty') or 0), 'count_unit': (cnt.get('count_unit') or p.get('unit') or 'ud'),
            'is_checked': int(cnt.get('is_checked') or 0), 'note': cnt.get('note') or '',
            'unit_cost_snapshot': float(p.get('current_price') or 0),
            'production_group': pg or 'Otros',
        })
    for fam in prod_groups:
        prod_groups[fam].sort(key=lambda x: ((x['theoretical_qty']<=0), x['item_name'].lower()))

    conn = db(); cur = conn.cursor()
    free_rows_raw = cur.execute("SELECT * FROM inventory_counts WHERE session_id=? AND source_type='free' ORDER BY id DESC", (int(current_session.get('id') or 0),)).fetchall()
    conn.close()
    free_rows = []
    for r in free_rows_raw:
        d = {k:r[k] for k in r.keys()}
        fk = str(d.get('family_key') or '').strip().lower()
        block = 'materias_primas'; fam = 'otros'
        if ':' in fk:
            block, fam = fk.split(':', 1)
        elif fk in {'limpieza','libres'}:
            block, fam = ('limpieza','limpieza') if fk == 'limpieza' else ('materias_primas','otros')
        d['free_block'] = block
        d['free_family'] = fam or 'otros'
        free_rows.append(d)

    def _count_checked(rows):
        return sum(1 for r in rows if int(r.get('is_checked') or 0) == 1)

    raw_total = sum(len(v) for v in raw_groups.values())
    prod_total = sum(len(v) for v in prod_groups.values())
    free_total = len(free_rows)
    raw_checked = sum(_count_checked(v) for v in raw_groups.values())
    prod_checked = sum(_count_checked(v) for v in prod_groups.values())
    free_checked = _count_checked(free_rows)

    if inv_mode == 'materias_primas':
        current_rows = raw_groups.get(inv_family, [])
    elif inv_mode == 'producciones':
        current_rows = prod_groups.get(inv_family, [])
    elif inv_mode == 'limpieza':
        current_rows = raw_groups.get('limpieza', [])
    else:
        current_rows = free_rows

    summary = {
        'raw_total': raw_total,
        'raw_checked': raw_checked,
        'production_total': prod_total,
        'production_checked': prod_checked,
        'free_total': free_total,
        'free_checked': free_checked,
        'current_total': len(current_rows),
        'current_checked': _count_checked(current_rows),
        'current_pending': max(len(current_rows) - _count_checked(current_rows), 0),
        'limpieza_total': len(raw_groups.get('limpieza', [])),
        'limpieza_checked': _count_checked(raw_groups.get('limpieza', [])),
    }
    return {
        'inventory_session': current_session, 'inventory_mode': inv_mode, 'inventory_family': inv_family,
        'inventory_raw_groups': raw_groups, 'inventory_production_groups': prod_groups,
        'inventory_free_rows': free_rows, 'inventory_warehouse_options': warehouse_options,
        'inventory_summary': summary,
    }

# ==============================================================================
# RUTA PRINCIPAL — GET /
# ==============================================================================

@app.get("/", response_class=HTMLResponse)
def home(request: Request, center_id: Optional[int] = None):
    page = request.query_params.get("page", "inicio")
    stock_q = (request.query_params.get("stock_q") or "").strip()
    show_archived_productions = (request.query_params.get("show_archived_productions") or "0") == "1"
    show_archived_orders = (request.query_params.get("show_archived_orders") or "0") == "1"
    show_archived_receipts = (request.query_params.get("show_archived_receipts") or "0") == "1"
    stock_item_id_q = request.query_params.get("stock_item_id") or ""
    stock_wh_id_q = request.query_params.get("stock_wh_id") or ""

    if page not in {"inicio", "stock", "inventario", "recetas", "producciones", "pedidos", "albaranes", "laboratorio", "admin"}:
        page = "inicio"

    rid_q = request.query_params.get("rid") or ""
    new_q = request.query_params.get("new") or ""
    pid_q = request.query_params.get("pid") or ""
    oid_q = request.query_params.get("oid") or ""
    aid_q = request.query_params.get("aid") or ""
    minmax_item_q = request.query_params.get("minmax_item") or ""
    minmax_center_q = request.query_params.get("minmax_center") or ""
    minmax_wh_q = request.query_params.get("minmax_wh") or ""

    if page == "recetas" and new_q == "1":
        rid_q = ""

    # --- Detalle de receta ---
    recipe_detail = None
    if rid_q.isdigit():
        connx = db(); curx = connx.cursor()
        recipe_detail = recipe_with_calc(curx, int(rid_q))
        connx.close()
        if recipe_detail and not recipe_visible_in_center(recipe_detail, center_id):
            recipe_detail = None

    # --- Detalle de producción ---
    production_detail = None
    if pid_q.isdigit():
        connx = db(); curx = connx.cursor()
        production_detail = get_production_detail(curx, pid_q)
        connx.close()

    # --- Pedidos: auto-seleccionar borrador ---
    if page == "pedidos" and (center_id or 0) > 0:
        connx = db(); curx = connx.cursor()
        selected_oid: Optional[int] = None
        if oid_q.isdigit():
            row = curx.execute("SELECT id,center_id,status FROM orders WHERE id=?", (int(oid_q),)).fetchone()
            if row and int(row["center_id"]) == int(center_id):
                selected_oid = int(row["id"])
        if selected_oid is None:
            row = curx.execute("SELECT id FROM orders WHERE center_id=? AND status='DRAFT' ORDER BY id DESC LIMIT 1",
                               (int(center_id),)).fetchone()
            if row:
                selected_oid = int(row["id"])
            else:
                now = __import__("datetime").datetime.utcnow().isoformat()
                try:
                    curx.execute("INSERT INTO orders(center_id,status,created_at,note) VALUES(?,'DRAFT',?,'')",
                                 (int(center_id), now))
                    selected_oid = int(curx.lastrowid)
                    connx.commit()
                except sqlite3.OperationalError:
                    selected_oid = None
        oid_q = str(selected_oid) if selected_oid is not None else ""
        connx.close()

    # --- Detalle de pedido ---
    order_detail = None
    if oid_q.isdigit():
        connx = db(); curx = connx.cursor()
        order_detail = order_with_lines(curx, int(oid_q))
        connx.close()

    # Opciones de proveedor por línea de pedido
    if order_detail and (order_detail.get("center_id") is not None):
        try:
            cx = db(); curx = cx.cursor()
            c_id = int(order_detail.get("center_id"))
            for ln in (order_detail.get("lines") or []):
                try:
                    it_id = int(ln.get("item_id"))
                except Exception:
                    it_id = None
                ln["supplier_options"] = _supplier_options_for_item(curx, c_id, it_id) if it_id else []
            cx.close()
        except Exception:
            pass

    # Pre-confirmación resumen por proveedor
    preconfirm_summary = None
    if page == "pedidos" and order_detail and (request.query_params.get("preconfirm") == "1"):
        buckets = {}
        for ln in (order_detail.get("lines") or []):
            sup = (ln.get("supplier_name") or "(Sin asignar)").strip() or "(Sin asignar)"
            b = buckets.setdefault(sup, {"supplier_name": sup, "lines": [], "total_qty_base": 0.0})
            b["lines"].append(ln)
            try:
                b["total_qty_base"] += float(ln.get("qty_base") or 0)
            except Exception:
                pass
        preconfirm_summary = sorted(buckets.values(),
                                     key=lambda x: (x["supplier_name"] == "(Sin asignar)", x["supplier_name"].lower()))

    # Min/max item
    minmax_item = None
    if minmax_item_q.isdigit():
        connx = db(); curx = connx.cursor(); ensure_columns(curx)
        row = curx.execute("SELECT id,name,unit,min_qty,max_qty FROM items WHERE id=?",
                           (int(minmax_item_q),)).fetchone()
        if row:
            minmax_item = {k: row[k] for k in row.keys()}
            if minmax_center_q.isdigit() and minmax_wh_q.isdigit():
                pref = curx.execute(
                    "SELECT min_qty,max_qty FROM item_location_prefs WHERE item_id=? AND center_id=? AND warehouse_id=?",
                    (int(minmax_item_q), int(minmax_center_q), int(minmax_wh_q))).fetchone()
                minmax_item["center_id"] = int(minmax_center_q)
                minmax_item["warehouse_id"] = int(minmax_wh_q)
                if pref:
                    minmax_item["min_qty"] = pref["min_qty"]
                    minmax_item["max_qty"] = pref["max_qty"]
                wh = curx.execute(
                    "SELECT w.name warehouse_name, c.name center_name FROM warehouses w JOIN centers c ON c.id=w.center_id WHERE w.id=?",
                    (int(minmax_wh_q),)).fetchone()
                if wh:
                    minmax_item["warehouse_name"] = wh["warehouse_name"]
                    minmax_item["center_name"] = wh["center_name"]
        connx.close()

    # Dashboard global
    centers, warehouses, items, stocks, summary, recipes = get_dashboard_data(center_id)
    warehouses_json = [{k: w[k] for k in w.keys()} for w in warehouses]
    items_json = [{k: i[k] for k in i.keys()} for i in items]
    for it in items_json:
        it['stock_area'] = normalize_stock_area(it.get('stock_area') or '')
        it['stock_area_label'] = stock_area_label(it.get('stock_area'))
    filtered_stocks = []
    for s in stocks:
        s['stock_area'] = normalize_stock_area(s.get('stock_area') or '')
        s['stock_area_label'] = stock_area_label(s.get('stock_area'))
        inferred_family = _inventory_raw_family(s.get('item_name') or '', s.get('stock_area') or '')
        s['inventory_raw_family'] = inferred_family
        has_activity = bool((s.get('last_move_at') or '').strip()) or float(s.get('stock_qty') or 0) != 0
        default_wh = _default_warehouse_name_for_stock_area(s.get('stock_area') or '')
        wh_name_norm = _norm_warehouse_name(s.get('warehouse_name') or '')
        default_norm = _norm_warehouse_name(default_wh or '')
        preferred_names = _preferred_warehouse_names_for_raw_family(inferred_family)
        keep = has_activity or not default_wh or wh_name_norm == default_norm
        if preferred_names and wh_name_norm in preferred_names:
            keep = True
        if keep:
            filtered_stocks.append(s)
    stocks = filtered_stocks
    stock_groups = {
        'fresh': [s for s in stocks if s.get('inventory_raw_family') in {'verduras','carnes','pescados','lacteos_huevos'} and _norm_warehouse_name(s.get('warehouse_name') or '') == 'camara'],
        'frozen': [s for s in stocks if (s.get('stock_area') == 'CONGELADOS' or s.get('inventory_raw_family') == 'congelados') and _norm_warehouse_name(s.get('warehouse_name') or '') == 'camara'],
        'dry': [s for s in stocks if s.get('inventory_raw_family') == 'secos' and _norm_warehouse_name(s.get('warehouse_name') or '') == 'economato'],
        'cleaning': [s for s in stocks if s.get('inventory_raw_family') == 'limpieza' and _norm_warehouse_name(s.get('warehouse_name') or '') == 'economato'],
        'unclassified': [s for s in stocks if s.get('stock_area') == 'SIN_CLASIFICACION'],
        'unlocated': [s for s in stocks if not s.get('stock_area')],
    }
    stock_section = (request.query_params.get('stock_section') or 'fresh').strip().lower()
    if stock_section not in {'fresh', 'productions', 'frozen', 'dry', 'cleaning', 'unclassified', 'unlocated', 'current_all'}:
        stock_section = 'fresh'

    connps = db(); curps = connps.cursor()
    production_stocks = get_production_stocks(curps, center_id if center_id else None)
    connps.close()

    inventory_ctx = _build_inventory_context(
        center_id=center_id or 0,
        warehouses=warehouses,
        stocks=stocks,
        production_stocks=production_stocks,
        request=request,
    )

    item_search = (request.query_params.get("item_search") or "").strip()
    ql = item_search.lower()
    items_pick = [it for it in items_json if ql in (it.get("name") or "").lower()][:60] if ql else items_json[:60]

    # Proveedores y precios
    conn2 = db(); cur2 = conn2.cursor()
    suppliers = cur2.execute("SELECT id,name,phone,email,is_active FROM suppliers ORDER BY name").fetchall()
    supplier_prices = cur2.execute(
        """SELECT sp.id,sp.supplier_id,sp.item_id,sp.center_id,sp.price_per_purchase,sp.purchase_unit,
                  sp.purchase_to_base_factor,sp.is_preferred,sp.updated_at,s.name supplier_name,i.name item_name
             FROM supplier_item_prices sp
             JOIN suppliers s ON s.id=sp.supplier_id
             JOIN items i ON i.id=sp.item_id
             ORDER BY s.name,i.name""").fetchall()
    suppliers_json = [{k: s[k] for k in s.keys()} for s in suppliers]
    supplier_prices_json = [{k: p[k] for k in p.keys()} for p in supplier_prices]
    users_rows = cur2.execute("SELECT id,name,role,center_id,is_active FROM users WHERE COALESCE(is_active,1)=1 ORDER BY CASE WHEN UPPER(TRIM(name))='ADMIN GENERAL' THEN 1 ELSE 0 END, name").fetchall()
    users_json = [{k: u[k] for k in u.keys()} for u in users_rows]
    conn2.close()

    # Producciones
    connp = db(); curp = connp.cursor()
    production_group_filter = (request.query_params.get("prod_group") or "").strip()
    productions_json = list_productions(
        curp,
        center_id=center_id,
        show_archived=show_archived_productions,
        production_group_filter=production_group_filter,
    )
    connp.close()

    # Pedidos
    conno = db(); curo = conno.cursor()
    order_status_clause = "o.status='ARCHIVED'" if show_archived_orders else "COALESCE(o.status,'') <> 'ARCHIVED'"
    if center_id:
        orders = curo.execute(
            f"""SELECT o.id,o.status,o.created_at,o.note,c.name center_name
                 FROM orders o JOIN centers c ON c.id=o.center_id
                WHERE o.center_id=? AND {order_status_clause} ORDER BY o.id DESC""",
            (center_id,)).fetchall()
    else:
        orders = curo.execute(
            f"""SELECT o.id,o.status,o.created_at,o.note,c.name center_name
                 FROM orders o JOIN centers c ON c.id=o.center_id
                WHERE {order_status_clause} ORDER BY o.id DESC""").fetchall()
    orders_json = [{k: r[k] for k in r.keys()} for r in orders]
    conno.close()

    # Albaranes
    connr = db(); curr = connr.cursor()
    try:
        cleanup_receipt_photos(curr, int(center_id) if center_id else None)
        connr.commit()
    except Exception:
        pass
    receipt_status_clause = "r.status='ARCHIVED'" if show_archived_receipts else "COALESCE(r.status,'') <> 'ARCHIVED'"
    if center_id:
        receipts = curr.execute(
            f"""SELECT r.id,r.status,r.created_at,r.doc_number,r.doc_date,r.note,
                      c.name center_name,w.name warehouse_name,s.name supplier_name
                 FROM receipts r JOIN centers c ON c.id=r.center_id
                 JOIN warehouses w ON w.id=r.warehouse_id JOIN suppliers s ON s.id=r.supplier_id
                WHERE r.center_id=? AND {receipt_status_clause} ORDER BY r.id DESC""",
            (int(center_id),)).fetchall()
    else:
        receipts = curr.execute(
            f"""SELECT r.id,r.status,r.created_at,r.doc_number,r.doc_date,r.note,
                      c.name center_name,w.name warehouse_name,s.name supplier_name
                 FROM receipts r JOIN centers c ON c.id=r.center_id
                 JOIN warehouses w ON w.id=r.warehouse_id JOIN suppliers s ON s.id=r.supplier_id
                WHERE {receipt_status_clause} ORDER BY r.id DESC""").fetchall()
    receipts_json = [{k: r[k] for k in r.keys()} for r in receipts]

    # Detalle de albarán
    receipt_detail = None
    auto_ocr_meta = None
    if aid_q.isdigit():
        rh = curr.execute(
            """SELECT r.*, c.name center_name, w.name warehouse_name, s.name supplier_name
                 FROM receipts r JOIN centers c ON c.id=r.center_id
                 JOIN warehouses w ON w.id=r.warehouse_id JOIN suppliers s ON s.id=r.supplier_id
                WHERE r.id=?""", (int(aid_q),)).fetchone()
        if rh:
            lines = curr.execute(
                """SELECT rl.*, i.name item_name, i.unit base_unit
                     FROM receipt_lines rl JOIN items i ON i.id=rl.item_id
                    WHERE rl.receipt_id=? ORDER BY rl.id""", (int(aid_q),)).fetchall()
            photos = curr.execute(
                "SELECT id,file_path,created_at FROM receipt_photos WHERE receipt_id=? ORDER BY id",
                (int(aid_q),)).fetchall()
            photo_dicts = [{k: p[k] for k in p.keys()} for p in photos]
            for _p in photo_dicts:
                try:
                    _abs = __import__("pathlib").Path(UPLOADS_DIR) / str(_p.get("file_path") or "")
                    _p["exists"] = _abs.exists()
                except Exception:
                    _p["exists"] = False
            ocr_run = curr.execute("SELECT * FROM receipt_ocr_runs WHERE receipt_id=? ORDER BY id DESC LIMIT 1",
                                   (int(aid_q),)).fetchone()
            ocr_lines = []
            if ocr_run:
                ocr_lines = curr.execute("SELECT * FROM receipt_ocr_lines WHERE ocr_run_id=? ORDER BY id",
                                         (int(ocr_run["id"]),)).fetchall()
            receipt_detail = {k: rh[k] for k in rh.keys()}
            receipt_detail["lines"] = [{k: l[k] for k in l.keys()} for l in lines]
            receipt_detail["photos"] = photo_dicts
            valid_photo_count = sum(1 for _p in photo_dicts if _p.get("exists"))
            receipt_detail["ocr"] = ({k: ocr_run[k] for k in ocr_run.keys()}
                                     if (ocr_run and valid_photo_count > 0) else None)
            receipt_detail["photo_missing"] = bool(photo_dicts) and valid_photo_count == 0
            if receipt_detail["ocr"]:
                receipt_detail["ocr"]["lines"] = [{k: l[k] for k in l.keys()} for l in ocr_lines]
                for _ol in receipt_detail["ocr"]["lines"]:
                    _raw = re.sub(r"\s+", " ", str(_ol.get("item_name_raw") or "").strip())
                    _matched = re.sub(r"\s+", " ", str(_ol.get("matched_item_name") or "").strip())
                    _display = (_matched or _raw or "").upper()
                    if _display:
                        try:
                            _display = _ocr_postfix_product_cleanup(_display)
                        except Exception:
                            pass
                    _ol["display_name"] = _display
    connr.close()

    resp = templates.TemplateResponse("index.html", {
        "request": request,
        "page": page,
        "centers": [{k: c[k] for k in c.keys()} for c in centers],
        "centers_json": [{k: c[k] for k in c.keys()} for c in centers],
        "warehouses": warehouses_json,
        "items": items_json,
        "items_pick": items_pick,
        "item_search": item_search,
        "stocks": stocks,
        "production_stocks": production_stocks,
        "summary": summary,
        "recipes": recipes,
        "suppliers": suppliers_json,
        "supplier_prices": supplier_prices_json,
        "users": users_json,
        "selected_center_id": center_id or 0,
        "build_id": BUILD_ID,
        "categories": list(CATEGORY_CODES.keys()),
        "subcategories": SUBCATEGORIES,
        "allergens_ue": [{"code": c, "icon": i, "name": n} for c, i, n in ALLERGENS_UE],
        "recipe_detail": recipe_detail,
        "productions": productions_json,
        "production_group_filter": production_group_filter,
        "production_detail": production_detail,
        "production_groups": production_groups(),
        "production_units": production_units(),
        "orders": orders_json,
        "order_detail": order_detail,
        "receipts": receipts_json,
        "receipt_detail": receipt_detail,
        "auto_ocr_meta": auto_ocr_meta,
        "preconfirm_summary": preconfirm_summary,
        "minmax_item": minmax_item,
        "stock_q": stock_q,
        "stock_item_id_q": stock_item_id_q,
        "stock_wh_id_q": stock_wh_id_q,
        "show_archived_productions": show_archived_productions,
        "show_archived_orders": show_archived_orders,
        "show_archived_receipts": show_archived_receipts,
        "stock_groups": stock_groups,
        "stock_section": stock_section,
        "stock_area_options": STOCK_AREAS,
        **inventory_ctx,
    })
    resp.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
    resp.headers["Pragma"] = "no-cache"
    return resp
