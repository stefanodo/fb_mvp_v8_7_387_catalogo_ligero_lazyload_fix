// orders.js — ayuda ligera de selección de artículos en pedidos
(function(){
  function debounce(fn, ms){ let t; return (...args)=>{ clearTimeout(t); t=setTimeout(()=>fn(...args), ms); }; }
  async function fetchItems(q){
    const res = await fetch('/api/items/search?q=' + encodeURIComponent(q || '') + '&limit=12', {headers:{'Accept':'application/json'}});
    const js = await res.json();
    return (js && js.items) ? js.items : [];
  }
  function setUnit(form, unit){
    const sel = form && form.querySelector('select[name="qty_unit"]');
    if(!sel) return;
    const u = String(unit || 'ud').toLowerCase();
    if(u === 'g'){ sel.innerHTML = '<option value="g">g</option><option value="kg">kg</option>'; sel.value='g'; return; }
    if(u === 'ml'){ sel.innerHTML = '<option value="g">g</option><option value="kg">kg</option>'; sel.value='g'; return; }
    if(u === 'kg' || u === 'l'){ sel.innerHTML = '<option value="g">g</option><option value="kg">kg</option>'; sel.value='kg'; return; }
    sel.innerHTML = `<option value="${u}">${u}</option>`;
    sel.value = u;
  }
  function wire(form){
    if(!form || form.__orderSmartWired) return; form.__orderSmartWired = true;
    const input = form.querySelector('.order-item-query');
    const hidden = form.querySelector('input[name="item_id"][data-smart-item-id]');
    const results = form.querySelector('.order-item-results');
    if(!input || !hidden || !results) return;
    let last='';
    function hide(){ results.innerHTML=''; results.style.display='none'; }
    function choose(it){
      input.value = it.name + ' [#' + it.id + ']';
      hidden.value = String(it.id || '');
      setUnit(form, it.unit);
      hide();
    }
    const search = debounce(async ()=>{
      const q = (input.value || '').trim();
      hidden.value = '';
      if(q.length < 1){ hide(); return; }
      last = q;
      try{
        const items = await fetchItems(q);
        if(last !== q) return;
        if(!items.length){ hide(); return; }
        results.innerHTML = items.map(it => `<button type="button" data-id="${it.id}" data-name="${String(it.name||'').replace(/"/g,'&quot;')}" data-unit="${String(it.unit||'').replace(/"/g,'&quot;')}">${it.name} <small>[${it.unit||'ud'}]</small></button>`).join('');
        results.style.display='block';
      }catch(_){ hide(); }
    }, 120);
    input.addEventListener('input', search);
    input.addEventListener('focus', search);
    results.addEventListener('mousedown', e=>e.preventDefault());
    results.addEventListener('click', e=>{
      const btn = e.target.closest('button[data-id]'); if(!btn) return;
      choose({id:btn.dataset.id, name:btn.dataset.name, unit:btn.dataset.unit});
    });
    form.addEventListener('submit', ()=>{
      const m = /\[#(\d+)\]\s*$/.exec(input.value || '');
      if(m) hidden.value = m[1];
    });
    document.addEventListener('click', e=>{ if(e.target!==input && !results.contains(e.target)) hide(); });
  }
  document.querySelectorAll('form[action*="/add_line_form"]').forEach(wire);
  document.addEventListener('focusin', e=>{ const f=e.target && e.target.closest && e.target.closest('form[action*="/add_line_form"]'); if(f) wire(f); });
})();
