# ==============================================================================
# BLOQUE ADMIN · Centros, configuración general
# ==============================================================================
from fastapi import APIRouter, Form
from fastapi.responses import RedirectResponse

from app.core import db
from app.services.admin_service import normalize_center_name, redirect_admin

router = APIRouter()


@router.post("/center/{center_id}/update_name_form")
def update_center_name_form(center_id: int, name: str = Form(...)):
    conn = db(); cur = conn.cursor()
    cur.execute("UPDATE centers SET name=? WHERE id=?", (normalize_center_name(name), center_id))
    conn.commit(); conn.close()
    return redirect_admin(center_id=0, ok=1)


@router.get("/health")
def health():
    return {"ok": True}


@router.post("/user/create_form")
def create_user_form(name: str = Form(...), role: str = Form('OPERATIVO'), center_id: int = Form(0), is_active: int = Form(1)):
    conn = db(); cur = conn.cursor()
    safe_name = (name or '').strip().upper()[:120]
    safe_role = (role or 'OPERATIVO').strip().upper()[:40]
    if safe_name:
        cur.execute("INSERT INTO users(name,role,center_id,is_active) VALUES(?,?,?,?)", (safe_name, safe_role, int(center_id or 0), 1 if int(is_active or 0) else 0))
        conn.commit()
    conn.close()
    return redirect_admin(center_id=0, ok=1)


@router.post("/user/{user_id}/update_form")
def update_user_form(user_id: int, name: str = Form(...), role: str = Form('OPERATIVO'), center_id: int = Form(0), is_active: int = Form(0)):
    conn = db(); cur = conn.cursor()
    safe_name = (name or '').strip().upper()[:120]
    safe_role = (role or 'OPERATIVO').strip().upper()[:40]
    cur.execute("UPDATE users SET name=?, role=?, center_id=?, is_active=? WHERE id=?", (safe_name, safe_role, int(center_id or 0), 1 if int(is_active or 0) else 0, int(user_id)))
    conn.commit(); conn.close()
    return redirect_admin(center_id=0, ok=1)


@router.post("/user/{user_id}/delete_form")
def delete_user_form(user_id: int):
    conn = db(); cur = conn.cursor()
    linked = 0
    try:
        linked = cur.execute("SELECT COUNT(*) FROM inventory_sessions WHERE responsible_user_id=?", (int(user_id),)).fetchone()[0]
    except Exception:
        linked = 0
    if linked:
        cur.execute("UPDATE users SET is_active=0 WHERE id=?", (int(user_id),))
    else:
        cur.execute("DELETE FROM users WHERE id=?", (int(user_id),))
    conn.commit(); conn.close()
    return redirect_admin(center_id=0, ok=1)
