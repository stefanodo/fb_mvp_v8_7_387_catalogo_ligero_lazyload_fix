# ==============================================================================
# BLOQUE PEDIDOS · Pedidos, líneas, sugerencias, impresión
# ==============================================================================
from fastapi import APIRouter, Form, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from typing import Optional
from datetime import datetime
import sqlite3

from app.core import (
    db, _parse_float, ensure_columns, _resolve_item_id, _unit_factor,
    _suggest_supplier_id, order_with_lines, human_qty, fmt_dt, status_label,
)
from app.services.orders_service import order_page_url, normalize_order_note, parse_optional_int

router = APIRouter()


def _order_has_responsible(cur, order_id: int) -> bool:
    row = cur.execute("SELECT COALESCE(responsible_user_id,0) responsible_user_id, COALESCE(responsible_name,'') responsible_name FROM orders WHERE id=?", (order_id,)).fetchone()
    if not row:
        return False
    return int(row["responsible_user_id"] or 0) > 0 and bool(str(row["responsible_name"] or "").strip())


@router.post("/order/new_form")
def order_new_form(center_id: int = Form(...), responsible_user_id: int = Form(0), note: str = Form("")):
    conn = db(); cur = conn.cursor(); ensure_columns(cur)
    rid = int(responsible_user_id or 0)
    if rid <= 0:
        conn.close()
        return RedirectResponse(url=order_page_url(center_id=center_id, ord_msg='responsible_required', anchor=''), status_code=303)
    resp = cur.execute("SELECT id,name FROM users WHERE id=? AND COALESCE(is_active,1)=1 AND UPPER(TRIM(name)) <> 'ADMIN GENERAL'", (rid,)).fetchone()
    if not resp:
        conn.close()
        return RedirectResponse(url=order_page_url(center_id=center_id, ord_msg='responsible_required', anchor=''), status_code=303)
    now = datetime.utcnow().isoformat()
    cur.execute("INSERT INTO orders(center_id,status,created_at,note,responsible_user_id,responsible_name) VALUES(?,'DRAFT',?,?,?,?)",
                (center_id, now, normalize_order_note(note), int(resp['id']), (resp['name'] or '').strip()))
    oid = cur.lastrowid
    conn.commit(); conn.close()
    return RedirectResponse(url=order_page_url(center_id=center_id, oid=oid),
                            status_code=303)


@router.post("/order/{order_id}/responsible_form")
def order_responsible_form(order_id: int, responsible_user_id: int = Form(0)):
    conn = db(); cur = conn.cursor(); ensure_columns(cur)
    o = cur.execute("SELECT center_id,status FROM orders WHERE id=?", (order_id,)).fetchone()
    if not o or o["status"] != "DRAFT":
        conn.close()
        return RedirectResponse(url=order_page_url(oid=order_id, err=1), status_code=303)
    rid = int(responsible_user_id or 0)
    if rid <= 0:
        conn.close()
        return RedirectResponse(url=order_page_url(center_id=int(o['center_id']), oid=order_id, ord_msg='responsible_required'), status_code=303)
    resp = cur.execute("SELECT id,name FROM users WHERE id=? AND COALESCE(is_active,1)=1 AND UPPER(TRIM(name)) <> 'ADMIN GENERAL'", (rid,)).fetchone()
    if not resp:
        conn.close()
        return RedirectResponse(url=order_page_url(center_id=int(o['center_id']), oid=order_id, ord_msg='responsible_required'), status_code=303)
    cur.execute("UPDATE orders SET responsible_user_id=?, responsible_name=? WHERE id=?", (int(resp['id']), (resp['name'] or '').strip(), order_id))
    conn.commit(); conn.close()
    return RedirectResponse(url=order_page_url(center_id=int(o['center_id']), oid=order_id, ok=1), status_code=303)


@router.post("/order/{order_id}/add_suggestions_form")
def order_add_suggestions_form(order_id: int, warehouse_id: str = Form("")):
    conn = db(); cur = conn.cursor(); ensure_columns(cur)
    o = cur.execute("SELECT center_id,status FROM orders WHERE id=?", (order_id,)).fetchone()
    if not o or o["status"] != "DRAFT":
        conn.close()
        return RedirectResponse(url=order_page_url(oid=order_id, err=1), status_code=303)
    if not _order_has_responsible(cur, order_id):
        conn.close()
        return RedirectResponse(url=order_page_url(center_id=int(o['center_id']), oid=order_id, ord_msg='responsible_required'), status_code=303)
    center_id = int(o["center_id"])
    wh_id = None
    try:
        if str(warehouse_id).strip().isdigit():
            wh_id = int(str(warehouse_id).strip())
    except Exception:
        pass
    if wh_id is None:
        roww = cur.execute("SELECT id FROM warehouses WHERE center_id=? ORDER BY id LIMIT 1",
                           (center_id,)).fetchone()
        if roww:
            wh_id = int(roww["id"])

    wh_clause = ""
    params = [center_id, center_id]
    if wh_id is not None:
        wh_clause = " AND w.id=?"
        params.append(int(wh_id))

    rows = cur.execute(f"""
        SELECT w.id warehouse_id, i.id item_id, i.unit base_unit,
               COALESCE(lp.min_qty, i.min_qty) min_qty,
               COALESCE(lp.max_qty, i.max_qty) max_qty,
               COALESCE(SUM(CASE WHEN m.movement_type IN ('ENTRADA','IN') THEN m.qty
                                 WHEN m.movement_type IN ('SALIDA','OUT') THEN -m.qty ELSE -m.qty END),0) stock_qty
          FROM warehouses w CROSS JOIN items i
          LEFT JOIN item_location_prefs lp ON lp.center_id=w.center_id AND lp.warehouse_id=w.id AND lp.item_id=i.id
          LEFT JOIN movements m ON m.warehouse_id=w.id AND m.item_id=i.id AND m.center_id=?
         WHERE w.center_id=?{wh_clause}
         GROUP BY w.id,i.id,i.unit,COALESCE(lp.min_qty,i.min_qty),COALESCE(lp.max_qty,i.max_qty)""",
        tuple(params)).fetchall()

    prod_params = [center_id]
    prod_wh_clause = ""
    if wh_id is not None:
        prod_wh_clause = " AND p.warehouse_id=?"
        prod_params.append(int(wh_id))
    planned_out = {}
    for rr in cur.execute(f"""
        SELECT p.warehouse_id, pl.item_id, SUM(pl.qty_base) qty
          FROM productions p JOIN production_lines pl ON pl.production_id=p.id
         WHERE p.center_id=? AND p.status='DRAFT' AND pl.line_type='OUT'{prod_wh_clause}
         GROUP BY p.warehouse_id, pl.item_id""", tuple(prod_params)).fetchall():
        planned_out[(int(rr["warehouse_id"]), int(rr["item_id"]))] = float(rr["qty"] or 0.0)

    existing = {(r["warehouse_id"], r["item_id"]) for r in cur.execute(
        "SELECT warehouse_id,item_id FROM order_lines WHERE order_id=?", (order_id,)).fetchall()}

    added = 0
    for r in rows:
        stock_qty = float(r["stock_qty"] or 0)
        min_qty = float(r["min_qty"] or 0)
        max_qty = float(r["max_qty"] or 0)
        if min_qty <= 0 or max_qty <= 0:
            continue
        key = (int(r["warehouse_id"]), int(r["item_id"]))
        projected_stock = stock_qty - float(planned_out.get(key, 0.0))
        if projected_stock >= min_qty:
            continue
        qty_to_order = max(0.0, max_qty - projected_stock)
        if qty_to_order <= 0:
            continue
        sid = _suggest_supplier_id(cur, center_id, key[1])
        if key in existing:
            cur.execute(
                "UPDATE order_lines SET qty_base=?,input_unit=?,qty_input=?,supplier_id=? WHERE order_id=? AND warehouse_id=? AND item_id=?",
                (qty_to_order, r["base_unit"], qty_to_order, sid, order_id, key[0], key[1]))
        else:
            cur.execute(
                "INSERT INTO order_lines(order_id,warehouse_id,item_id,qty_base,input_unit,qty_input,supplier_id) VALUES(?,?,?,?,?,?,?)",
                (order_id, key[0], key[1], qty_to_order, r["base_unit"], qty_to_order, sid))
        added += 1

    conn.commit(); conn.close()
    return RedirectResponse(
        url=order_page_url(center_id=center_id, oid=order_id, ok=1, added=added),
        status_code=303)




@router.post("/order/{order_id}/add_production_needs_form")
def order_add_production_needs_form(order_id: int):
    conn = db(); cur = conn.cursor(); ensure_columns(cur)
    o = cur.execute("SELECT center_id,status FROM orders WHERE id=?", (order_id,)).fetchone()
    if not o or o["status"] != "DRAFT":
        conn.close()
        return RedirectResponse(url=order_page_url(oid=order_id, err=1), status_code=303)
    center_id = int(o["center_id"])
    if not _order_has_responsible(cur, order_id):
        conn.close()
        return RedirectResponse(url=order_page_url(center_id=center_id, oid=order_id, ord_msg='responsible_required'), status_code=303)

    required_rows = cur.execute(
        """
        SELECT p.warehouse_id, pl.item_id, SUM(pl.qty_base) required_qty
          FROM productions p
          JOIN production_lines pl ON pl.production_id=p.id
         WHERE p.center_id=? AND p.status='DRAFT' AND pl.line_type='OUT'
         GROUP BY p.warehouse_id, pl.item_id
        """,
        (center_id,),
    ).fetchall()

    required_map = {(int(r['warehouse_id']), int(r['item_id'])): float(r['required_qty'] or 0.0) for r in required_rows}
    if not required_map:
        conn.close()
        return RedirectResponse(url=order_page_url(center_id=center_id, oid=order_id, ok=1, added=0), status_code=303)

    wh_ids = sorted({k[0] for k in required_map.keys()})
    item_ids = sorted({k[1] for k in required_map.keys()})
    wh_ph = ','.join(['?'] * len(wh_ids))
    item_ph = ','.join(['?'] * len(item_ids))
    stock_rows = cur.execute(
        f"""
        SELECT warehouse_id, item_id,
               COALESCE(SUM(CASE WHEN movement_type IN ('ENTRADA','IN') THEN qty
                                 WHEN movement_type IN ('SALIDA','OUT') THEN -qty ELSE -qty END),0) stock_qty
          FROM movements
         WHERE center_id=? AND warehouse_id IN ({wh_ph}) AND item_id IN ({item_ph})
         GROUP BY warehouse_id, item_id
        """,
        tuple([center_id] + wh_ids + item_ids),
    ).fetchall()
    stock_map = {(int(r['warehouse_id']), int(r['item_id'])): float(r['stock_qty'] or 0.0) for r in stock_rows}

    existing_rows = cur.execute(
        "SELECT id, warehouse_id, item_id, qty_base, supplier_id FROM order_lines WHERE order_id=?",
        (order_id,),
    ).fetchall()
    existing_map = {(int(r['warehouse_id']), int(r['item_id'])): {'id': int(r['id']), 'qty_base': float(r['qty_base'] or 0.0), 'supplier_id': r['supplier_id']} for r in existing_rows}

    added = 0
    for key, required_qty in required_map.items():
        warehouse_id, item_id = key
        shortage = max(0.0, float(required_qty) - float(stock_map.get(key, 0.0)))
        if shortage <= 0:
            continue
        item = cur.execute("SELECT unit FROM items WHERE id=?", (item_id,)).fetchone()
        base_unit = ((item['unit'] if item else 'ud') or 'ud').strip() or 'ud'
        supplier_id = _suggest_supplier_id(cur, center_id, item_id)
        current = existing_map.get(key)
        if current:
            new_qty = max(float(current['qty_base']), shortage)
            cur.execute(
                "UPDATE order_lines SET qty_base=?, input_unit=?, qty_input=?, supplier_id=COALESCE(supplier_id, ?) WHERE id=? AND order_id=?",
                (new_qty, base_unit, new_qty, supplier_id, int(current['id']), order_id),
            )
        else:
            cur.execute(
                "INSERT INTO order_lines(order_id,warehouse_id,item_id,qty_base,input_unit,qty_input,supplier_id) VALUES(?,?,?,?,?,?,?)",
                (order_id, warehouse_id, item_id, shortage, base_unit, shortage, supplier_id),
            )
            added += 1

    conn.commit(); conn.close()
    return RedirectResponse(
        url=order_page_url(center_id=center_id, oid=order_id, ok=1, added=added),
        status_code=303)


@router.post("/order/{order_id}/add_line_form")
def order_add_line_form(
    order_id: int,
    warehouse_id: int = Form(...),
    item_id: str = Form(""),
    item_query: str = Form(""),
    qty_value: str = Form(""),
    qty_unit: str = Form(""),
    supplier_id: str = Form(""),
):
    conn = db(); cur = conn.cursor()
    o = cur.execute("SELECT center_id,status FROM orders WHERE id=?", (order_id,)).fetchone()
    if not o or o["status"] != "DRAFT":
        conn.close()
        return RedirectResponse(url=order_page_url(oid=order_id, err=1), status_code=303)
    if not _order_has_responsible(cur, order_id):
        conn.close()
        return RedirectResponse(url=order_page_url(center_id=int(o['center_id']), oid=order_id, ord_msg='responsible_required'), status_code=303)
    resolved_item_id = _resolve_item_id(cur, item_id, item_query)
    if not resolved_item_id:
        conn.close()
        return RedirectResponse(url=order_page_url(oid=order_id, err=1), status_code=303)
    item = cur.execute("SELECT unit FROM items WHERE id=?", (int(resolved_item_id),)).fetchone()
    if not item:
        conn.close()
        return RedirectResponse(url=order_page_url(oid=order_id, err=1), status_code=303)
    base_unit = item["unit"]
    iu = (qty_unit or base_unit).strip() or base_unit
    factor = _unit_factor(iu, base_unit)
    qty_input = _parse_float(qty_value, 0.0)
    qty_base = float(qty_input) * float(factor)
    if qty_base <= 0:
        conn.close()
        return RedirectResponse(url=order_page_url(oid=order_id, err=1), status_code=303)
    sid = parse_optional_int(supplier_id)
    cur.execute(
        "INSERT INTO order_lines(order_id,warehouse_id,item_id,qty_base,input_unit,qty_input,supplier_id) VALUES(?,?,?,?,?,?,?)",
        (order_id, int(warehouse_id), int(resolved_item_id), qty_base, iu, float(qty_input), sid))
    conn.commit(); conn.close()
    return RedirectResponse(
        url=order_page_url(center_id=int(o['center_id']), oid=order_id, ok=1),
        status_code=303)


@router.post("/order/{order_id}/update_line/{line_id}")
def order_update_line_form(
    order_id: int, line_id: int,
    qty_value: str = Form(...), qty_unit: str = Form(...), supplier_id: str = Form(""),
):
    conn = db(); cur = conn.cursor()
    o = cur.execute("SELECT center_id,status FROM orders WHERE id=?", (order_id,)).fetchone()
    if not o or o["status"] != "DRAFT":
        conn.close()
        return RedirectResponse(url=order_page_url(oid=order_id, err=1), status_code=303)
    if not _order_has_responsible(cur, order_id):
        conn.close()
        return RedirectResponse(url=order_page_url(center_id=int(o['center_id']), oid=order_id, ord_msg='responsible_required'), status_code=303)
    ln = cur.execute("SELECT id,item_id FROM order_lines WHERE id=? AND order_id=?",
                     (line_id, order_id)).fetchone()
    if not ln:
        conn.close()
        return RedirectResponse(url=order_page_url(oid=order_id, err=1), status_code=303)
    qty_input = _parse_float(qty_value, 0.0)
    if qty_input <= 0:
        conn.close()
        return RedirectResponse(url=order_page_url(center_id=int(o['center_id']), oid=order_id, err=1),
                                status_code=303)
    item = cur.execute("SELECT unit FROM items WHERE id=?", (int(ln["item_id"]),)).fetchone()
    base_unit = (item["unit"] if item else "ud") or "ud"
    iu = (qty_unit or base_unit).strip() or base_unit
    qty_base = float(qty_input) * float(_unit_factor(iu, base_unit))
    sid = parse_optional_int(supplier_id)
    cur.execute("UPDATE order_lines SET qty_base=?,input_unit=?,qty_input=?,supplier_id=? WHERE id=? AND order_id=?",
                (qty_base, iu, float(qty_input), sid, line_id, order_id))
    conn.commit(); conn.close()
    return RedirectResponse(
        url=order_page_url(center_id=int(o['center_id']), oid=order_id, ok=1),
        status_code=303)


@router.post("/order/{order_id}/delete_line/{line_id}")
def order_delete_line_form(order_id: int, line_id: int):
    conn = db(); cur = conn.cursor()
    o = cur.execute("SELECT center_id,status FROM orders WHERE id=?", (order_id,)).fetchone()
    if not o or o["status"] != "DRAFT":
        conn.close()
        return RedirectResponse(url=order_page_url(oid=order_id, err=1), status_code=303)
    if not _order_has_responsible(cur, order_id):
        conn.close()
        return RedirectResponse(url=order_page_url(center_id=int(o['center_id']), oid=order_id, ord_msg='responsible_required'), status_code=303)
    cur.execute("DELETE FROM order_lines WHERE id=? AND order_id=?", (line_id, order_id))
    conn.commit(); conn.close()
    return RedirectResponse(
        url=order_page_url(center_id=int(o['center_id']), oid=order_id), status_code=303)


@router.post("/order/{order_id}/confirm_form")
def order_confirm_form(order_id: int):
    conn = db(); cur = conn.cursor()
    o = cur.execute("SELECT center_id,status FROM orders WHERE id=?", (order_id,)).fetchone()
    if not o or o["status"] != "DRAFT":
        conn.close()
        return RedirectResponse(url=order_page_url(oid=order_id, err=1), status_code=303)
    if not _order_has_responsible(cur, order_id):
        conn.close()
        return RedirectResponse(url=order_page_url(center_id=int(o['center_id']), oid=order_id, ord_msg='responsible_required'), status_code=303)
    ln = cur.execute("SELECT COUNT(*) c FROM order_lines WHERE order_id=?", (order_id,)).fetchone()["c"]
    if not ln:
        conn.close()
        return RedirectResponse(
            url=order_page_url(center_id=int(o['center_id']), oid=order_id, err=1),
            status_code=303)
    cur.execute("UPDATE orders SET status='CONFIRMED' WHERE id=?", (order_id,))
    conn.commit(); conn.close()
    return RedirectResponse(
        url=order_page_url(center_id=int(o['center_id']), oid=order_id, ok=1),
        status_code=303)


@router.post("/order/{order_id}/reopen_form")
def order_reopen_form(order_id: int):
    conn = db(); cur = conn.cursor()
    o = cur.execute("SELECT center_id,status FROM orders WHERE id=?", (order_id,)).fetchone()
    if not o or o["status"] != "CONFIRMED":
        conn.close()
        return RedirectResponse(url=order_page_url(oid=order_id, err=1), status_code=303)
    if not _order_has_responsible(cur, order_id):
        conn.close()
        return RedirectResponse(url=order_page_url(center_id=int(o['center_id']), oid=order_id, ord_msg='responsible_required'), status_code=303)
    cur.execute("UPDATE orders SET status='DRAFT' WHERE id=?", (order_id,))
    conn.commit(); conn.close()
    return RedirectResponse(
        url=order_page_url(center_id=int(o['center_id']), oid=order_id, ok=1),
        status_code=303)



@router.post("/order/{order_id}/delete_form")
def order_delete_form(order_id: int):
    conn = db(); cur = conn.cursor()
    o = cur.execute("SELECT status,center_id FROM orders WHERE id=?", (order_id,)).fetchone()
    if not o or o["status"] != "DRAFT":
        conn.close()
        return RedirectResponse(url=order_page_url(oid=order_id, err=1), status_code=303)
    center_id = int(o["center_id"])
    cur.execute("DELETE FROM order_lines WHERE order_id=?", (order_id,))
    cur.execute("DELETE FROM orders WHERE id=?", (order_id,))
    conn.commit(); conn.close()
    return RedirectResponse(url=order_page_url(center_id=center_id, ok=1, anchor=''), status_code=303)


@router.post("/order/{order_id}/archive_form")
def order_archive_form(order_id: int):
    conn = db(); cur = conn.cursor()
    o = cur.execute("SELECT status,center_id FROM orders WHERE id=?", (order_id,)).fetchone()
    if not o or o["status"] != "CONFIRMED":
        conn.close()
        return RedirectResponse(url=order_page_url(oid=order_id, err=1), status_code=303)
    cur.execute("UPDATE orders SET status='ARCHIVED' WHERE id=?", (order_id,))
    conn.commit(); conn.close()
    return RedirectResponse(url=order_page_url(center_id=int(o['center_id']), ok=1, anchor=''), status_code=303)


@router.post("/order/{order_id}/restore_form")
def order_restore_form(order_id: int):
    conn = db(); cur = conn.cursor()
    o = cur.execute("SELECT status,center_id FROM orders WHERE id=?", (order_id,)).fetchone()
    if not o or o["status"] != "ARCHIVED":
        conn.close()
        return RedirectResponse(url=order_page_url(oid=order_id, err=1), status_code=303)
    cur.execute("UPDATE orders SET status='CONFIRMED' WHERE id=?", (order_id,))
    conn.commit(); conn.close()
    return RedirectResponse(
        url=order_page_url(center_id=int(o['center_id']), oid=order_id, show_archived_orders=1, ok=1),
        status_code=303)


@router.get("/order/{order_id}/print", response_class=HTMLResponse)
def order_print(order_id: int, request: Request):
    conn = db(); cur = conn.cursor()
    od = order_with_lines(cur, int(order_id))
    conn.close()
    if not od:
        return HTMLResponse("Pedido no encontrado", status_code=404)
    lines = od.get("lines") or []
    def _sort_key(line):
        supplier = (line.get("supplier_name") or "~").strip().lower()
        item = (line.get("item_name") or "").strip().lower()
        return (supplier, item)
    lines = sorted(lines, key=_sort_key)

    def esc(s):
        return (s or "").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    def qty_str(l):
        try:
            q = float(l.get("qty_input") or 0)
            u = (l.get("input_unit") or l.get("base_unit") or "").strip()
            return esc(human_qty(q, u))
        except Exception:
            return esc(str(l.get("qty_base") or ""))

    rows = "".join(
        f"<tr><td>{esc(l.get('item_name',''))}</td>"
        f"<td>{esc(l.get('warehouse_name',''))}</td>"
        f"<td>{esc(l.get('supplier_name','') or '—')}</td>"
        f"<td style='text-align:right'>{qty_str(l)}</td></tr>"
        for l in lines)
    html = f"""<!doctype html><html><head><meta charset='utf-8'><title>Pedido #{od['id']}</title>
<style>
  @page {{ size:A4; margin:14mm; }}
  body {{ font-family:-apple-system,BlinkMacSystemFont,Arial,sans-serif; font-size:12px; }}
  h1 {{ font-size:18px; margin:0 0 6px 0; }}
  .meta {{ margin:0 0 12px 0; color:#333; }}
  table {{ width:100%; border-collapse:collapse; }}
  th,td {{ border:1px solid #999; padding:6px; }}
  th {{ background:#f2f2f2; text-align:left; }}
  .print-footer {{ margin-top:auto; padding-top:10mm; text-align:right; font-size:9px; color:#666; }}
</style></head><body>
<h1>Pedido #{od['id']} · {esc(od.get('center_name',''))}</h1>
<div class='meta'>
  <div><b>Estado:</b> {esc(status_label(od.get('status','')))}</div>
  <div><b>Fecha:</b> {esc(fmt_dt(od.get('created_at','')))}</div>
  <div><b>Nota:</b> {esc(od.get('note','') or '—')}</div>
</div>
<table><thead><tr><th>Artículo</th><th>Almacén</th><th>Proveedor</th><th style='text-align:right'>Cantidad</th></tr></thead>
<tbody>{rows}</tbody></table>
<div class='print-footer'><div class='print-logo'><div class='brand'>F&amp;B MVP</div><div>Created by Mauro Ciccarelli</div></div></div>
<script>window.print();</script>
</body></html>"""
    return HTMLResponse(html)
