# ==============================================================================
# BLOQUE STOCK · Movimientos, niveles min/max, artículos
# ==============================================================================
from fastapi import APIRouter, Form, Request
from fastapi.responses import JSONResponse, RedirectResponse
from typing import Optional
from datetime import datetime
import sqlite3

from app.core import (
    db, _retry_db_write, _parse_float, _resolve_item_id, _resolve_item_id_strict,
    ensure_columns, get_unit_factor, normalize_price_to_base,
    upper_name, suggest_item_waste_pct, get_dashboard_data, human_qty, fmt_num,
    preferred_price_unit, preferred_display_qty, get_elaborados_stock, get_production_stocks
)
from app.services.stock_service import create_stock_movement, save_item_minmax
from app.services.stock_queries_service import resolve_item_id_strict, stock_page_url

router = APIRouter()


# ==============================================================================
# MOVIMIENTOS
# ==============================================================================

@router.post("/movement/create_form")
def create_movement_form(
    center_id: int = Form(...),
    warehouse_id: int = Form(...),
    item_id: Optional[str] = Form(None),
    item_query: str = Form(""),
    movement_type: str = Form(...),
    qty_value: str = Form("0"),
    qty_unit: str = Form(...),
    note: str = Form(""),
    after: str = Form("stay"),
):
    resolved_item_id = resolve_item_id_strict(item_id, item_query)
    if not resolved_item_id:
        return RedirectResponse(url=stock_page_url(center_id=center_id, err="1"), status_code=303)

    res = _create_movement_internal(center_id, warehouse_id, int(resolved_item_id),
                                    movement_type, _parse_float(qty_value, 0.0), qty_unit, note)
    if isinstance(res, JSONResponse) and res.status_code >= 400:
        return RedirectResponse(url=stock_page_url(center_id=center_id, err="1"), status_code=303)

    if (after or "").lower() == "exit":
        return RedirectResponse(url=f"/?page=inicio&center_id={center_id}&mv_ok=1", status_code=303)
    return RedirectResponse(url=stock_page_url(center_id=center_id, ok="mv_ok"), status_code=303)


@router.post("/stock/initial_load_form")
def stock_initial_load_form(
    center_id: int = Form(...),
    warehouse_id: int = Form(...),
    item_id: Optional[str] = Form(None),
    item_query: str = Form(""),
    qty_value: str = Form("0"),
    qty_unit: str = Form(...),
):
    return create_movement_form(
        center_id=center_id, warehouse_id=warehouse_id,
        item_id=item_id, item_query=item_query,
        movement_type="ENTRADA", qty_value=qty_value,
        qty_unit=qty_unit, note="CARGA INICIAL", after="stay")


@router.post("/api/movement")
def create_movement(
    center_id: int = Form(...),
    warehouse_id: int = Form(...),
    item_id: int = Form(...),
    movement_type: str = Form(...),
    qty_value: float = Form(...),
    qty_unit: str = Form(...),
    note: str = Form(""),
):
    return _create_movement_internal(center_id, warehouse_id, item_id, movement_type,
                                     qty_value, qty_unit, note)


def _create_movement_internal(center_id, warehouse_id, item_id, movement_type, qty_value, qty_unit, note):
    return create_stock_movement(center_id, warehouse_id, item_id, movement_type, qty_value, qty_unit, note)


# ==============================================================================
# MIN/MAX
# ==============================================================================

@router.post("/item/{item_id}/minmax_form")
def update_minmax_form(
    item_id: int,
    min_qty: str = Form("0"),
    max_qty: str = Form("0"),
    min_unit: str = Form(""),
    max_unit: str = Form(""),
    center_id: str = Form(""),
    warehouse_id: str = Form(""),
):
    def _num(s: str) -> float:
        s = (s or "").strip().replace(" ", "").replace(",", ".")
        return float(s) if s else 0.0

    conn = db()
    cur = conn.cursor()
    ensure_columns(cur)
    conn.close()

    try:
        save_item_minmax(item_id, _num(min_qty), _num(max_qty), min_unit, max_unit, center_id, warehouse_id)
    except Exception:
        return RedirectResponse(url=f"/?page=stock&minmax_item={item_id}&err=1", status_code=303)

    redirect_q = f"&minmax_center={int(center_id)}&minmax_wh={int(warehouse_id)}" if str(center_id).isdigit() and str(warehouse_id).isdigit() else ""
    return RedirectResponse(url=f"/?page=stock&minmax_item={item_id}{redirect_q}&ok=1", status_code=303)


@router.post("/api/item/{item_id}/minmax")
def update_minmax(
    item_id: int,
    min_qty: float = Form(...),
    max_qty: float = Form(...),
    min_unit: str = Form(""),
    max_unit: str = Form(""),
    center_id: str = Form(""),
    warehouse_id: str = Form(""),
):
    conn = db()
    cur = conn.cursor()
    ensure_columns(cur)
    conn.close()
    try:
        save_item_minmax(item_id, float(min_qty), float(max_qty), min_unit, max_unit, center_id, warehouse_id)
    except LookupError:
        return JSONResponse({"ok": False, "error": "Artículo inválido"}, status_code=400)
    except Exception:
        return JSONResponse({"ok": False, "error": "Rango o unidad inválidos"}, status_code=400)
    return {"ok": True, "message": "Mín/Máx guardados"}


# ==============================================================================
# PRECIO ARTÍCULO
# ==============================================================================

@router.post("/item/{item_id}/price_form")
def update_item_price_form(item_id: int, current_price: str = Form("0")):
    conn = db()
    cur = conn.cursor()
    cur.execute("UPDATE items SET current_price=? WHERE id=?",
                (_parse_float(current_price, 0.0), item_id))
    conn.commit()
    conn.close()
    return RedirectResponse(url="/?page=admin&price_ok=1", status_code=303)


# ==============================================================================
# API STOCKS / ITEMS
# ==============================================================================

@router.get("/api/stocks")
def api_stocks(center_id: Optional[int] = None):
    centers, warehouses, items, stocks, summary, recipes = get_dashboard_data(center_id)
    stocks_json = [{k: s[k] for k in s.keys()} for s in stocks]
    return {"ok": True, "stocks": stocks_json, "summary": summary}


@router.get("/api/items")
def api_items(q: str = "", limit: int = 20):
    qn = (q or "").strip()
    limit = max(1, min(int(limit or 20), 50))
    conn = db()
    cur = conn.cursor()
    if not qn:
        rows = cur.execute("SELECT id,name,unit,COALESCE(stock_area,'') stock_area FROM items ORDER BY name LIMIT ?", (limit,)).fetchall()
    else:
        rows = cur.execute(
            """SELECT id,name,unit,COALESCE(stock_area,'') stock_area,
                      CASE WHEN lower(name) LIKE lower(?) THEN 0 ELSE 1 END AS rank
                 FROM items WHERE lower(name) LIKE lower(?)
                 ORDER BY rank, name LIMIT ?""",
            (qn + "%", "%" + qn + "%", limit)).fetchall()
    conn.close()
    return {"ok": True, "items": [{"id": r["id"], "name": r["name"], "unit": r["unit"], "stock_area": r["stock_area"]} for r in rows]}


@router.get("/api/items/search")
def search_items(q: str = "", limit: int = 50):
    conn = db()
    cur = conn.cursor()
    qn = q.strip().lower()
    try:
        lim = max(1, min(int(limit or 50), 100))
    except Exception:
        lim = 50
    if not qn:
        rows = cur.execute("SELECT id,name,unit,COALESCE(stock_area,'') stock_area FROM items ORDER BY name LIMIT ?", (lim,)).fetchall()
    else:
        rows = cur.execute(
            "SELECT id,name,unit,COALESCE(stock_area,'') stock_area FROM items WHERE LOWER(name) LIKE ? ORDER BY CASE WHEN LOWER(name) LIKE ? THEN 0 ELSE 1 END, name LIMIT ?",
            (f"%{qn}%", f"{qn}%", lim)).fetchall()
    conn.close()
    return {"ok": True, "items": [{"id": r["id"], "name": r["name"], "unit": r["unit"], "stock_area": r["stock_area"]} for r in rows]}


@router.get("/api/elaborados")
def api_elaborados(center_id: int = 0):
    """Devuelve el stock de elaborados con porciones calculadas."""
    try:
        conn = db(); cur = conn.cursor()
        data = get_production_stocks(cur, center_id if center_id else None)
        conn.close()
        return {"ok": True, "elaborados": data}
    except Exception as e:
        return JSONResponse({"ok": False, "error": str(e)}, status_code=500)
