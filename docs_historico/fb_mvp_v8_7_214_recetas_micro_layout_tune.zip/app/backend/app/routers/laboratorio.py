# ==============================================================================
# BLOQUE LABORATORIO · Artículos y proveedores (alta, edición)
# ==============================================================================
from fastapi import APIRouter, Form, Request
from fastapi.responses import JSONResponse, RedirectResponse
from datetime import datetime

from app.core import db, _provider_has_links, _provider_archive_name


def _item_has_links(cur, item_id: int) -> bool:
    checks = (
        ("recipe_ingredients", "item_id"),
        ("movements", "item_id"),
        ("supplier_item_prices", "item_id"),
        ("production_lines", "item_id"),
        ("order_lines", "item_id"),
        ("receipt_lines", "item_id"),
        ("inventory_counts", "item_id"),
    )
    for table, col in checks:
        try:
            row = cur.execute(f"SELECT COUNT(*) c FROM {table} WHERE {col}=?", (int(item_id),)).fetchone()
            if row and int(row["c"] or 0) > 0:
                return True
        except Exception:
            continue
    return False

from app.services.laboratory_service import normalize_item_payload, normalize_supplier_payload

router = APIRouter()


# ==============================================================================
# ARTÍCULOS
# ==============================================================================

@router.post("/item/create_form")
def item_create_form(
    name: str = Form(...),
    unit: str = Form(...),
    current_price: str = Form("0"),
    current_price_unit: str = Form(""),
    waste_default_pct: str = Form(""),
    stock_area: str = Form(""),
    supplier_id: int = Form(0),
    return_page: str = Form("admin"),
    lab_note: str = Form(""),
):
    payload = normalize_item_payload(name, unit, current_price, current_price_unit, waste_default_pct, stock_area)

    conn = db(); cur = conn.cursor()
    dup = cur.execute("SELECT id FROM items WHERE lower(trim(name))=lower(trim(?)) AND unit=?",
                      (payload["name"], payload["unit"])).fetchone()
    if dup:
        conn.close()
        return RedirectResponse(url="/?page=admin&err=item_dup", status_code=303)

    cur.execute("INSERT INTO items(name,unit,min_qty,max_qty,current_price,waste_default_pct,stock_area) VALUES(?,?,?,?,?,?,?)",
                (payload["name"], payload["unit"], 0, 0, payload["current_price"], payload["waste_default_pct"], payload["stock_area"]))
    item_id = int(cur.lastrowid or 0)

    if int(supplier_id or 0) > 0 and item_id > 0:
        now = datetime.utcnow().isoformat()
        try:
            cur.execute(
                """INSERT INTO supplier_item_prices(supplier_id,item_id,center_id,price_per_purchase,
                   purchase_unit,purchase_to_base_factor,is_preferred,updated_at) VALUES(?,?,?,?,?,?,?,?)""",
                (int(supplier_id), int(item_id), None, payload["current_price"],
                 payload["current_price_unit"], 1.0, 1, now))
        except Exception:
            pass

    conn.commit(); conn.close()
    page_target = "laboratorio" if (return_page or "").strip().lower() == "laboratorio" else "admin"
    ok_qs = "lab=item_created" if page_target == "laboratorio" else "ok=1"
    return RedirectResponse(url=f"/?page={page_target}&{ok_qs}", status_code=303)


@router.post("/item/{item_id}/update_form")
def item_update_form(
    request: Request,
    item_id: int,
    name: str = Form(...),
    unit: str = Form(...),
    current_price: str = Form("0"),
    current_price_unit: str = Form(""),
    waste_default_pct: str = Form(""),
    stock_area: str = Form(""),
    ajax: int = Form(0),
    return_query: str = Form(""),
):
    payload = normalize_item_payload(name, unit, current_price, current_price_unit, waste_default_pct, stock_area)

    conn = db(); cur = conn.cursor()
    dup = cur.execute("SELECT id FROM items WHERE lower(trim(name))=lower(trim(?)) AND unit=? AND id<>?",
                      (payload["name"], payload["unit"], item_id)).fetchone()
    if dup:
        conn.close()
        if int(ajax or 0):
            return JSONResponse({"ok": False, "error": "item_dup"}, status_code=409)
        return RedirectResponse(url="/?page=admin&err=item_dup", status_code=303)

    cur.execute("UPDATE items SET name=?,unit=?,current_price=?,waste_default_pct=?,stock_area=? WHERE id=?",
                (payload["name"], payload["unit"], payload["current_price"], payload["waste_default_pct"], payload["stock_area"], item_id))
    conn.commit(); conn.close()
    if int(ajax or 0):
        return JSONResponse({"ok": True, "item_id": int(item_id), "stock_area": payload["stock_area"], "name": payload["name"]})
    q = (return_query or '').strip()
    if q:
        return RedirectResponse(url=f"/?page=admin&{q}&ok=1#item-{int(item_id)}", status_code=303)
    return RedirectResponse(url=f"/?page=admin&ok=1#item-{int(item_id)}", status_code=303)


# ==============================================================================
# PROVEEDORES
# ==============================================================================

@router.post("/supplier/create_form")
def supplier_create_form(
    name: str = Form(...),
    phone: str = Form(""),
    email: str = Form(""),
):
    payload = normalize_supplier_payload(name, phone, email)
    conn = db(); cur = conn.cursor()
    cur.execute("INSERT INTO suppliers(name,phone,email,is_active) VALUES(?,?,?,1)",
                (payload["name"], payload["phone"], payload["email"]))
    conn.commit(); conn.close()
    return RedirectResponse(url="/?page=admin&ok=1", status_code=303)


@router.post("/supplier/{supplier_id}/update_form")
def supplier_update_form(
    supplier_id: int,
    name: str = Form(...),
    phone: str = Form(""),
    email: str = Form(""),
    is_active: int = Form(1),
):
    payload = normalize_supplier_payload(name, phone, email)
    conn = db(); cur = conn.cursor()
    cur.execute("UPDATE suppliers SET name=?,phone=?,email=?,is_active=? WHERE id=?",
                (payload["name"], payload["phone"], payload["email"],
                 1 if int(is_active) else 0, supplier_id))
    conn.commit(); conn.close()
    return RedirectResponse(url="/?page=admin&ok=1", status_code=303)


@router.post("/supplier/{supplier_id}/delete_form")
def supplier_delete_form(supplier_id: int):
    conn = db(); cur = conn.cursor()
    cur.execute("UPDATE suppliers SET is_active=0 WHERE id=?", (supplier_id,))
    conn.commit(); conn.close()
    return RedirectResponse(url="/?page=admin&ok=1", status_code=303)


@router.post("/provider/{provider_id}/delete_form")
def provider_delete_form(provider_id: int, center_id: int = Form(0)):
    conn = db(); cur = conn.cursor()
    sup = cur.execute("SELECT id,name FROM suppliers WHERE id=?", (int(provider_id),)).fetchone()
    if not sup:
        conn.close()
        return RedirectResponse(url=f"/?page=admin&center_id={int(center_id)}&provider_err=not_found",
                                status_code=303)
    try:
        if _provider_has_links(cur, int(provider_id)):
            cur.execute("UPDATE suppliers SET name=?,is_active=0 WHERE id=?",
                        (_provider_archive_name(sup["name"]), int(provider_id)))
            conn.commit(); conn.close()
            return RedirectResponse(url=f"/?page=admin&center_id={int(center_id)}&provider_archived=1",
                                    status_code=303)
        cur.execute("DELETE FROM suppliers WHERE id=?", (int(provider_id),))
        conn.commit(); conn.close()
        return RedirectResponse(url=f"/?page=admin&center_id={int(center_id)}&provider_deleted=1",
                                status_code=303)
    except Exception:
        conn.close()
        return RedirectResponse(url=f"/?page=admin&center_id={int(center_id)}&provider_err=delete_failed",
                                status_code=303)


# ==============================================================================
# API PROVEEDORES / PRECIOS
# ==============================================================================

@router.post("/api/suppliers")
def api_create_supplier(name: str = Form(...), phone: str = Form(""), email: str = Form("")):
    payload = normalize_supplier_payload(name, phone, email)
    if not payload["name"]:
        return JSONResponse({"ok": False, "error": "Nombre requerido"}, status_code=400)
    conn = db(); cur = conn.cursor()
    cur.execute("INSERT INTO suppliers(name,phone,email,is_active) VALUES(?,?,?,1)",
                (payload["name"], payload["phone"], payload["email"]))
    conn.commit(); conn.close()
    return {"ok": True, "message": "Proveedor creado"}


@router.post("/api/item/{item_id}/supplier_price")
def api_set_supplier_price(
    item_id: int,
    supplier_id: int = Form(...),
    price_per_purchase: float = Form(...),
    purchase_unit: str = Form(...),
    purchase_to_base_factor: float = Form(...),
    is_preferred: int = Form(0),
    center_id: int = Form(0),
):
    if price_per_purchase < 0 or purchase_to_base_factor <= 0:
        return JSONResponse({"ok": False, "error": "Precio/factor inválidos"}, status_code=400)
    conn = db(); cur = conn.cursor()
    now = datetime.utcnow().isoformat()
    c_id = None if int(center_id) == 0 else int(center_id)
    if int(is_preferred) == 1:
        cur.execute("UPDATE supplier_item_prices SET is_preferred=0 WHERE item_id=? AND COALESCE(center_id,0)=COALESCE(?,0)",
                    (item_id, c_id))
    cur.execute(
        """INSERT INTO supplier_item_prices(supplier_id,item_id,center_id,price_per_purchase,
           purchase_unit,purchase_to_base_factor,is_preferred,updated_at) VALUES(?,?,?,?,?,?,?,?)""",
        (supplier_id, item_id, c_id, price_per_purchase, purchase_unit,
         purchase_to_base_factor, int(is_preferred), now))
    conn.commit(); conn.close()
    return {"ok": True, "message": "Precio guardado"}


@router.post("/item/{item_id}/delete_form")
def item_delete_form(item_id: int):
    conn = db(); cur = conn.cursor()
    item = cur.execute("SELECT id,name FROM items WHERE id=?", (int(item_id),)).fetchone()
    if not item:
        conn.close()
        return RedirectResponse(url="/?page=admin&err=item_not_found", status_code=303)
    if _item_has_links(cur, int(item_id)):
        conn.close()
        return RedirectResponse(url=f"/?page=admin&err=item_has_links#item-{int(item_id)}", status_code=303)
    cur.execute("DELETE FROM item_location_prefs WHERE item_id=?", (int(item_id),))
    cur.execute("DELETE FROM items WHERE id=?", (int(item_id),))
    conn.commit(); conn.close()
    return RedirectResponse(url="/?page=admin&ok=1", status_code=303)
