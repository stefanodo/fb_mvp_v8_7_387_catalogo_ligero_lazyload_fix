from fastapi import APIRouter, Form
from fastapi.responses import RedirectResponse
from datetime import datetime

from app.core import db, ensure_columns

router = APIRouter()


def _allowed_inventory_modes_for_warehouse(warehouse_name: str | None):
    n = (warehouse_name or '').strip().lower()
    if n in ('economato',):
        return {'limpieza', 'libres'}
    if n in ('cocina', 'camara', 'cámara'):
        return {'materias_primas', 'producciones', 'libres'}
    return {'materias_primas', 'producciones', 'limpieza', 'libres'}


def _redirect(session_id: int, center_id: int, mode: str, family: str, msg: str = ""):
    extra = f"&inv_msg={msg}" if msg else ""
    return RedirectResponse(
        url=f"/?page=inventario&center_id={int(center_id or 0)}&inv_session_id={int(session_id)}&inv_mode={mode}&inv_family={family}{extra}",
        status_code=303,
    )


@router.post('/inventory/session/create_form')
def inventory_session_create_form(
    center_id: int = Form(0),
    warehouse_id: int = Form(0),
    session_type: str = Form('MIXTO'),
    responsible_user_id: int = Form(0),
    note: str = Form(''),
):
    conn = db(); cur = conn.cursor(); ensure_columns(cur)
    rid = int(responsible_user_id or 0)
    if rid <= 0:
        conn.close()
        return _redirect(0, center_id, 'materias_primas', 'verduras', 'responsible_required')
    resp = cur.execute("SELECT name FROM users WHERE id=? AND is_active=1", (rid,)).fetchone()
    if not resp:
        conn.close()
        return _redirect(0, center_id, 'materias_primas', 'verduras', 'responsible_required')
    cur.execute(
        "INSERT INTO inventory_sessions(center_id,warehouse_id,session_type,status,created_at,note,responsible_user_id,responsible_name) VALUES(?,?,?,?,?,?,?,?)",
        (int(center_id or 0), int(warehouse_id or 0), (session_type or 'MIXTO').upper()[:20], 'DRAFT', datetime.utcnow().isoformat(), (note or '').strip(), rid, (resp['name'] or '').strip()),
    )
    sid = int(cur.lastrowid or 0)
    conn.commit(); conn.close()
    return _redirect(sid, center_id, 'materias_primas', 'verduras', 'session_created')


@router.post('/inventory/session/update_form')
def inventory_session_update_form(
    session_id: int = Form(...),
    center_id: int = Form(0),
    warehouse_id: int = Form(0),
    responsible_user_id: int = Form(0),
    status: str = Form('COUNTING'),
    note: str = Form(''),
    inv_mode: str = Form('materias_primas'),
    inv_family: str = Form('verduras'),
):
    conn = db(); cur = conn.cursor(); ensure_columns(cur)
    rid = int(responsible_user_id or 0)
    if rid <= 0:
        conn.close()
        return _redirect(session_id, center_id, inv_mode, inv_family, 'responsible_required')
    resp = cur.execute("SELECT name FROM users WHERE id=? AND is_active=1", (rid,)).fetchone()
    if not resp:
        conn.close()
        return _redirect(session_id, center_id, inv_mode, inv_family, 'responsible_required')
    cur.execute(
        "UPDATE inventory_sessions SET warehouse_id=?, responsible_user_id=?, responsible_name=?, status=?, note=? WHERE id=?",
        (int(warehouse_id or 0), rid, (resp['name'] or '').strip(), (status or 'COUNTING').upper()[:20], (note or '').strip(), int(session_id)),
    )
    conn.commit(); conn.close()
    return _redirect(session_id, center_id, inv_mode, inv_family, 'session_saved')


@router.post('/inventory/counts/save_form')
def inventory_counts_save_form(
    session_id: int = Form(...),
    center_id: int = Form(0),
    inv_mode: str = Form('materias_primas'),
    inv_family: str = Form('verduras'),
    source_type: str = Form('raw'),
    item_id: list[str] = Form([]),
    item_name: list[str] = Form([]),
    warehouse_id: list[str] = Form([]),
    theoretical_qty: list[str] = Form([]),
    physical_qty: list[str] = Form([]),
    count_unit: list[str] = Form([]),
    line_note: list[str] = Form([]),
    is_checked: list[str] = Form([]),
    unit_cost_snapshot: list[str] = Form([]),
):
    conn = db(); cur = conn.cursor(); ensure_columns(cur)
    ses = cur.execute("SELECT responsible_user_id,responsible_name FROM inventory_sessions WHERE id=?", (int(session_id),)).fetchone()
    if not ses or (int(ses['responsible_user_id'] or 0) <= 0 and not str(ses['responsible_name'] or '').strip()):
        conn.close()
        return _redirect(session_id, center_id, inv_mode, inv_family, 'responsible_required')
    fam = (inv_family or '').strip().lower()
    stype = (source_type or 'raw').strip().lower()
    cur.execute("UPDATE inventory_sessions SET status='COUNTING' WHERE id=? AND status='DRAFT'", (int(session_id),))
    total = max(len(item_id), len(item_name), len(warehouse_id), len(theoretical_qty), len(physical_qty), len(count_unit), len(line_note), len(unit_cost_snapshot))
    checked_set = {str(v) for v in (is_checked or [])}
    for idx in range(total):
        iid = int((item_id[idx] if idx < len(item_id) and str(item_id[idx]).strip().isdigit() else 0))
        iname = (item_name[idx] if idx < len(item_name) else '').strip()
        whid = int((warehouse_id[idx] if idx < len(warehouse_id) and str(warehouse_id[idx]).strip().isdigit() else 0))
        tqty = float(str(theoretical_qty[idx]).replace(',', '.') or 0) if idx < len(theoretical_qty) else 0.0
        pqty_raw = (physical_qty[idx] if idx < len(physical_qty) else '').strip()
        pqty = float(pqty_raw.replace(',', '.')) if pqty_raw else 0.0
        cunit = (count_unit[idx] if idx < len(count_unit) else '').strip() or 'ud'
        note = (line_note[idx] if idx < len(line_note) else '').strip()
        cost = float(str(unit_cost_snapshot[idx]).replace(',', '.') or 0) if idx < len(unit_cost_snapshot) else 0.0
        checked = 1 if str(idx) in checked_set or pqty_raw != '' else 0
        existing = cur.execute(
            "SELECT id FROM inventory_counts WHERE session_id=? AND source_type=? AND item_id=? AND family_key=? AND warehouse_id=?",
            (int(session_id), stype, int(iid), fam, int(whid)),
        ).fetchone()
        payload = (int(session_id), stype, int(iid), iname, fam, int(whid), float(tqty), float(pqty), cunit, int(checked), note, float(cost))
        if existing:
            cur.execute(
                "UPDATE inventory_counts SET item_name=?, theoretical_qty=?, physical_qty=?, count_unit=?, is_checked=?, note=?, unit_cost_snapshot=? WHERE id=?",
                (iname, float(tqty), float(pqty), cunit, int(checked), note, float(cost), int(existing['id'])),
            )
        else:
            cur.execute(
                "INSERT INTO inventory_counts(session_id,source_type,item_id,item_name,family_key,warehouse_id,theoretical_qty,physical_qty,count_unit,is_checked,note,unit_cost_snapshot) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                payload,
            )
    conn.commit(); conn.close()
    return _redirect(session_id, center_id, inv_mode, inv_family, 'block_saved')


@router.post('/inventory/free/add_form')
def inventory_free_add_form(
    session_id: int = Form(...),
    center_id: int = Form(0),
    inv_mode: str = Form('libres'),
    inv_family: str = Form('libres'),
    warehouse_id: int = Form(0),
    free_name: str = Form(...),
    free_block: str = Form('materias_primas'),
    free_family: str = Form('otros'),
    free_qty: str = Form('0'),
    free_unit: str = Form('ud'),
    free_note: str = Form(''),
    free_cost: str = Form('0'),
):
    name = (free_name or '').strip()
    if not name:
        return _redirect(session_id, center_id, inv_mode, inv_family, 'free_empty')
    block = (free_block or 'materias_primas').strip().lower()
    family = (free_family or '').strip().lower()
    if block not in {'materias_primas','producciones','limpieza'}:
        block = 'materias_primas'
    if block == 'limpieza':
        family = 'limpieza'
    elif not family:
        family = 'otros'
    family_key = f"{block}:{family}"
    conn = db(); cur = conn.cursor(); ensure_columns(cur)
    cur.execute(
        "INSERT INTO inventory_counts(session_id,source_type,item_id,item_name,family_key,warehouse_id,theoretical_qty,physical_qty,count_unit,is_checked,note,unit_cost_snapshot) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
        (
            int(session_id), 'free', 0, name.upper()[:160], family_key, int(warehouse_id or 0), 0.0,
            float(str(free_qty or '0').replace(',', '.')), (free_unit or 'ud').strip()[:20], 1,
            (free_note or '').strip(), float(str(free_cost or '0').replace(',', '.')),
        ),
    )
    cur.execute("UPDATE inventory_sessions SET status='COUNTING' WHERE id=? AND status='DRAFT'", (int(session_id),))
    conn.commit(); conn.close()
    return _redirect(session_id, center_id, inv_mode, inv_family, 'free_added')
