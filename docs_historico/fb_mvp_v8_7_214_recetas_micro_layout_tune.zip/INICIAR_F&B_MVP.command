#!/bin/bash
set -euo pipefail
DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$DIR"

xattr -dr com.apple.quarantine "$DIR" 2>/dev/null || true
chmod +x "$DIR"/*.command 2>/dev/null || true

APP_DIR="$DIR/backend"
HOST="0.0.0.0"
PORT="8000"
URL="http://127.0.0.1:${PORT}"
LOCAL_IP="$(ipconfig getifaddr en0 2>/dev/null || ipconfig getifaddr en1 2>/dev/null || true)"
if [ -n "$LOCAL_IP" ]; then
  LAN_URL="http://${LOCAL_IP}:${PORT}"
else
  LAN_URL=""
fi
RUNTIME_DIR="$APP_DIR/runtime"
mkdir -p "$RUNTIME_DIR"

if lsof -iTCP:${PORT} -sTCP:LISTEN >/dev/null 2>&1; then
  echo "El puerto ${PORT} ya está en uso. Cierra otras ventanas del servidor (Control+C) y vuelve a ejecutar."
  exit 1
fi

cd "$APP_DIR"
python3 -m ensurepip --upgrade >/dev/null 2>&1 || true
python3 -m pip install --user --upgrade pip >/dev/null 2>&1 || true
python3 -m pip install --user -r requirements.txt || {
  echo "No se pudieron instalar las dependencias automáticamente."
  echo "Revisa tu conexión a internet y vuelve a ejecutar este script."
  exit 1
}
cd "$DIR"

echo "Iniciando F&B MVP en ${URL} ..."
if [ -n "$LAN_URL" ]; then
  echo "Acceso móvil/red local: ${LAN_URL}"
fi
python3 -m uvicorn app.main:app --host ${HOST} --port ${PORT} --app-dir "$APP_DIR" &
SERVER_PID=$!
cleanup() {
  if kill -0 "$SERVER_PID" >/dev/null 2>&1; then
    kill "$SERVER_PID" >/dev/null 2>&1 || true
  fi
}
trap cleanup EXIT INT TERM

OPENED=0
for i in $(seq 1 60); do
  if python3 - <<PY2 >/dev/null 2>&1
import urllib.request
urllib.request.urlopen('${URL}', timeout=1)
PY2
  then
    if [ "$OPENED" -eq 0 ]; then
      open -a Safari "$URL" >/dev/null 2>&1 || open "$URL" >/dev/null 2>&1 || true
      OPENED=1
      echo "Servidor listo. Se abrió ${URL}"
      if [ -n "$LAN_URL" ]; then echo "Móvil: ${LAN_URL}"; fi
    fi
    break
  fi
  sleep 1
done

if [ "$OPENED" -eq 0 ]; then
  echo "Servidor arrancado, pero el navegador no se abrió automáticamente."
  echo "Abre manualmente: ${URL}"
  if [ -n "$LAN_URL" ]; then echo "Móvil: ${LAN_URL}"; fi
fi

wait "$SERVER_PID"
