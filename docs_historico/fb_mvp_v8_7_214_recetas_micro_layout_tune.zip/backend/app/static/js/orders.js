// orders.js — ayuda ligera de selección de artículos en pedidos
(function(){
  function debounce(fn, ms){ let t; return (...args)=>{ clearTimeout(t); t=setTimeout(()=>fn(...args), ms); }; }
  async function fetchItems(q){
    const res = await fetch('/api/items/search?q=' + encodeURIComponent(q || '') + '&limit=24', {headers:{'Accept':'application/json'}});
    const js = await res.json();
    return (js && js.items) ? js.items : [];
  }
  function setUnit(form, unit){
    const sel = form && form.querySelector('select[name="qty_unit"]');
    if(!sel) return;
    const u = String(unit || 'ud').toLowerCase();
    if(u === 'g'){ sel.innerHTML = '<option value="g">g</option><option value="kg">kg</option>'; sel.value='g'; return; }
    if(u === 'ml'){ sel.innerHTML = '<option value="g">g</option><option value="kg">kg</option>'; sel.value='g'; return; }
    if(u === 'kg' || u === 'l'){ sel.innerHTML = '<option value="g">g</option><option value="kg">kg</option>'; sel.value='kg'; return; }
    sel.innerHTML = `<option value="${u}">${u}</option>`;
    sel.value = u;
  }
  function currentBlock(form){
    const checked = form && form.querySelector('input[name="order_block_ui_manual"]:checked');
    return checked ? String(checked.value || 'fresh').toLowerCase() : 'fresh';
  }
  function areaMatchesBlock(stockArea, block){
    const a = String(stockArea || '').trim().toLowerCase();
    const b = String(block || 'fresh').trim().toLowerCase();
    if(b === 'free' || b === 'all' || b === 'libres') return true;
    if(b === 'fresh') return a === 'fresh' || a === 'frescos';
    if(b === 'dry') return a === 'dry' || a === 'secos';
    if(b === 'clean') return a === 'clean' || a === 'limpieza';
    return true;
  }
  function sortItems(items, q){
    const qq = String(q || '').trim().toLowerCase();
    return (items || []).slice().sort((a,b)=>{
      const an = String(a.name||'').toLowerCase();
      const bn = String(b.name||'').toLowerCase();
      const as = an.startsWith(qq) ? 0 : 1;
      const bs = bn.startsWith(qq) ? 0 : 1;
      return as - bs || an.localeCompare(bn);
    });
  }
  function wire(form){
    if(!form || form.__orderSmartWired) return; form.__orderSmartWired = true;
    const input = form.querySelector('.order-item-query');
    const hidden = form.querySelector('input[name="item_id"][data-smart-item-id]');
    const results = form.querySelector('.order-item-results');
    if(!input || !hidden || !results) return;
    let last='';
    function hide(){ results.innerHTML=''; results.style.display='none'; }
    function choose(it){
      input.value = it.name + ' [#' + it.id + ']';
      hidden.value = String(it.id || '');
      setUnit(form, it.unit);
      hide();
    }
    function resetIfBlockChanges(){
      hidden.value = '';
      if(/\[#\d+\]\s*$/.test(input.value||'')) input.value = '';
      hide();
      if((input.value || '').trim().length > 0) search();
    }
    const search = debounce(async ()=>{
      const q = (input.value || '').trim();
      hidden.value = '';
      if(q.length < 1){ hide(); return; }
      last = q;
      try{
        const block = currentBlock(form);
        let items = await fetchItems(q);
        if(last !== q) return;
        items = sortItems(items, q).filter(it => areaMatchesBlock(it.stock_area, block)).slice(0, 12);
        if(!items.length){
          results.innerHTML = '<div class="order-empty-search">No hay artículos en este bloque. Usa <b>Libres</b> para ver todo.</div>';
          results.style.display='block';
          return;
        }
        results.innerHTML = items.map(it => `<button type="button" data-id="${it.id}" data-name="${String(it.name||'').replace(/"/g,'&quot;')}" data-unit="${String(it.unit||'').replace(/"/g,'&quot;')}"><span>${it.name}</span><small>${it.unit||'ud'} · ${it.stock_area||'-'}</small></button>`).join('');
        results.style.display='block';
      }catch(_){ hide(); }
    }, 120);
    input.addEventListener('input', search);
    input.addEventListener('focus', search);
    input.addEventListener('keydown', e=>{
      if(e.key === 'Enter'){
        const first = results.querySelector('button[data-id]');
        if(first){ e.preventDefault(); first.click(); }
      }
    });
    form.querySelectorAll('input[name="order_block_ui_manual"]').forEach(r=>r.addEventListener('change', resetIfBlockChanges));
    results.addEventListener('mousedown', e=>e.preventDefault());
    results.addEventListener('click', e=>{
      const btn = e.target.closest('button[data-id]'); if(!btn) return;
      choose({id:btn.dataset.id, name:btn.dataset.name, unit:btn.dataset.unit});
    });
    form.addEventListener('submit', ()=>{
      const m = /\[#(\d+)\]\s*$/.exec(input.value || '');
      if(m){ hidden.value = m[1]; return; }
      const raw = String(input.value || '').trim().toLowerCase();
      const exactBtn = Array.from(results.querySelectorAll('button[data-id]')).find(btn => String(btn.dataset.name || '').trim().toLowerCase() === raw);
      if(exactBtn) hidden.value = exactBtn.dataset.id || '';
    });
    document.addEventListener('click', e=>{ if(e.target!==input && !results.contains(e.target)) hide(); });
  }
  document.querySelectorAll('form[action*="/add_line_form"]').forEach(wire);
  document.addEventListener('focusin', e=>{ const f=e.target && e.target.closest && e.target.closest('form[action*="/add_line_form"]'); if(f) wire(f); });
})();
