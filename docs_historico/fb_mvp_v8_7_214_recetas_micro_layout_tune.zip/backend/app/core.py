# ==============================================================================
# BLOQUE CORE · DB, utilidades compartidas y helpers globales
# ==============================================================================
import re
import sqlite3
import unicodedata
import os
import shutil
import csv
import time
import calendar
from pathlib import Path
from typing import Optional
from datetime import datetime, timezone
from zoneinfo import ZoneInfo
from difflib import SequenceMatcher

from PIL import Image, ImageOps

try:
    from paddleocr import PaddleOCR  # type: ignore
except Exception:
    PaddleOCR = None

_PADDLE_OCR = None
APP_TZ = ZoneInfo("Europe/Madrid")

# --- Rutas de la aplicación ---
APP_DIR = Path(__file__).resolve().parent
ROOT_DIR = APP_DIR.parent
USER_HOME = Path.home()
_DEFAULT_SHARED_RUNTIME = USER_HOME / "Documents" / "F&B_MAC_RUNTIME"
_RUNTIME_ENV = os.getenv("FB_MVP_RUNTIME_DIR", "").strip()
RUNTIME_DIR = Path(_RUNTIME_ENV).expanduser() if _RUNTIME_ENV else _DEFAULT_SHARED_RUNTIME
RUNTIME_DIR.mkdir(parents=True, exist_ok=True)
BUNDLED_RUNTIME_DIR = ROOT_DIR / "runtime"
BUNDLED_DB_PATH = BUNDLED_RUNTIME_DIR / "fb_mvp_v8.db"
DB_PATH = RUNTIME_DIR / "fb_mvp_v8.db"
if not DB_PATH.exists() and BUNDLED_DB_PATH.exists():
    try:
        shutil.copy2(BUNDLED_DB_PATH, DB_PATH)
    except Exception:
        pass
UPLOADS_DIR = RUNTIME_DIR / "uploads"
UPLOADS_DIR.mkdir(parents=True, exist_ok=True)
SEED_DIR = APP_DIR / "data"
SEED_ITEMS_CSV = SEED_DIR / "seed_items_152.csv"
SEED_PRICES_CSV = SEED_DIR / "seed_prices_35.csv"

BUILD_ID = "v8_7_175_modular"

# --- Constantes de negocio ---
CATEGORY_CODES = {
    "Entrantes": "ENT", "Principales": "PRI", "Postres": "POS",
    "Ensaladas": "ENS", "Guarniciones": "GUA", "Salsas": "SAL",
    "Bases": "BAS", "Preelaborados": "PRE", "Bebidas": "BEB", "Otros": "OTR",
}
SUBCATEGORIES = ["Sin definir", "Frío", "Caliente", "Salsas", "Guarniciones",
                 "Postres", "Otros", "Carne", "Pescado", "Vegetariano",
                 "Cocina Central", "Barra"]
ALLERGENS_UE = [
    ("gluten", "🌾", "Gluten"), ("crustaceos", "🦐", "Crustáceos"),
    ("huevo", "🥚", "Huevo"), ("pescado", "🐟", "Pescado"),
    ("cacahuete", "🥜", "Cacahuete"), ("soja", "🫘", "Soja"),
    ("leche", "🥛", "Leche"), ("frutos_cascara", "🌰", "Frutos de cáscara"),
    ("apio", "🥬", "Apio"), ("mostaza", "🟡", "Mostaza"),
    ("sesamo", "⚪", "Sésamo"), ("sulfitos", "🍷", "Sulfitos"),
    ("altramuces", "🌼", "Altramuces"), ("moluscos", "🦪", "Moluscos"),
]


# ==============================================================================
# BASE DE DATOS
# ==============================================================================

def db():
    conn = sqlite3.connect(DB_PATH, timeout=240, isolation_level="DEFERRED", check_same_thread=False)
    conn.row_factory = sqlite3.Row
    for pragma in ["PRAGMA journal_mode=WAL", "PRAGMA synchronous=NORMAL", "PRAGMA busy_timeout=240000"]:
        try:
            conn.execute(pragma)
        except Exception:
            pass
    return conn


def _is_db_locked_error(exc: Exception) -> bool:
    try:
        return "locked" in str(exc).lower()
    except Exception:
        return False


def _retry_db_write(write_fn, attempts: int = 10, delay: float = 0.45):
    last_exc = None
    for attempt in range(attempts):
        conn = db()
        try:
            cur = conn.cursor()
            try:
                cur.execute("BEGIN IMMEDIATE")
            except Exception:
                pass
            result = write_fn(conn, cur)
            conn.commit()
            conn.close()
            return result
        except sqlite3.OperationalError as exc:
            last_exc = exc
            try:
                conn.rollback()
            except Exception:
                pass
            conn.close()
            if (not _is_db_locked_error(exc)) or attempt >= attempts - 1:
                raise
            time.sleep(delay * (attempt + 1))
        except Exception:
            try:
                conn.rollback()
            except Exception:
                pass
            conn.close()
            raise
    if last_exc:
        raise last_exc


# ==============================================================================
# UTILIDADES DE FORMATO
# ==============================================================================

def _parse_float(v, default: float = 0.0) -> float:
    if v is None:
        return default
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).strip().replace(" ", "").replace(",", ".")
    try:
        return float(s)
    except Exception:
        return default


def fmt_num(v: float, decimals: int = 3) -> str:
    try:
        f = float(v)
    except Exception:
        return str(v or "")
    s = f"{f:.{decimals}f}"
    if "." in s:
        s = s.rstrip("0").rstrip(".")
    return s


def fmt_price(v: float, decimals: int = 2) -> str:
    return fmt_num(v, decimals)


def _cache_bust_token() -> str:
    return str(int(time.time() * 1000))


def _norm_text(s: str) -> str:
    s = unicodedata.normalize("NFD", (s or "").lower())
    s = "".join(ch for ch in s if unicodedata.category(ch) != "Mn")
    s = re.sub(r"[^a-z0-9]+", " ", s)
    return re.sub(r"\s+", " ", s).strip()


def _norm_name(s: str) -> str:
    return _norm_text(s)


def _item_key(name: str) -> str:
    return re.sub(r"\s+", " ", (name or "").strip()).lower()


def upper_name(value: str) -> str:
    return (value or "").strip().upper()


def fmt_dt(value: str) -> str:
    s = (value or "").strip()
    if not s:
        return ""
    if re.fullmatch(r"\d{4}-\d{2}-\d{2}", s):
        try:
            return datetime.strptime(s, "%Y-%m-%d").strftime("%d/%m/%Y")
        except Exception:
            return s
    try:
        raw = s.replace("Z", "+00:00")
        dt = datetime.fromisoformat(raw)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(APP_TZ).strftime("%d/%m/%Y %H:%M")
    except Exception:
        try:
            dt = datetime.strptime(s[:19], "%Y-%m-%d %H:%M:%S")
            return dt.replace(tzinfo=timezone.utc).astimezone(APP_TZ).strftime("%d/%m/%Y %H:%M")
        except Exception:
            return s


def status_label(status: str) -> str:
    return {"DRAFT": "BORRADOR", "CONFIRMED": "CONFIRMADO", "PENDING": "BORRADOR",
            "CANCELED": "CANCELADO", "ARCHIVED": "ARCHIVADO"}.get(
        (status or "").strip(), (status or "").strip())


def _ocr_state_label(state: str) -> str:
    return {"READY": "Listo para revisar", "PENDING": "Pendiente", "EMPTY": "Sin fotos",
            "ERROR": "Con incidencias", "READ": "Leído para revisar"}.get(
        (state or "").strip(), state or "-")


# ==============================================================================
# UNIDADES Y PRECIOS
# ==============================================================================

def normalize_price_to_base(price: float, base_unit: str, input_unit: str) -> float:
    """Normaliza precio por unidad de compra a precio por unidad base.
    Directriz operativa: los líquidos se gestionan también por peso (g/kg),
    usando equivalencia 1 l = 1 kg y 1 ml = 1 g.
    """
    base_unit = (base_unit or "").strip().lower()
    input_unit = (input_unit or base_unit or "").strip().lower()
    price = float(price or 0)
    if base_unit in ("g", "kg"):
        if input_unit in ("kg", "l"):
            return price / 1000.0 if base_unit == "g" else price
        if input_unit in ("g", "ml"):
            return price * 1000.0 if base_unit == "kg" else price
    if base_unit == "ud":
        return price
    return price


def preferred_price_unit(base_unit: str) -> str:
    return {"g": "kg", "kg": "kg", "ud": "ud"}.get((base_unit or "").strip().lower(), (base_unit or "").strip().lower())


def display_price_from_base(current_price: float, base_unit: str) -> float:
    base_unit = (base_unit or "").strip().lower()
    p = float(current_price or 0)
    if base_unit == "g":
        return p * 1000.0
    return p


def _unit_factor(input_unit: str, base_unit: str) -> float:
    iu = (input_unit or base_unit or "").lower().strip()
    bu = (base_unit or "").lower().strip()
    if not iu or not bu:
        return 1.0
    if iu == bu:
        return 1.0
    # Política operativa del sistema: líquidos también por peso.
    # Equivalencias aceptadas: 1 ml = 1 g, 1 l = 1 kg.
    aliases_to_g = {"g", "gr", "gramo", "gramos", "ml"}
    aliases_to_kg = {"kg", "kilo", "kilos", "l", "lt", "lts", "litro", "litros"}
    if bu in {"g", "kg"}:
        if iu in aliases_to_g:
            return 1.0 if bu == "g" else 0.001
        if iu in aliases_to_kg:
            return 1000.0 if bu == "g" else 1.0
    if bu == "ud":
        return 1.0 if iu == "ud" else 1.0
    return 1.0


def _factor_for_units(input_unit: str, base_unit: str) -> float:
    return _unit_factor(input_unit, base_unit)


def get_unit_factor(input_unit: str, base_unit: str) -> float:
    return _unit_factor(input_unit, base_unit)


def _canonical_unit(unit: str) -> str:
    u = (unit or "").strip().lower()
    if u in ("g", "kg", "gr", "gramo", "gramos", "ml", "l", "lt", "lts", "litro", "litros"):
        return "g"
    if u in ("ud", "u", "unidad", "unidades"):
        return "ud"
    if u in {"racion", "raciones"}:
        return "raciones"
    if u in {"porcion", "porciones"}:
        return "porciones"
    return u or "ud"


def _guess_unit_family(unit: str) -> str:
    u = (unit or "").strip().lower()
    if u in ("g", "kg", "gr", "gramo", "gramos", "ml", "l", "lt", "lts", "litro", "litros"):
        return "peso"
    return "unidad"


def preferred_display_qty(qty: float, unit: str) -> tuple:
    try:
        q = float(qty or 0)
    except Exception:
        return qty, (unit or "").strip()
    u = (unit or "").strip().lower()
    if u == "g" and abs(q) >= 1000:
        return q / 1000.0, "kg"
    return q, "g" if u in {"ml", "l"} else (u or (unit or ""))


def human_qty(qty: float, unit: str) -> str:
    try:
        q = float(qty or 0)
    except Exception:
        return f"{qty} {unit}".strip()
    u = (unit or "").strip().lower()
    if u in {"ml", "l"}:
        u = "g"
        if unit == "l":
            q *= 1000.0
    sign = -1 if q < 0 else 1
    q = abs(q)
    if u == "g" and q >= 1000:
        return f"{fmt_num(sign*q/1000.0, 2)} kg"
    if u == "g":
        if q >= 10:
            rounded = round(sign * q, 1)
            return f"{fmt_num(rounded, 1)} g"
        rounded = round(sign * q, 2)
        return f"{fmt_num(rounded, 2)} g"
    return f"{fmt_num(sign*q, 2)} {u}".strip()


def _movement_signed_qty(movement_type: str, qty: float) -> float:
    mt = (movement_type or "").upper().strip()
    if mt in {"ENTRADA", "IN"}:
        return float(qty)
    return -float(qty)


def _convert_qty(qty: float, from_unit: str, to_unit: str) -> float:
    try:
        return float(qty or 0.0) * float(_unit_factor(from_unit, to_unit))
    except Exception:
        return float(qty or 0.0)


# ==============================================================================
# ARTÍCULOS Y MERMAS
# ==============================================================================

def suggest_item_waste_pct(name: str, unit: str = "") -> float:
    nm = upper_name(name or "")
    u = (unit or "").strip().lower()
    if not nm:
        return 0.0
    if u == "ud" and any(k in nm for k in ["HUEVO", "LIMON", "LIMA", "AGUACATE", "MANZANA", "NARANJA"]):
        return 0.0
    zero_kw = ["SAL", "AZUCAR", "AZÚCAR", "PIMIENTA", "ESPECIA", "VINAGRE", "ACEITE",
               "AGUA", "HARINA", "ARROZ", "PASTA SECA", "TOMATE LATA", "CONCENTRADO",
               "PURE", "PURÉ", "CALDO", "QUESO", "MANTEQUILLA", "NATA", "LECHE", "YOGUR"]
    if any(k in nm for k in zero_kw):
        return 0.0
    if any(k in nm for k in ["FILETE", "LOMO LIMPIO", "PELADO", "LIMPIO", "DESHUESADO"]):
        return 0.0
    if any(k in nm for k in ["PESCADO ENTERO", "DORADA", "LUBINA", "MERLUZA ENTERA", "RAPE"]):
        return 45.0
    if any(k in nm for k in ["POLLO ENTERO", "COSTILLAR", "PALETILLA", "CARRILLERA"]):
        return 18.0
    if any(k in nm for k in ["CEBOLLA", "PUERRO", "APIO", "ZANAHORIA", "AJO", "PIMIENTO", "PATATA"]):
        return 12.0
    if any(k in nm for k in ["GAMBA ENTERA", "LANGOSTINO ENTERO", "MARISCO ENTERO"]):
        return 35.0
    return 0.0


def _resolve_item_id(cur, item_id, item_query: str):
    if item_id is not None and str(item_id).strip() != "":
        try:
            return int(item_id)
        except Exception:
            pass
    q = (item_query or "").strip()
    if not q:
        return None
    m = re.search(r"\[#(\d+)\]", q)
    if m:
        return int(m.group(1))
    name = re.sub(r"\s*\[.*\]\s*$", "", q).strip()
    if not name:
        return None
    row = cur.execute("SELECT id FROM items WHERE lower(name)=lower(?)", (name,)).fetchone()
    if row:
        return int(row["id"])
    row = cur.execute("SELECT id FROM items WHERE lower(name) LIKE lower(?) ORDER BY name LIMIT 1",
                      (name + "%",)).fetchone()
    if row:
        return int(row["id"])
    return None


def _resolve_item_id_strict(cur, item_id, item_query: str):
    if item_id is not None and str(item_id).strip() != "":
        try:
            return int(item_id)
        except Exception:
            return None
    q = (item_query or "").strip()
    if not q:
        return None
    m = re.search(r"\[#(\d+)\]", q)
    if m:
        return int(m.group(1))
    name = re.sub(r"\s*\[.*\]\s*$", "", q).strip()
    if not name:
        return None
    row = cur.execute("SELECT id FROM items WHERE lower(name)=lower(?)", (name,)).fetchone()
    if row:
        return int(row["id"])
    return None


# ==============================================================================
# PROVEEDORES
# ==============================================================================

def _supplier_columns(cur) -> set:
    return {r["name"] for r in cur.execute("PRAGMA table_info(suppliers)").fetchall()}


def _ensure_pending_supplier(cur) -> int:
    row = cur.execute(
        "SELECT id FROM suppliers WHERE lower(name)=lower(?) ORDER BY id LIMIT 1",
        ("Proveedor pendiente OCR",)).fetchone()
    if row:
        return int(row["id"])
    cols = _supplier_columns(cur)
    if "tax_id" in cols and "address" in cols:
        cur.execute(
            "INSERT INTO suppliers(name,phone,email,tax_id,address,is_active) VALUES(?,?,?,?,?,1)",
            ("Proveedor pendiente OCR", None, None, None, None))
    else:
        cur.execute("INSERT INTO suppliers(name,is_active) VALUES(?,1)", ("Proveedor pendiente OCR",))
    return int(cur.lastrowid)


def _cleanup_pending_supplier(cur) -> None:
    row = cur.execute(
        "SELECT id FROM suppliers WHERE lower(name)=lower(?) ORDER BY id LIMIT 1",
        ("Proveedor pendiente OCR",)).fetchone()
    if not row:
        return
    pending_id = int(row["id"])
    cur.execute("UPDATE suppliers SET is_active=0 WHERE id=?", (pending_id,))


def _insert_supplier_compatible(cur, name: str, is_active: int = 1, phone=None, email=None,
                                 tax_id=None, address=None) -> int:
    cols = _supplier_columns(cur)
    now = datetime.utcnow().isoformat()
    payload = {"name": (name or "").strip()[:120], "phone": phone, "email": email,
               "tax_id": tax_id, "address": address, "is_active": int(is_active), "created_at": now}
    ordered_cols = [c for c in ["name", "phone", "email", "tax_id", "address", "is_active", "created_at"]
                    if c in cols]
    placeholders = ",".join(["?"] * len(ordered_cols))
    cur.execute(f"INSERT INTO suppliers({','.join(ordered_cols)}) VALUES({placeholders})",
                tuple(payload[c] for c in ordered_cols))
    return int(cur.lastrowid)


def _resolve_supplier_id_by_name(cur, supplier_name: str):
    name = (supplier_name or "").strip()
    if not name:
        return None, None
    row = cur.execute("SELECT id,name FROM suppliers WHERE lower(name)=lower(?) AND is_active=1 ORDER BY id LIMIT 1",
                      (name,)).fetchone()
    if row:
        return int(row["id"]), row["name"]
    row = cur.execute(
        "SELECT id,name FROM suppliers WHERE lower(name) LIKE lower(?) AND is_active=1 ORDER BY id LIMIT 1",
        (f"%{name}%",)).fetchone()
    if row:
        return int(row["id"]), row["name"]
    return None, None


def _provider_has_links(cur, provider_id: int) -> bool:
    for table in ("receipts", "order_lines", "supplier_item_prices"):
        row = cur.execute(f"SELECT 1 FROM {table} WHERE supplier_id=? LIMIT 1", (provider_id,)).fetchone()
        if row:
            return True
    return False


def _provider_archive_name(name: str) -> str:
    base = (name or "").strip()
    suffix = " [ARCHIVADO]"
    if base.endswith(suffix):
        return base
    return (base + suffix)[:120]


def _suggest_supplier_id(cur, center_id: int, item_id: int):
    try:
        row = cur.execute(
            """SELECT supplier_id FROM supplier_item_prices
               WHERE item_id=? AND is_preferred=1 AND (center_id IS NULL OR center_id=?)
               ORDER BY CASE WHEN center_id=? THEN 0 ELSE 1 END, updated_at DESC LIMIT 1""",
            (int(item_id), int(center_id), int(center_id))).fetchone()
        if row and row["supplier_id"]:
            return int(row["supplier_id"])
        row = cur.execute(
            """SELECT supplier_id FROM supplier_item_prices
               WHERE item_id=? AND (center_id IS NULL OR center_id=?)
               ORDER BY CASE WHEN center_id=? THEN 0 ELSE 1 END, price_per_purchase ASC, updated_at DESC LIMIT 1""",
            (int(item_id), int(center_id), int(center_id))).fetchone()
        if row and row["supplier_id"]:
            return int(row["supplier_id"])
    except Exception:
        return None
    return None


def _supplier_options_for_item(cur, center_id: int, item_id: int):
    rows = cur.execute(
        """SELECT sp.supplier_id, s.name supplier_name, sp.price_per_purchase,
                  sp.purchase_unit, sp.purchase_to_base_factor, sp.is_preferred,
                  sp.updated_at, sp.center_id
             FROM supplier_item_prices sp
             JOIN suppliers s ON s.id=sp.supplier_id
            WHERE sp.item_id=? AND (sp.center_id IS NULL OR sp.center_id=?)
            ORDER BY CASE WHEN sp.center_id=? THEN 0 ELSE 1 END, sp.is_preferred DESC, sp.updated_at DESC""",
        (int(item_id), int(center_id), int(center_id))).fetchall()
    best = {}
    for r in rows:
        sid = int(r["supplier_id"])
        if sid not in best:
            best[sid] = {k: r[k] for k in r.keys()}
    opts = list(best.values())

    def norm_price(o):
        try:
            fac = float(o.get("purchase_to_base_factor") or 1.0)
            return float(o.get("price_per_purchase") or 0.0) / max(fac, 0.0001)
        except Exception:
            return 0.0

    opts.sort(key=lambda o: (0 if int(o.get("is_preferred") or 0) == 1 else 1,
                              norm_price(o), (o.get("supplier_name") or "").lower()))
    return opts


def _supplier_factor_for_item(cur, center_id: int, supplier_id: int, item_id: int,
                               input_unit: str, base_unit: str) -> float:
    try:
        row = cur.execute(
            """SELECT purchase_unit, purchase_to_base_factor FROM supplier_item_prices
               WHERE supplier_id=? AND item_id=? AND (center_id=? OR center_id IS NULL)
               ORDER BY CASE WHEN center_id=? THEN 0 ELSE 1 END, updated_at DESC LIMIT 1""",
            (int(supplier_id), int(item_id), int(center_id), int(center_id))).fetchone()
        if row:
            fac = float(row["purchase_to_base_factor"] or 0)
            pu = (row["purchase_unit"] or "").lower().strip()
            iu = (input_unit or "").lower().strip()
            if fac > 0 and (not pu or pu == iu):
                return fac
    except Exception:
        pass
    return _unit_factor(input_unit, base_unit)


# ==============================================================================
# RECETAS
# ==============================================================================

def _parse_scope(scope_global_raw, scope_centers_raw):
    scope_global = 1 if str(scope_global_raw or "").lower() in {"1", "on", "true", "yes"} else 0
    center_ids = []
    for v in (scope_centers_raw or []):
        sv = str(v).strip()
        if sv.isdigit():
            center_ids.append(int(sv))
    center_ids = sorted(set(center_ids))
    if scope_global:
        return 1, ""
    return 0, ",".join(str(x) for x in center_ids)


def recipe_visible_in_center(rec, center_id):
    if not rec:
        return False
    if not center_id:
        return True
    try:
        if int(rec["scope_global"] or 0) == 1:
            return True
    except Exception:
        return True
    scope_centers = str(rec["scope_centers"] or "")
    parts = {int(x) for x in scope_centers.split(",") if str(x).strip().isdigit()}
    return int(center_id) in parts


def next_recipe_code(cur, category: str):
    prefix = CATEGORY_CODES.get(category, "REC")
    row = cur.execute("SELECT COUNT(*) c FROM recipes WHERE category=?", (category,)).fetchone()
    seq = (row["c"] or 0) + 1
    return f"REC-{prefix}-{seq:04d}"


def recipe_with_calc(cur, recipe_id: int):
    rec = cur.execute("SELECT * FROM recipes WHERE id=?", (recipe_id,)).fetchone()
    if not rec:
        return None
    ing_rows = cur.execute("SELECT * FROM recipe_ingredients WHERE recipe_id=? ORDER BY id",
                           (recipe_id,)).fetchall()
    cost_supplier_id = int(rec["cost_supplier_id"] or 0)
    cost_base = 0.0
    ingredients = []
    for r in ing_rows:
        item_id = int(r["item_id"] or 0)
        subrecipe_id = int(r["subrecipe_id"] or 0)
        unit_cost = 0.0
        ing_unit = (r["unit"] or "ud").strip()
        if subrecipe_id:
            sub = cur.execute("SELECT * FROM recipes WHERE id=?", (subrecipe_id,)).fetchone()
            if sub:
                sub_calc = recipe_with_calc(cur, subrecipe_id)
                sub_cost = float((sub_calc or {}).get("calc", {}).get("cost_per_portion", 0.0))
                unit_cost = sub_cost
        elif item_id:
            if cost_supplier_id:
                sp = cur.execute(
                    """SELECT price_per_purchase, purchase_to_base_factor FROM supplier_item_prices
                       WHERE supplier_id=? AND item_id=? ORDER BY updated_at DESC LIMIT 1""",
                    (cost_supplier_id, item_id)).fetchone()
                if sp:
                    fac = float(sp["purchase_to_base_factor"] or 1.0)
                    unit_cost = float(sp["price_per_purchase"] or 0.0) / max(fac, 0.0001)
                else:
                    it = cur.execute("SELECT current_price FROM items WHERE id=?", (item_id,)).fetchone()
                    unit_cost = float(it["current_price"] or 0.0) if it else 0.0
            else:
                it = cur.execute("SELECT current_price FROM items WHERE id=?", (item_id,)).fetchone()
                unit_cost = float(it["current_price"] or 0.0) if it else 0.0
        qty_gross = float(r["qty_gross"] or 0.0)
        line_cost = qty_gross * unit_cost
        cost_base += line_cost
        ing_d = {k: r[k] for k in r.keys()}
        ing_d["unit_cost"] = unit_cost
        ing_d["line_cost"] = line_cost
        ingredients.append(ing_d)

    waste_pct = float(rec["waste_pct"] or 0.0)
    contingency_pct = float(rec["contingency_pct"] or 0.0)
    yield_portions = max(float(rec["yield_portions"] or 1.0), 0.0001)
    target_food_cost_pct = float(rec["target_food_cost_pct"] or 30.0)
    target_margin_pct = float(rec["target_margin_pct"] or 70.0)
    manual_price = float(rec["manual_price"] or 0.0)
    cost_adjusted = cost_base * (1 + contingency_pct / 100.0)
    cost_per_portion = cost_adjusted / yield_portions
    price_ex_vat = (cost_per_portion / (target_food_cost_pct / 100.0)) if target_food_cost_pct > 0 else 0.0
    price_vat = price_ex_vat * 0.10
    price_inc_vat = price_ex_vat * 1.10
    suggested_ex_vat = manual_price if manual_price > 0 else price_ex_vat
    suggested_inc_vat = suggested_ex_vat * 1.10
    food_cost_real_pct = (cost_per_portion / suggested_ex_vat * 100.0) if suggested_ex_vat > 0 else 0.0

    payload = {k: rec[k] for k in rec.keys()}
    payload["ingredients"] = ingredients
    payload["calc"] = {
        "cost_base": cost_base, "cost_adjusted": cost_adjusted,
        "yield_portions": yield_portions, "cost_per_portion": cost_per_portion,
        "price_ex_vat": price_ex_vat, "price_vat": price_vat,
        "price_inc_vat": price_inc_vat, "suggested_ex_vat": suggested_ex_vat,
        "suggested_inc_vat": suggested_inc_vat, "food_cost_real_pct": food_cost_real_pct,
    }
    return payload


# ==============================================================================
# PRODUCCIONES
# ==============================================================================

def production_with_lines(cur, production_id: int):
    p = cur.execute(
        """SELECT p.*, c.name center_name, w.name warehouse_name
             FROM productions p
             JOIN centers c ON c.id=p.center_id
             JOIN warehouses w ON w.id=p.warehouse_id
            WHERE p.id=?""", (production_id,)).fetchone()
    if not p:
        return None
    lines = cur.execute(
        """SELECT pl.*, i.name item_name, i.unit base_unit
             FROM production_lines pl
             JOIN items i ON i.id=pl.item_id
            WHERE pl.production_id=? ORDER BY pl.id""", (production_id,)).fetchall()
    payload = {k: p[k] for k in p.keys()}
    payload["lines"] = [{k: r[k] for k in r.keys()} for r in lines]
    return payload


def _production_required_gross(cur, recipe_row) -> float:
    gross = float(recipe_row["qty_gross"] or 0.0)
    if gross > 0:
        return gross
    net = float(recipe_row["qty_net"] or 0.0)
    waste = float(recipe_row["waste_pct_ing"] or 0.0)
    if waste <= 0 and int(recipe_row["item_id"] or 0) > 0:
        ir = cur.execute("SELECT waste_default_pct FROM items WHERE id=?",
                         (int(recipe_row["item_id"]),)).fetchone()
        if ir:
            waste = float(ir[0] or 0.0)
    if waste >= 100:
        waste = 99.0
    if net <= 0:
        return 0.0
    if waste > 0:
        return net / max(0.000001, (1.0 - (waste / 100.0)))
    return net


def _merge_or_insert_production_line(cur, production_id: int, line_type: str, item_id: int,
                                      qty_base: float, input_unit: str, qty_input: float):
    existing = cur.execute(
        "SELECT id, qty_base, qty_input FROM production_lines WHERE production_id=? AND line_type=? AND item_id=? AND input_unit=? ORDER BY id LIMIT 1",
        (production_id, line_type, int(item_id), (input_unit or "").strip())).fetchone()
    if existing:
        cur.execute(
            "UPDATE production_lines SET qty_base=?, qty_input=? WHERE id=?",
            (float(existing["qty_base"] or 0.0) + float(qty_base or 0.0),
             float(existing["qty_input"] or 0.0) + float(qty_input or 0.0),
             int(existing["id"])))
        return False
    cur.execute(
        "INSERT INTO production_lines(production_id,line_type,item_id,qty_base,input_unit,qty_input) VALUES(?,?,?,?,?,?)",
        (production_id, line_type, int(item_id), float(qty_base), (input_unit or "").strip() or "ud", float(qty_input)))
    return True


# ==============================================================================
# PEDIDOS
# ==============================================================================

def order_with_lines(cur, order_id: int):
    o = cur.execute(
        """SELECT o.*, c.name center_name FROM orders o
             JOIN centers c ON c.id=o.center_id WHERE o.id=?""", (order_id,)).fetchone()
    if not o:
        return None
    lines = cur.execute(
        """SELECT ol.*, i.name item_name, i.unit base_unit,
                  w.name warehouse_name, s.name supplier_name
             FROM order_lines ol
             JOIN items i ON i.id=ol.item_id
             JOIN warehouses w ON w.id=ol.warehouse_id
             LEFT JOIN suppliers s ON s.id=ol.supplier_id
            WHERE ol.order_id=? ORDER BY ol.id""", (order_id,)).fetchall()
    payload = {k: o[k] for k in o.keys()}
    out_lines = []
    for r in lines:
        d = {k: r[k] for k in r.keys()}
        dv, du = preferred_display_qty(d.get("qty_input"), d.get("input_unit"))
        d["display_qty_value"] = dv
        d["display_qty_unit"] = du
        d["display_price_unit"] = preferred_price_unit(d.get("base_unit") or d.get("input_unit") or "")
        out_lines.append(d)
    payload["lines"] = out_lines
    return payload


# ==============================================================================
# DASHBOARD / DATOS GLOBALES
# ==============================================================================

def get_dashboard_data(center_id: Optional[int] = None):
    conn = db()
    cur = conn.cursor()
    ensure_columns(cur)
    centers = cur.execute("SELECT * FROM centers ORDER BY id").fetchall()
    center_filter = ""
    params = []
    if center_id:
        center_filter = "WHERE c.id=?"
        params.append(center_id)
    stock_sql = f"""
    SELECT c.id center_id,c.name center_name,w.id warehouse_id,w.name warehouse_name,
           i.id item_id,i.name item_name,i.unit,i.stock_area,
           COALESCE(lp.min_qty, i.min_qty) min_qty,
           COALESCE(lp.max_qty, i.max_qty) max_qty,
           CASE WHEN lp.item_id IS NOT NULL THEN 1 ELSE 0 END has_pref,
           COALESCE(SUM(CASE WHEN m.movement_type IN ('ENTRADA','IN') THEN m.qty
                             WHEN m.movement_type IN ('SALIDA','OUT') THEN -m.qty ELSE -m.qty END),0) stock_qty,
           (SELECT mm.qty FROM movements mm WHERE mm.center_id=c.id AND mm.warehouse_id=w.id AND mm.item_id=i.id ORDER BY mm.id DESC LIMIT 1) last_move_qty,
           (SELECT mm.note FROM movements mm WHERE mm.center_id=c.id AND mm.warehouse_id=w.id AND mm.item_id=i.id ORDER BY mm.id DESC LIMIT 1) last_move_note,
           (SELECT mm.created_at FROM movements mm WHERE mm.center_id=c.id AND mm.warehouse_id=w.id AND mm.item_id=i.id ORDER BY mm.id DESC LIMIT 1) last_move_at
    FROM centers c
    JOIN warehouses w ON w.center_id=c.id
    CROSS JOIN items i
    LEFT JOIN item_location_prefs lp ON lp.center_id=c.id AND lp.warehouse_id=w.id AND lp.item_id=i.id
    LEFT JOIN movements m ON m.center_id=c.id AND m.warehouse_id=w.id AND m.item_id=i.id
    {center_filter}
    GROUP BY c.id,c.name,w.id,w.name,i.id,i.name,i.unit,i.stock_area,
             COALESCE(lp.min_qty, i.min_qty),COALESCE(lp.max_qty, i.max_qty), CASE WHEN lp.item_id IS NOT NULL THEN 1 ELSE 0 END
    ORDER BY c.name, w.name, i.name
    """
    stocks = cur.execute(stock_sql, params).fetchall()
    summary = {
        "centers": len({s["center_id"] for s in stocks}),
        "positions": len(stocks),
        "below_min": sum(1 for s in stocks if s["stock_qty"] < s["min_qty"]),
    }
    warehouses = cur.execute(
        "SELECT w.id,w.name,w.center_id,c.name center_name FROM warehouses w JOIN centers c ON c.id=w.center_id ORDER BY c.id,w.id").fetchall()
    items = cur.execute("SELECT *, COALESCE(stock_area,'') stock_area FROM items ORDER BY name COLLATE NOCASE").fetchall()
    if center_id:
        recipes = cur.execute(
            """SELECT * FROM recipes WHERE is_active=1
               AND (COALESCE(scope_global,1)=1 OR instr(','||COALESCE(scope_centers,'')||',', ','||?||',')>0)
               ORDER BY id""", (int(center_id),)).fetchall()
    else:
        recipes = cur.execute("SELECT * FROM recipes WHERE is_active=1 ORDER BY id").fetchall()
    conn.close()
    stocks = [dict(s) if not hasattr(s, 'keys') else {k: s[k] for k in s.keys()} for s in stocks]
    for s in stocks:
        s['stock_area'] = normalize_stock_area(s.get('stock_area') or '')
    return centers, warehouses, items, stocks, summary, recipes


# ==============================================================================
# ALBARANES / FOTOS / RETENCIÓN
# ==============================================================================

def _parse_dt_any(s: str):
    if not s:
        return None
    ss = str(s).strip().replace("Z", "")
    try:
        return datetime.fromisoformat(ss)
    except Exception:
        pass
    try:
        return datetime.strptime(ss[:19], "%Y-%m-%d %H:%M:%S")
    except Exception:
        return None


def _expiry_end_of_month_plus_2(dt: datetime) -> datetime:
    y, m = dt.year, dt.month
    m2 = m + 2
    y2 = y + (m2 - 1) // 12
    m2 = ((m2 - 1) % 12) + 1
    last_day = calendar.monthrange(y2, m2)[1]
    return datetime(y2, m2, last_day, 23, 59, 59)


def cleanup_receipt_photos(cur, center_id: Optional[int] = None) -> dict:
    now = datetime.now()
    q = """SELECT rp.id, rp.file_path, rp.created_at, r.center_id
             FROM receipt_photos rp JOIN receipts r ON r.id = rp.receipt_id"""
    params = []
    if center_id:
        q += " WHERE r.center_id=?"
        params.append(int(center_id))
    rows = cur.execute(q, tuple(params)).fetchall()
    deleted_files = 0
    deleted_rows = 0
    for r in rows:
        dt = _parse_dt_any(r["created_at"])
        if not dt:
            continue
        if now <= _expiry_end_of_month_plus_2(dt):
            continue
        fp = (r["file_path"] or "").strip()
        try:
            if fp:
                p = Path(fp)
                if not p.is_absolute():
                    p = (RUNTIME_DIR / fp).resolve()
                if p.exists():
                    p.unlink(missing_ok=True)
                    deleted_files += 1
        except Exception:
            pass
        try:
            cur.execute("DELETE FROM receipt_photos WHERE id=?", (int(r["id"]),))
            deleted_rows += 1
        except Exception:
            pass
    return {"deleted_files": deleted_files, "deleted_rows": deleted_rows}


def _refresh_ocr_summary(cur, receipt_id: int):
    run = cur.execute(
        "SELECT id FROM receipt_ocr_runs WHERE receipt_id=? ORDER BY id DESC LIMIT 1",
        (int(receipt_id),)).fetchone()
    if not run:
        return
    rows = cur.execute("SELECT review_status FROM receipt_ocr_lines WHERE ocr_run_id=? ORDER BY id",
                       (int(run["id"]),)).fetchall()
    total = len(rows)
    accepted = sum(1 for r in rows if (r["review_status"] or "").upper() == "ACCEPTED")
    pending = sum(1 for r in rows if (r["review_status"] or "").upper() in ("PENDING", "REVIEW"))
    summary = f"{total} línea(s) OCR · {accepted} aceptada(s) · {pending} pendiente(s)"
    status = "READ" if total else "EMPTY"
    cur.execute("UPDATE receipt_ocr_runs SET summary=?, status=? WHERE id=?",
                (summary, status, int(run["id"])))


def _resolve_receipt_warehouse(cur, center_id: int, warehouse_id: int) -> int:
    row = cur.execute("SELECT id FROM warehouses WHERE id=? AND center_id=?",
                      (int(warehouse_id or 0), int(center_id or 0))).fetchone()
    if row:
        return int(row["id"])
    row = cur.execute("SELECT id FROM warehouses WHERE center_id=? ORDER BY id LIMIT 1",
                      (int(center_id or 0),)).fetchone()
    if row:
        return int(row["id"])
    raise ValueError("No hay almacén disponible para el centro")


def _collect_uploads_from_form(form, *field_names) -> list:
    files = []
    for name in field_names:
        try:
            vals = form.getlist(name)
        except Exception:
            vals = []
        for v in vals:
            if getattr(v, "filename", None):
                files.append(v)
    seen = set()
    uniq = []
    for f in files:
        key = (getattr(f, "filename", None), id(f))
        if key in seen:
            continue
        seen.add(key)
        uniq.append(f)
    return uniq


# ==============================================================================
# OCR - LOCKS
# ==============================================================================

def _ocr_lock_path(receipt_id: int) -> Path:
    lock_dir = APP_DIR.parent / "var" / "ocr_locks"
    lock_dir.mkdir(parents=True, exist_ok=True)
    return lock_dir / f"receipt_{int(receipt_id)}.lock"


def _ocr_lock_is_recent(receipt_id: int, max_age_sec: int = 45) -> bool:
    p = _ocr_lock_path(receipt_id)
    if not p.exists():
        return False
    try:
        age = time.time() - p.stat().st_mtime
        return age < max_age_sec
    except Exception:
        return False


def _ocr_lock_touch(receipt_id: int):
    try:
        _ocr_lock_path(receipt_id).write_text(str(int(time.time())))
    except Exception:
        pass


def _ocr_lock_clear(receipt_id: int):
    try:
        p = _ocr_lock_path(receipt_id)
        if p.exists():
            p.unlink()
    except Exception:
        pass


# ==============================================================================
# OCR HELPERS COMPARTIDOS (usados por main.py para display)
# ==============================================================================

def _ocr_cleanup_product_tokens(name: str) -> str:
    s = re.sub(r"\b(E[S5]|S2)\b", " ", (name or ""), flags=re.I)
    s = re.sub(r"\b(cod|codigo|ref|articulo|art)\b[\s.:]+\w+", " ", s, flags=re.I)
    s = re.sub(r"\s+", " ", s).strip(" -:;,.()")
    return s


def _ocr_postfix_product_cleanup(name: str) -> str:
    s = _ocr_cleanup_product_tokens(name or "")
    s = re.sub(r"\bPITOS?\b", " ", s, flags=re.I)
    s = re.sub(r"\bM[I1J]L\b", "M/L", s, flags=re.I)
    s = re.sub(r"\bM\s*/?\s*L\b", "M/L", s, flags=re.I)
    s = re.sub(r"\b(PT|MA|ES|E[S5]|S2)\b$", " ", s, flags=re.I)
    s = re.sub(r"\b(BR)\b$", " ", s, flags=re.I)
    s = re.sub(r"\b(RESTAURANTE|REFERENCIA|MERCASA)\b$", " ", s, flags=re.I)
    s = re.sub(r"\s+", " ", s).strip(" -:;,.()")
    return s


# ==============================================================================
# UTILIDADES DE IMAGEN
# ==============================================================================

def _normalize_uploaded_image_bytes_to_jpeg(filename: str, content: bytes, *, quality: int = 92, max_side: int = 2200):
    import io as _io
    safe = re.sub(r"[^a-zA-Z0-9._-]", "_", (filename or "upload").strip()) or "upload"
    base = re.sub(r"\.[A-Za-z0-9]+$", "", safe) or "upload"

    def _finalize(im):
        im.load()
        try:
            im = ImageOps.exif_transpose(im)
        except Exception:
            pass
        if getattr(im, "mode", "RGB") != "RGB":
            im = im.convert("RGB")
        try:
            w, h = im.size
            if max(w, h) > max_side and max(w, h) > 0:
                scale = float(max_side) / float(max(w, h))
                im = im.resize((max(1, int(round(w * scale))), max(1, int(round(h * scale)))))
        except Exception:
            pass
        out = _io.BytesIO()
        try:
            im.save(out, format="JPEG", quality=quality, optimize=True)
        except Exception:
            out = _io.BytesIO()
            im.save(out, format="JPEG", quality=quality)
        data = out.getvalue()
        chk = Image.open(_io.BytesIO(data))
        chk.load()
        return f"{base}.jpg", data

    try:
        im = Image.open(_io.BytesIO(content))
        return _finalize(im)
    except Exception:
        pass
    if safe.lower().endswith((".heic", ".heif")):
        try:
            import subprocess, tempfile
            with tempfile.NamedTemporaryFile(suffix=Path(safe).suffix or ".heic", delete=False) as tin:
                tin.write(content)
                tmp_in = Path(tin.name)
            with tempfile.NamedTemporaryFile(suffix=".jpg", delete=False) as tout:
                tmp_out = Path(tout.name)
            subprocess.run(["sips", "-s", "format", "jpeg", str(tmp_in), "--out", str(tmp_out)],
                           check=True, capture_output=True)
            data = tmp_out.read_bytes()
            im = Image.open(_io.BytesIO(data))
            return _finalize(im)
        except Exception:
            pass
    return f"{base}.jpg", b""


def _normalize_receipt_upload_to_jpg(filename: str, content: bytes):
    jpg_name, jpg_bytes = _normalize_uploaded_image_bytes_to_jpeg(filename, content, quality=92, max_side=2400)
    if jpg_bytes:
        return jpg_name, jpg_bytes
    safe = re.sub(r"[^a-zA-Z0-9._-]", "_", (filename or "upload").strip()) or "upload"
    return safe, content


def _build_receipt_ocr_work_jpg(filename: str, content: bytes):
    import io as _io
    safe = re.sub(r"[^a-zA-Z0-9._-]", "_", (filename or "upload").strip()) or "upload"
    base = re.sub(r"\.[A-Za-z0-9]+$", "", safe) or "upload"
    norm_name, norm_bytes = _normalize_uploaded_image_bytes_to_jpeg(filename, content, quality=94, max_side=2400)
    if norm_bytes:
        try:
            im = Image.open(_io.BytesIO(norm_bytes))
            im.load()
            try:
                im = ImageOps.exif_transpose(im)
            except Exception:
                pass
            if im.mode != "RGB":
                im = im.convert("RGB")
            try:
                w, h = im.size
                target = 1900
                if max(w, h) < target and max(w, h) > 0:
                    scale = max(1, int(target / max(w, h)) + 1)
                    im = im.resize((w * scale, h * scale))
            except Exception:
                pass
            gray = ImageOps.autocontrast(im.convert("L")).convert("RGB")
            out = _io.BytesIO()
            gray.save(out, format="JPEG", quality=94, optimize=True)
            data = out.getvalue()
            base2 = re.sub(r"\.[A-Za-z0-9]+$", "", norm_name) or base
            return f"{base2}.ocr.jpg", data
        except Exception:
            return f"{base}.ocr.jpg", norm_bytes
    return f"{base}.ocr.jpg", b""


# ==============================================================================
# MIGRACIONES DE BD
# ==============================================================================

STOCK_AREAS = [
    ('', 'Sin ubicar'),
    ('SIN_CLASIFICACION', 'Sin clasificación'),
    ('SECOS', 'Secos'),
    ('CONGELADOS', 'Congelados'),
    ('FRESCOS', 'Frescos'),
    ('LIMPIEZA', 'Limpieza'),
]


def normalize_stock_area(value: str) -> str:
    v = (value or '').strip().upper()
    allowed = {k for k, _ in STOCK_AREAS if k}
    return v if v in allowed else ''


def stock_area_label(value: str) -> str:
    key = normalize_stock_area(value)
    labels = dict(STOCK_AREAS)
    return labels.get(key, labels.get('', 'Sin ubicar'))


def ensure_columns(cur):

    cur.execute("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        role TEXT NOT NULL DEFAULT 'OPERATIVO',
        center_id INTEGER NOT NULL DEFAULT 0,
        is_active INTEGER NOT NULL DEFAULT 1,
        created_at TEXT NOT NULL DEFAULT (datetime('now'))
    )
    """)
    try:
        cur.execute("ALTER TABLE inventory_sessions ADD COLUMN responsible_user_id INTEGER NOT NULL DEFAULT 0")
    except Exception:
        pass
    try:
        cur.execute("ALTER TABLE inventory_sessions ADD COLUMN responsible_name TEXT DEFAULT ''")
    except Exception:
        pass
    try:
        cur.execute("ALTER TABLE orders ADD COLUMN responsible_user_id INTEGER NOT NULL DEFAULT 0")
    except Exception:
        pass
    try:
        cur.execute("ALTER TABLE orders ADD COLUMN responsible_name TEXT DEFAULT ''")
    except Exception:
        pass
    try:
        count_users = cur.execute("SELECT COUNT(*) FROM users").fetchone()[0]
    except Exception:
        count_users = 0
    if not count_users:
        cur.execute("INSERT INTO users(name,role,center_id,is_active) VALUES('ADMIN GENERAL','ADMIN',0,1)")
    cols_items = {r["name"] for r in cur.execute("PRAGMA table_info(items)").fetchall()}
    for col, defn in [("max_qty", "REAL NOT NULL DEFAULT 0"),
                      ("current_price", "REAL NOT NULL DEFAULT 0"),
                      ("waste_default_pct", "REAL NOT NULL DEFAULT 0"),
                      ("stock_area", "TEXT NOT NULL DEFAULT ''")]:
        if col not in cols_items:
            try:
                cur.execute(f"ALTER TABLE items ADD COLUMN {col} {defn}")
            except Exception:
                pass
    cols_sup = {r["name"] for r in cur.execute("PRAGMA table_info(suppliers)").fetchall()}
    for col, defn in [("tax_id", "TEXT"), ("address", "TEXT"),
                      ("is_active", "INTEGER NOT NULL DEFAULT 1"),
                      ("created_at", "TEXT")]:
        if col not in cols_sup:
            try:
                cur.execute(f"ALTER TABLE suppliers ADD COLUMN {col} {defn}")
            except Exception:
                pass
    cols_rec = {r["name"] for r in cur.execute("PRAGMA table_info(recipes)").fetchall()}
    for col, defn in [("is_subrecipe", "INTEGER NOT NULL DEFAULT 0"),
                      ("cost_supplier_id", "INTEGER"),
                      ("scope_global", "INTEGER NOT NULL DEFAULT 1"),
                      ("scope_centers", "TEXT NOT NULL DEFAULT ''"),
                      ("yield_portions", "REAL NOT NULL DEFAULT 1"),
                      ("yield_final_qty", "REAL NOT NULL DEFAULT 0"),
                      ("yield_final_unit", "TEXT NOT NULL DEFAULT 'g'"),
                      ("is_active", "INTEGER NOT NULL DEFAULT 1"),
                      ("recipe_photo_path", "TEXT")]:
        if col not in cols_rec:
            try:
                cur.execute(f"ALTER TABLE recipes ADD COLUMN {col} {defn}")
            except Exception:
                pass
    cols_ocr = {r["name"] for r in cur.execute("PRAGMA table_info(receipt_ocr_runs)").fetchall()}
    for col, defn in [("supplier_name", "TEXT"), ("date_text", "TEXT"), ("line_count", "INTEGER DEFAULT 0"),
                      ("supplier_phone_raw", "TEXT"), ("supplier_email_raw", "TEXT"),
                      ("supplier_tax_id_raw", "TEXT"), ("supplier_address_raw", "TEXT")]:
        if col not in cols_ocr:
            try:
                cur.execute(f"ALTER TABLE receipt_ocr_runs ADD COLUMN {col} {defn}")
            except Exception:
                pass
    cols_ing = {r["name"] for r in cur.execute("PRAGMA table_info(recipe_ingredients)").fetchall()}
    for col, defn in [("input_unit", "TEXT"), ("waste_pct_ing", "REAL NOT NULL DEFAULT 0"),
                      ("subrecipe_id", "INTEGER")]:
        if col not in cols_ing:
            try:
                cur.execute(f"ALTER TABLE recipe_ingredients ADD COLUMN {col} {defn}")
            except Exception:
                pass

    cur.execute("""CREATE TABLE IF NOT EXISTS inventory_sessions(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      center_id INTEGER NOT NULL DEFAULT 0,
      warehouse_id INTEGER NOT NULL DEFAULT 0,
      session_type TEXT NOT NULL DEFAULT 'MIXTO',
      status TEXT NOT NULL DEFAULT 'DRAFT',
      created_at TEXT NOT NULL,
      note TEXT
    )""")
    cur.execute("""CREATE TABLE IF NOT EXISTS inventory_counts(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      session_id INTEGER NOT NULL,
      source_type TEXT NOT NULL DEFAULT 'raw',
      item_id INTEGER NOT NULL DEFAULT 0,
      item_name TEXT,
      family_key TEXT NOT NULL DEFAULT '',
      warehouse_id INTEGER NOT NULL DEFAULT 0,
      theoretical_qty REAL NOT NULL DEFAULT 0,
      physical_qty REAL NOT NULL DEFAULT 0,
      count_unit TEXT NOT NULL DEFAULT 'ud',
      is_checked INTEGER NOT NULL DEFAULT 0,
      note TEXT,
      unit_cost_snapshot REAL NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(session_id) REFERENCES inventory_sessions(id)
    )""")

    # productions.production_group (v8.7.198)
    cols_prod = {r["name"] for r in cur.execute("PRAGMA table_info(productions)").fetchall()} if cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='productions'").fetchone() else set()
    if "production_group" not in cols_prod:
        try:
            cur.execute("ALTER TABLE productions ADD COLUMN production_group TEXT NOT NULL DEFAULT 'Otros'")
        except Exception:
            pass


def ensure_items_columns(cur):
    cols = {r["name"] for r in cur.execute("PRAGMA table_info(items)").fetchall()}
    for col, defn in [("waste_default_pct", "REAL NOT NULL DEFAULT 0"),
                      ("current_price", "REAL NOT NULL DEFAULT 0"),
                      ("stock_area", "TEXT NOT NULL DEFAULT ''")]:
        if col not in cols:
            try:
                cur.execute(f"ALTER TABLE items ADD COLUMN {col} {defn}")
            except Exception:
                pass


def merge_duplicate_items(cur):
    rows = cur.execute("SELECT id,name,unit,min_qty,max_qty,current_price FROM items ORDER BY id").fetchall()
    groups = {}
    for r in rows:
        key = (_item_key(r["name"]), (r["unit"] or "").strip())
        groups.setdefault(key, []).append(r)
    for key, grp in groups.items():
        if len(grp) <= 1:
            continue
        canon = grp[0]
        dup_ids = [int(r["id"]) for r in grp[1:]]
        best_price = max([float(canon["current_price"] or 0)] + [float(r["current_price"] or 0) for r in grp[1:]])
        best_min = max([float(canon["min_qty"] or 0)] + [float(r["min_qty"] or 0) for r in grp[1:]])
        best_max = max([float(canon["max_qty"] or 0)] + [float(r["max_qty"] or 0) for r in grp[1:]])
        cur.execute("UPDATE items SET current_price=?, min_qty=?, max_qty=? WHERE id=?",
                    (best_price, best_min, best_max, int(canon["id"])))
        for t in ("movements", "supplier_item_prices", "order_lines", "receipt_lines"):
            cur.execute(f"UPDATE {t} SET item_id=? WHERE item_id IN ({','.join('?'*len(dup_ids))})",
                        [int(canon["id"]), *dup_ids])
        cur.execute(f"DELETE FROM items WHERE id IN ({','.join('?'*len(dup_ids))})", dup_ids)


def merge_exact_duplicate_items(cur):
    merge_duplicate_items(cur)


# ==============================================================================
# SEMILLAS (SEED)
# ==============================================================================

def _seed_load_items():
    if not SEED_ITEMS_CSV.exists():
        return []
    rows = []
    with SEED_ITEMS_CSV.open("r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for r in reader:
            name = (r.get("item_name") or "").strip()
            unit = (r.get("base_unit") or "").strip() or "g"
            if name:
                rows.append((name, unit, 0.0, 0.0))
    return rows


def _seed_load_prices():
    if not SEED_PRICES_CSV.exists():
        return []
    rows = []
    with SEED_PRICES_CSV.open("r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for r in reader:
            item_name = (r.get("item_name") or "").strip()
            base_unit = (r.get("base_unit") or "").strip()
            ref_unit = (r.get("ref_unit") or "").strip()
            try:
                ref_price = float(r.get("ref_price"))
            except Exception:
                continue
            if not item_name or ref_price < 0:
                continue
            factor = 1.0
            if ref_unit == "kg" and base_unit == "g":
                factor = 1000.0
            elif ref_unit == "l" and base_unit == "ml":
                factor = 1000.0
            rows.append((item_name, ref_price, ref_unit, factor))
    return rows


# ==============================================================================
# INIT DB
# ==============================================================================



def _classify_stock_area_from_name(name: str) -> str:
    n = _norm_text(name or '')
    if not n:
        return ''
    cleaning = ['lejia','desengrasante','detergente','lavavajillas','guantes','bolsas basura','bolsa basura','film transparente','papel aluminio','papel horno','caja take away','take away','nitrilo']
    frozen = ['congelado','congelada','precocido congelado','helado']
    fresh = [
        'tomate','lechuga','cebolla','ceboll','pimiento','pepino','cilantro','jalapeno','espinaca','zanahoria','patata','papa','berenjena','calabacin','aguacate','brocoli','col','repollo','hierba','menta','albahaca','cebollino','seta','champi','ajo','perejil','lima','limon','manzana','naranja','jengibre',
        'pollo','ternera','vacuno','cerdo','solomillo','costilla','hamburg','secreto','presa','carrillera','chuleta','entrecot','cordero','bacon','panceta','jamon','chorizo','morcilla','carne picada','huesos de pollo','huesos de ternera',
        'lubina','merluza','atun','salmon','bacalao','pescado','sepia','calamar','langost','gamba','pulpo','mejillon','marisco','dorada','almeja','anchoa',
        'huevo','huevos','leche','nata','queso','mantequilla','yogur','yogurt','mozzarella','parmesano','cheddar'
    ]
    dry = ['aceite','arroz','azucar','cacao','canela','clavo','comino','curry','curcuma','fideos','frijol','garbanzos','gelatina','harina','judia blanca','lentejas','levadura','maicena','maiz dulce','mostaza','nuez moscada','oregano','pan rallado','panko','pan precocido','pasta seca','sal','salsa soja','vinagre','wasabi','aceituna','alcaparras','algas nori','brandy cocina','cerveza para cocinar','caldo stock liquido','fondo blanco','fondo oscuro','demi glace','ketchup','mayonesa','jarabe de arce']
    for k in cleaning:
        if k in n:
            return 'LIMPIEZA'
    for k in frozen:
        if k in n:
            return 'CONGELADOS'
    for k in fresh:
        if k in n:
            return 'FRESCOS'
    for k in dry:
        if k in n:
            return 'SECOS'
    return ''


def _autoclassify_item_stock_areas(cur):
    rows = cur.execute("SELECT id,name,COALESCE(stock_area,'') stock_area FROM items ORDER BY id").fetchall()
    updates = []
    for r in rows:
        current = normalize_stock_area(r['stock_area'] or '')
        suggested = _classify_stock_area_from_name(r['name'] or '')
        # Nueva regla operativa: si un artículo no está clasificado, no se fuerza a FRESCOS.
        # Debe quedar en SIN_CLASIFICACION para revisión posterior.
        if not current:
            if suggested == 'FRESCOS' or not suggested:
                updates.append(('SIN_CLASIFICACION', int(r['id'])))
            else:
                updates.append((suggested, int(r['id'])))
            continue
    if updates:
        cur.executemany("UPDATE items SET stock_area=? WHERE id=?", updates)


def init_db():
    conn = db()
    cur = conn.cursor()
    cur.executescript("""
    CREATE TABLE IF NOT EXISTS centers(
      id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL,
      kind TEXT NOT NULL DEFAULT 'RESTAURANT');
    CREATE TABLE IF NOT EXISTS warehouses(
      id INTEGER PRIMARY KEY AUTOINCREMENT, center_id INTEGER NOT NULL,
      name TEXT NOT NULL, FOREIGN KEY(center_id) REFERENCES centers(id));
    CREATE TABLE IF NOT EXISTS items(
      id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, unit TEXT NOT NULL,
      min_qty REAL NOT NULL DEFAULT 0, max_qty REAL NOT NULL DEFAULT 0,
      current_price REAL NOT NULL DEFAULT 0, waste_default_pct REAL NOT NULL DEFAULT 0,
      stock_area TEXT NOT NULL DEFAULT '');
    CREATE TABLE IF NOT EXISTS suppliers(
      id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL,
      phone TEXT, email TEXT, is_active INTEGER NOT NULL DEFAULT 1);
    CREATE TABLE IF NOT EXISTS supplier_item_prices(
      id INTEGER PRIMARY KEY AUTOINCREMENT, supplier_id INTEGER NOT NULL,
      item_id INTEGER NOT NULL, center_id INTEGER,
      price_per_purchase REAL NOT NULL, purchase_unit TEXT NOT NULL,
      purchase_to_base_factor REAL NOT NULL, is_preferred INTEGER NOT NULL DEFAULT 0,
      updated_at TEXT NOT NULL,
      FOREIGN KEY(supplier_id) REFERENCES suppliers(id),
      FOREIGN KEY(item_id) REFERENCES items(id));
    CREATE TABLE IF NOT EXISTS movements(
      id INTEGER PRIMARY KEY AUTOINCREMENT, movement_type TEXT NOT NULL,
      item_id INTEGER NOT NULL, center_id INTEGER NOT NULL, warehouse_id INTEGER NOT NULL,
      qty REAL NOT NULL, unit TEXT NOT NULL, note TEXT, created_at TEXT NOT NULL,
      FOREIGN KEY(item_id) REFERENCES items(id));
    CREATE TABLE IF NOT EXISTS item_location_prefs(
      id INTEGER PRIMARY KEY AUTOINCREMENT, center_id INTEGER NOT NULL,
      warehouse_id INTEGER NOT NULL, item_id INTEGER NOT NULL,
      min_qty REAL NOT NULL DEFAULT 0, max_qty REAL NOT NULL DEFAULT 0,
      UNIQUE(center_id, warehouse_id, item_id));
    CREATE TABLE IF NOT EXISTS recipes(
      id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT NOT NULL, name TEXT NOT NULL,
      category TEXT, subcategory TEXT, cost_supplier_id INTEGER,
      waste_pct REAL NOT NULL DEFAULT 0, yield_portions REAL NOT NULL DEFAULT 1,
      yield_final_qty REAL NOT NULL DEFAULT 0, yield_final_unit TEXT NOT NULL DEFAULT 'g',
      contingency_pct REAL NOT NULL DEFAULT 0, target_food_cost_pct REAL NOT NULL DEFAULT 30,
      target_margin_pct REAL NOT NULL DEFAULT 70, manual_price REAL NOT NULL DEFAULT 0,
      suggested_price REAL NOT NULL DEFAULT 0, prep_steps TEXT, allergens TEXT,
      is_subrecipe INTEGER NOT NULL DEFAULT 0, recipe_photo_path TEXT);
    CREATE TABLE IF NOT EXISTS recipe_ingredients(
      id INTEGER PRIMARY KEY AUTOINCREMENT, recipe_id INTEGER NOT NULL,
      item_name TEXT NOT NULL, qty_gross REAL NOT NULL, qty_net REAL NOT NULL,
      unit TEXT NOT NULL, item_id INTEGER, input_unit TEXT,
      waste_pct_ing REAL NOT NULL DEFAULT 0, subrecipe_id INTEGER,
      FOREIGN KEY(recipe_id) REFERENCES recipes(id));
    CREATE TABLE IF NOT EXISTS productions(
      id INTEGER PRIMARY KEY AUTOINCREMENT, center_id INTEGER NOT NULL,
      warehouse_id INTEGER NOT NULL, status TEXT NOT NULL DEFAULT 'DRAFT',
      created_at TEXT NOT NULL, note TEXT);
    CREATE TABLE IF NOT EXISTS production_lines(
      id INTEGER PRIMARY KEY AUTOINCREMENT, production_id INTEGER NOT NULL,
      line_type TEXT NOT NULL, item_id INTEGER NOT NULL, qty_base REAL NOT NULL,
      input_unit TEXT NOT NULL, qty_input REAL NOT NULL,
      FOREIGN KEY(production_id) REFERENCES productions(id));
    CREATE TABLE IF NOT EXISTS orders(
      id INTEGER PRIMARY KEY AUTOINCREMENT, center_id INTEGER NOT NULL,
      status TEXT NOT NULL DEFAULT 'DRAFT', created_at TEXT NOT NULL, note TEXT);
    CREATE TABLE IF NOT EXISTS inventory_sessions(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      center_id INTEGER NOT NULL DEFAULT 0,
      warehouse_id INTEGER NOT NULL DEFAULT 0,
      session_type TEXT NOT NULL DEFAULT 'MIXTO',
      status TEXT NOT NULL DEFAULT 'DRAFT',
      created_at TEXT NOT NULL,
      note TEXT);
    CREATE TABLE IF NOT EXISTS inventory_counts(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      session_id INTEGER NOT NULL,
      source_type TEXT NOT NULL DEFAULT 'raw',
      item_id INTEGER NOT NULL DEFAULT 0,
      item_name TEXT,
      family_key TEXT NOT NULL DEFAULT '',
      warehouse_id INTEGER NOT NULL DEFAULT 0,
      theoretical_qty REAL NOT NULL DEFAULT 0,
      physical_qty REAL NOT NULL DEFAULT 0,
      count_unit TEXT NOT NULL DEFAULT 'ud',
      is_checked INTEGER NOT NULL DEFAULT 0,
      note TEXT,
      unit_cost_snapshot REAL NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(session_id) REFERENCES inventory_sessions(id));
    CREATE TABLE IF NOT EXISTS order_lines(
      id INTEGER PRIMARY KEY AUTOINCREMENT, order_id INTEGER NOT NULL,
      warehouse_id INTEGER NOT NULL, item_id INTEGER NOT NULL,
      qty_base REAL NOT NULL, input_unit TEXT NOT NULL, qty_input REAL NOT NULL,
      supplier_id INTEGER,
      FOREIGN KEY(order_id) REFERENCES orders(id));
    CREATE TABLE IF NOT EXISTS receipts(
      id INTEGER PRIMARY KEY AUTOINCREMENT, center_id INTEGER NOT NULL,
      warehouse_id INTEGER NOT NULL, supplier_id INTEGER NOT NULL,
      status TEXT NOT NULL DEFAULT 'PENDING', doc_number TEXT, doc_date TEXT,
      note TEXT, created_at TEXT NOT NULL, validated_at TEXT);
    CREATE TABLE IF NOT EXISTS receipt_lines(
      id INTEGER PRIMARY KEY AUTOINCREMENT, receipt_id INTEGER NOT NULL,
      item_id INTEGER NOT NULL, qty_input REAL NOT NULL, input_unit TEXT NOT NULL,
      factor REAL NOT NULL, qty_base REAL NOT NULL, price_unit REAL, line_total REAL,
      FOREIGN KEY(receipt_id) REFERENCES receipts(id));
    CREATE TABLE IF NOT EXISTS receipt_photos(
      id INTEGER PRIMARY KEY AUTOINCREMENT, receipt_id INTEGER NOT NULL,
      file_path TEXT NOT NULL, created_at TEXT NOT NULL,
      FOREIGN KEY(receipt_id) REFERENCES receipts(id));
    CREATE TABLE IF NOT EXISTS receipt_ocr_runs(
      id INTEGER PRIMARY KEY AUTOINCREMENT, receipt_id INTEGER NOT NULL,
      status TEXT NOT NULL DEFAULT 'PENDING', supplier_raw TEXT,
      doc_number_raw TEXT, doc_date_raw TEXT, supplier_phone_raw TEXT,
      supplier_email_raw TEXT, supplier_tax_id_raw TEXT, supplier_address_raw TEXT,
      summary TEXT, created_at TEXT NOT NULL,
      FOREIGN KEY(receipt_id) REFERENCES receipts(id));
    CREATE TABLE IF NOT EXISTS receipt_ocr_lines(
      id INTEGER PRIMARY KEY AUTOINCREMENT, ocr_run_id INTEGER NOT NULL,
      source_text TEXT, item_name_raw TEXT, qty_raw TEXT, unit_raw TEXT,
      price_raw TEXT, amount_raw TEXT, discount_raw TEXT, vat_raw TEXT,
      qty_basis_raw TEXT, qty_aux_raw TEXT, matched_item_id INTEGER,
      matched_item_name TEXT, review_status TEXT NOT NULL DEFAULT 'PENDING',
      created_at TEXT NOT NULL,
      FOREIGN KEY(ocr_run_id) REFERENCES receipt_ocr_runs(id));
    """)
    ensure_columns(cur)
    ensure_items_columns(cur)

    # Datos iniciales
    if cur.execute("SELECT COUNT(*) c FROM centers").fetchone()["c"] == 0:
        centers = [("Restaurante Centro", "RESTAURANT"), ("Restaurante Norte", "RESTAURANT"),
                   ("Restaurante Sur", "RESTAURANT"), ("Restaurante Playa", "RESTAURANT"),
                   ("Restaurante Barrio", "RESTAURANT"), ("Restaurante Premium", "RESTAURANT"),
                   ("Cocina Central", "CENTRAL_KITCHEN")]
        cur.executemany("INSERT INTO centers(name,kind) VALUES(?,?)", centers)
        for ce in cur.execute("SELECT id FROM centers").fetchall():
            for wh in ["Cocina", "Economato", "Cámara"]:
                cur.execute("INSERT INTO warehouses(center_id,name) VALUES(?,?)", (ce["id"], wh))

    try:
        cur.execute("UPDATE warehouses SET name='Cámara' WHERE name LIKE 'CÃ%'")
    except Exception:
        pass

    if cur.execute("SELECT COUNT(*) c FROM items").fetchone()["c"] == 0:
        seed_items = _seed_load_items()
        if seed_items:
            cur.executemany("INSERT INTO items(name,unit,min_qty,max_qty) VALUES(?,?,?,?)", seed_items)
        else:
            cur.executemany("INSERT INTO items(name,unit,min_qty,max_qty) VALUES(?,?,?,?)", [
                ("Solomillo", "g", 0, 0), ("Patata", "g", 0, 0),
                ("Aceite de oliva", "ml", 0, 0), ("Sal", "g", 0, 0), ("Mantequilla", "g", 0, 0)])

    merge_exact_duplicate_items(cur)

    if cur.execute("SELECT COUNT(*) c FROM suppliers").fetchone()["c"] == 0:
        cur.executemany("INSERT INTO suppliers(name,phone,email) VALUES(?,?,?)", [
            ("Referencia Mercasa (Madrid)", None, None),
            ("Proveedor A", "900111111", "a@proveedor.com"),
            ("Proveedor B", "900222222", "b@proveedor.com")])

    sid_row = cur.execute("SELECT id FROM suppliers WHERE name='Referencia Mercasa (Madrid)'").fetchone()
    if sid_row and cur.execute("SELECT COUNT(*) c FROM supplier_item_prices").fetchone()["c"] == 0:
        now = datetime.utcnow().isoformat()
        for (item_name, price_per_purchase, purchase_unit, factor) in _seed_load_prices():
            row = cur.execute("SELECT id FROM items WHERE name=?", (item_name,)).fetchone()
            if not row:
                continue
            cur.execute(
                """INSERT INTO supplier_item_prices(supplier_id,item_id,center_id,price_per_purchase,
                   purchase_unit,purchase_to_base_factor,is_preferred,updated_at) VALUES(?,?,?,?,?,?,?,?)""",
                (sid_row["id"], row["id"], None, float(price_per_purchase), purchase_unit, float(factor), 1, now))

    merge_duplicate_items(cur)
    _autoclassify_item_stock_areas(cur)

    if cur.execute("SELECT COUNT(*) c FROM recipes").fetchone()["c"] == 0:
        cur.execute(
            """INSERT INTO recipes(code,name,category,subcategory,waste_pct,contingency_pct,
               target_food_cost_pct,target_margin_pct,manual_price,suggested_price,prep_steps,allergens)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
            ("REC-PRI-0001", "Solomillo a la plancha", "Principales", "Carne", 12, 5, 30, 70, 19.5, 20.0,
             "1. Porcionar.\n2. Salpimentar.\n3. Sellar.\n4. Mantequilla.\n5. Emplatar.", "Leche"))
        r1 = cur.lastrowid
        cur.executemany(
            "INSERT INTO recipe_ingredients(recipe_id,item_name,qty_gross,qty_net,unit) VALUES (?,?,?,?,?)",
            [(r1, "Solomillo", 220, 200, "g"), (r1, "Sal", 2, 2, "g"), (r1, "Mantequilla", 10, 10, "g")])

    conn.commit()
    conn.close()


def _clear_pending_receipts_runtime():
    conn = db()
    cur = conn.cursor()
    rows = cur.execute("SELECT id FROM receipts WHERE status='PENDING' ORDER BY id").fetchall()
    for r in rows:
        rid = int(r["id"])
        try:
            ph_rows = cur.execute("SELECT file_path FROM receipt_photos WHERE receipt_id=?", (rid,)).fetchall()
            for ph in ph_rows:
                try:
                    fp = UPLOADS_DIR / ph["file_path"]
                    if fp.exists():
                        fp.unlink()
                except Exception:
                    pass
            cur.execute("DELETE FROM receipt_ocr_lines WHERE ocr_run_id IN (SELECT id FROM receipt_ocr_runs WHERE receipt_id=?)", (rid,))
            cur.execute("DELETE FROM receipt_ocr_runs WHERE receipt_id=?", (rid,))
            cur.execute("DELETE FROM receipt_lines WHERE receipt_id=?", (rid,))
            cur.execute("DELETE FROM receipt_photos WHERE receipt_id=?", (rid,))
            cur.execute("DELETE FROM receipts WHERE id=? AND status='PENDING'", (rid,))
        except Exception:
            pass
    conn.commit()
    conn.close()


# ==============================================================================
# ELABORADOS — Stock de artículos producidos con info de porciones y receta
# ==============================================================================

def get_elaborados_stock(center_id=None):
    """
    Devuelve artículos que tienen stock originado en producciones confirmadas,
    con porciones calculadas automáticamente desde la receta asociada.

    Lógica:
    - Busca items cuyo stock acumulado en movements tiene al menos un movimiento
      con nota que empieza por "PRODUCCIÓN"
    - Cruza con production_lines (line_type=IN) para obtener la producción origen
    - Busca la receta cuyo nombre coincide con el item para obtener yield_portions
      y yield_final_qty (gramaje/porciones por lote)
    - Calcula porciones = stock_qty / (yield_final_qty / yield_portions)
    """
    conn = db()
    cur = conn.cursor()

    center_clause = ""
    params = []
    if center_id:
        center_clause = "AND m.center_id = ?"
        params.append(int(center_id))

    # Artículos con stock de producción + info de la última producción que los generó
    sql = f"""
    SELECT
        i.id         item_id,
        i.name       item_name,
        i.unit       unit,
        c.id         center_id,
        c.name       center_name,
        w.id         warehouse_id,
        w.name       warehouse_name,
        COALESCE(SUM(CASE
            WHEN m.movement_type IN ('ENTRADA','IN')  THEN m.qty
            WHEN m.movement_type IN ('SALIDA','OUT')  THEN -m.qty
            ELSE -m.qty
        END), 0)     stock_qty,
        -- Última producción que generó este artículo
        (SELECT p2.id
           FROM productions p2
           JOIN production_lines pl2 ON pl2.production_id = p2.id
          WHERE pl2.item_id = i.id
            AND pl2.line_type = 'IN'
            AND p2.status IN ('CONFIRMED','ARCHIVED')
            {('AND p2.center_id = ?' if center_id else '')}
          ORDER BY p2.id DESC LIMIT 1
        ) last_prod_id,
        (SELECT p2.created_at
           FROM productions p2
           JOIN production_lines pl2 ON pl2.production_id = p2.id
          WHERE pl2.item_id = i.id
            AND pl2.line_type = 'IN'
            AND p2.status IN ('CONFIRMED','ARCHIVED')
            {('AND p2.center_id = ?' if center_id else '')}
          ORDER BY p2.id DESC LIMIT 1
        ) last_prod_at,
        (SELECT p2.note
           FROM productions p2
           JOIN production_lines pl2 ON pl2.production_id = p2.id
          WHERE pl2.item_id = i.id
            AND pl2.line_type = 'IN'
            AND p2.status IN ('CONFIRMED','ARCHIVED')
            {('AND p2.center_id = ?' if center_id else '')}
          ORDER BY p2.id DESC LIMIT 1
        ) last_prod_note,
        -- Receta asociada (nombre = item)
        (SELECT r.id FROM recipes r
          WHERE lower(trim(r.name)) = lower(trim(i.name))
          ORDER BY r.id LIMIT 1
        ) recipe_id,
        (SELECT r.name FROM recipes r
          WHERE lower(trim(r.name)) = lower(trim(i.name))
          ORDER BY r.id LIMIT 1
        ) recipe_name,
        (SELECT r.yield_portions FROM recipes r
          WHERE lower(trim(r.name)) = lower(trim(i.name))
          ORDER BY r.id LIMIT 1
        ) yield_portions,
        (SELECT r.yield_final_qty FROM recipes r
          WHERE lower(trim(r.name)) = lower(trim(i.name))
          ORDER BY r.id LIMIT 1
        ) yield_final_qty,
        (SELECT r.yield_final_unit FROM recipes r
          WHERE lower(trim(r.name)) = lower(trim(i.name))
          ORDER BY r.id LIMIT 1
        ) yield_final_unit
    FROM items i
    JOIN (
        -- Solo items que tienen AL MENOS UN movimiento de producción
        SELECT DISTINCT item_id, center_id, warehouse_id
        FROM movements
        WHERE movement_type IN ('ENTRADA','IN')
          AND note LIKE 'PRODUCCIÓN%'
          {('AND center_id = ?' if center_id else '')}
    ) produced ON produced.item_id = i.id
    JOIN centers c ON c.id = produced.center_id
    JOIN warehouses w ON w.id = produced.warehouse_id
    LEFT JOIN movements m ON m.item_id = i.id
        AND m.center_id = produced.center_id
        AND m.warehouse_id = produced.warehouse_id
    WHERE 1=1
        {center_clause}
    GROUP BY i.id, i.name, i.unit, c.id, c.name, w.id, w.name
    HAVING stock_qty > 0
    ORDER BY c.name, i.name
    """

    # Construir params con los duplicados necesarios para los subqueries
    full_params = []
    if center_id:
        # produced subquery: 1 param
        full_params.append(int(center_id))
        # last_prod_id, last_prod_at, last_prod_note: 3 subqueries × 1 param cada uno
        full_params.extend([int(center_id)] * 3)
        # center_clause: 1 param
        full_params.append(int(center_id))
    
    rows = cur.execute(sql, full_params).fetchall()
    conn.close()

    result = []
    for r in rows:
        stock_qty    = float(r["stock_qty"] or 0)
        yield_qty    = float(r["yield_final_qty"] or 0)
        yield_port   = float(r["yield_portions"] or 0)

        # Calcular porciones: stock / (gramaje_por_porcion)
        # gramaje_por_porcion = yield_final_qty / yield_portions
        porciones = None
        gramaje_porcion = None
        if yield_qty > 0 and yield_port > 0:
            gramaje_porcion = yield_qty / yield_port
            if gramaje_porcion > 0:
                porciones = stock_qty / gramaje_porcion

        result.append({
            "item_id":        r["item_id"],
            "item_name":      r["item_name"],
            "unit":           r["unit"],
            "center_id":      r["center_id"],
            "center_name":    r["center_name"],
            "warehouse_id":   r["warehouse_id"],
            "warehouse_name": r["warehouse_name"],
            "stock_qty":      stock_qty,
            "last_prod_id":   r["last_prod_id"],
            "last_prod_at":   r["last_prod_at"],
            "last_prod_note": r["last_prod_note"],
            "recipe_id":      r["recipe_id"],
            "recipe_name":    r["recipe_name"],
            "yield_portions": yield_port,
            "yield_final_qty": yield_qty,
            "yield_final_unit": r["yield_final_unit"],
            "porciones":      porciones,
            "gramaje_porcion": gramaje_porcion,
        })

    return result


# ==============================================================================
# HELPERS DE ESCALADO DE PRODUCCIONES (v8.7.198)
# ==============================================================================

def _canonical_unit(unit: str) -> str:
    """Normaliza unidades a su forma canónica base."""
    u = (unit or "").strip().lower()
    if u in {"g", "kg", "gr", "gramo", "gramos", "ml", "l", "lt", "lts", "litro", "litros"}: return "g"
    if u in {"ud", "u", "unidad", "unidades"}: return "ud"
    if u in {"racion", "raciones"}: return "raciones"
    if u in {"porcion", "porciones"}: return "porciones"
    return u or "ud"


def _convert_qty(qty: float, from_unit: str, to_unit: str) -> float:
    """Convierte cantidad entre unidades usando _unit_factor."""
    try:
        return float(qty or 0.0) * float(_unit_factor(from_unit, to_unit))
    except Exception:
        return float(qty or 0.0)


def _resolve_recipe_id(cur, recipe_id, recipe_query: str):
    """Resuelve un recipe_id desde ID directo o texto de búsqueda."""
    try:
        if str(recipe_id or '').isdigit() and int(recipe_id) > 0:
            row = cur.execute("SELECT id FROM recipes WHERE id=?", (int(recipe_id),)).fetchone()
            if row:
                return int(row[0] if not hasattr(row, 'keys') else row['id'])
    except Exception:
        pass
    q = (recipe_query or '').strip()
    if not q:
        return None
    q_up = q.upper()
    row = cur.execute("SELECT id FROM recipes WHERE upper(trim(name))=? ORDER BY id LIMIT 1", (q_up,)).fetchone()
    if row:
        return int(row[0] if not hasattr(row, 'keys') else row['id'])
    row = cur.execute("SELECT id FROM recipes WHERE upper(trim(code))=? ORDER BY id LIMIT 1", (q_up,)).fetchone()
    if row:
        return int(row[0] if not hasattr(row, 'keys') else row['id'])
    if '·' in q_up:
        left = q_up.split('·', 1)[0].strip()
        row = cur.execute("SELECT id FROM recipes WHERE upper(trim(code))=? ORDER BY id LIMIT 1", (left,)).fetchone()
        if row:
            return int(row[0] if not hasattr(row, 'keys') else row['id'])
    row = cur.execute("SELECT id FROM recipes WHERE upper(name) LIKE ? ORDER BY id LIMIT 1", (q_up + '%',)).fetchone()
    if row:
        return int(row[0] if not hasattr(row, 'keys') else row['id'])
    return None


# ==============================================================================
# GET_PRODUCTION_STOCKS — v8.7.198 (versión mejorada de get_elaborados_stock)
# Muestra stock de artículos que son resultado de producciones confirmadas.
# No filtra por nota "PRODUCCIÓN%" — usa production_lines directamente.
# ==============================================================================

def get_production_stocks(cur, center_id=None):
    """
    Stock de artículos que son resultado (line_type=IN) de producciones confirmadas.
    Incluye datos de receta para calcular porciones automáticamente.
    """
    center_filter = ""
    params = []
    if center_id:
        center_filter = "WHERE c.id=?"
        params.append(int(center_id))

    sql = f"""
    SELECT c.id center_id,
           c.name center_name,
           w.id warehouse_id,
           w.name warehouse_name,
           i.id item_id,
           i.name item_name,
           i.unit,
           i.current_price,
           COALESCE(SUM(CASE
               WHEN m.movement_type IN ('ENTRADA','IN')  THEN m.qty
               WHEN m.movement_type IN ('SALIDA','OUT')  THEN -m.qty
               ELSE 0
           END), 0) stock_qty,
           -- Última producción que generó este artículo
           (SELECT p.id
              FROM productions p
              JOIN production_lines pl ON pl.production_id=p.id
             WHERE p.status='CONFIRMED'
               AND pl.line_type='IN'
               AND pl.item_id=i.id
               AND p.center_id=c.id
               AND p.warehouse_id=w.id
             ORDER BY p.id DESC LIMIT 1) last_prod_id,
           (SELECT p.created_at
              FROM productions p
              JOIN production_lines pl ON pl.production_id=p.id
             WHERE p.status='CONFIRMED'
               AND pl.line_type='IN'
               AND pl.item_id=i.id
               AND p.center_id=c.id
               AND p.warehouse_id=w.id
             ORDER BY p.id DESC LIMIT 1) last_production_at,
           (SELECT p.note
              FROM productions p
              JOIN production_lines pl ON pl.production_id=p.id
             WHERE p.status='CONFIRMED'
               AND pl.line_type='IN'
               AND pl.item_id=i.id
               AND p.center_id=c.id
               AND p.warehouse_id=w.id
             ORDER BY p.id DESC LIMIT 1) last_prod_note,
           -- Receta asociada por nombre (para calcular porciones)
           (SELECT r.id FROM recipes r
             WHERE lower(trim(r.name))=lower(trim(i.name))
             ORDER BY r.id LIMIT 1) recipe_id,
           (SELECT r.name FROM recipes r
             WHERE lower(trim(r.name))=lower(trim(i.name))
             ORDER BY r.id LIMIT 1) recipe_name,
           (SELECT r.yield_portions FROM recipes r
             WHERE lower(trim(r.name))=lower(trim(i.name))
             ORDER BY r.id LIMIT 1) yield_portions,
           (SELECT r.yield_final_qty FROM recipes r
             WHERE lower(trim(r.name))=lower(trim(i.name))
             ORDER BY r.id LIMIT 1) yield_final_qty,
           (SELECT r.yield_final_unit FROM recipes r
             WHERE lower(trim(r.name))=lower(trim(i.name))
             ORDER BY r.id LIMIT 1) yield_final_unit,
           (SELECT mm.created_at FROM movements mm
             WHERE mm.center_id=c.id AND mm.warehouse_id=w.id AND mm.item_id=i.id
             ORDER BY mm.id DESC LIMIT 1) last_move_at,
           (SELECT mm.note FROM movements mm
             WHERE mm.center_id=c.id AND mm.warehouse_id=w.id AND mm.item_id=i.id
             ORDER BY mm.id DESC LIMIT 1) last_move_note
      FROM centers c
      JOIN warehouses w ON w.center_id=c.id
      JOIN (
          SELECT DISTINCT item_id
            FROM production_lines
           WHERE line_type='IN'
      ) produced ON 1=1
      JOIN items i ON i.id=produced.item_id
      LEFT JOIN movements m ON m.center_id=c.id
                            AND m.warehouse_id=w.id
                            AND m.item_id=i.id
      {center_filter}
     GROUP BY c.id, c.name, w.id, w.name, i.id, i.name, i.unit, i.current_price
     HAVING ABS(COALESCE(SUM(CASE
               WHEN m.movement_type IN ('ENTRADA','IN')  THEN m.qty
               WHEN m.movement_type IN ('SALIDA','OUT')  THEN -m.qty
               ELSE 0 END), 0)) > 0.000001
     ORDER BY c.name, w.name, i.name
    """

    rows = cur.execute(sql, params).fetchall()
    payload = []
    for r in rows:
        try:
            raw_qty = float(r['stock_qty'] or 0)
            qty   = raw_qty if raw_qty > 0 else 0.0
            price = float(r['current_price'] or 0)
            value = qty * price if qty > 0 and price > 0 else 0.0

            # Calcular porciones según la unidad del artículo
            unit_low = str(r['unit'] or '').lower()
            if unit_low in {'ud', 'porcion', 'porciones', 'racion', 'raciones'}:
                # Si la unidad ya es porciones/ud, el stock ES las porciones
                porciones = round(qty, 1)
                gramaje_porcion = None
            else:
                # Calcular porciones desde receta: stock / (yield_final_qty / yield_portions)
                yf_qty  = float(r['yield_final_qty']  or 0)
                yf_port = float(r['yield_portions']   or 0)
                if yf_qty > 0 and yf_port > 0:
                    gramaje_base = yf_qty / yf_port  # qty base por porción
                    porciones = round(qty / gramaje_base, 1) if gramaje_base > 0 else None
                    gramaje_porcion = gramaje_base
                else:
                    porciones = None
                    gramaje_porcion = None

        except Exception:
            qty = 0.0; value = 0.0; porciones = None; gramaje_porcion = None

        if qty <= 0:
            continue

        d = dict(r)
        d['stock_qty']             = qty
        d['stock_value']           = round(value, 4)
        d['porciones_disponibles'] = porciones
        d['gramaje_porcion']       = gramaje_porcion if 'gramaje_porcion' in dir() else None
        payload.append(d)
    return payload


# ==============================================================================
# COLLECT PRODUCTION INPUTS — v8.7.198
# Recoge ingredientes de una receta para producción con escalado correcto
# ==============================================================================

def _resolve_item_for_production(cur, *, item_id=None, item_name=""):
    """Resuelve un artículo consumible de producción por ID o nombre."""
    try:
        iid = int(item_id or 0)
    except Exception:
        iid = 0
    if iid:
        row = cur.execute("SELECT id,unit,name FROM items WHERE id=?", (iid,)).fetchone()
        if row:
            return row
    qn = (item_name or "").strip().lower()
    if not qn:
        return None
    row = cur.execute("SELECT id,unit,name FROM items WHERE lower(trim(name))=? ORDER BY id LIMIT 1", (qn,)).fetchone()
    if row:
        return row
    row = cur.execute("SELECT id,unit,name FROM items WHERE lower(name) LIKE ? ORDER BY id LIMIT 1", (qn + '%',)).fetchone()
    return row


def _collect_recipe_production_inputs(cur, recipe_id: int, scale_factor: float = 1.0, depth: int = 0, visited=None):
    """
    Recoge las líneas de entrada (OUT) para producir una receta.
    Soporta subrecetas recursivas y escalado por raciones/kg/lotes.
    Retorna: (lines, pending_names)
    """
    visited = set(visited or set())
    recipe_id = int(recipe_id or 0)
    if recipe_id <= 0 or depth > 6 or recipe_id in visited:
        return [], []
    visited.add(recipe_id)

    rows = cur.execute(
        """SELECT item_id, subrecipe_id, qty_gross, qty_net, unit, input_unit, item_name, waste_pct_ing
               FROM recipe_ingredients
              WHERE recipe_id=?
              ORDER BY id""",
        (recipe_id,),
    ).fetchall()
    out = []
    pending = []

    for r in rows:
        gross_base = _production_required_gross(cur, r)
        qty_base = float(gross_base or 0.0) * float(scale_factor or 1.0)
        if qty_base <= 0:
            continue

        item = _resolve_item_for_production(cur, item_id=r["item_id"], item_name=r["item_name"] or "")
        if item:
            base_unit  = (item["unit"] or "ud").strip() or "ud"
            input_unit = (r["input_unit"] or r["unit"] or base_unit).strip() or base_unit
            source_unit = _canonical_unit(input_unit or r["unit"] or base_unit)
            try:
                qty_base_for_stock = float(_convert_qty(qty_base, source_unit, base_unit))
            except Exception:
                qty_base_for_stock = float(qty_base)
            try:
                qty_input = float(_convert_qty(qty_base, source_unit, input_unit))
            except Exception:
                qty_input = float(qty_base)
            out.append({
                "item_id":    int(item["id"]),
                "qty_base":   float(qty_base_for_stock),
                "input_unit": input_unit,
                "qty_input":  float(qty_input),
            })
            continue

        subrecipe_id = int(r["subrecipe_id"] or 0)
        if subrecipe_id > 0:
            sub = cur.execute(
                "SELECT id,name,yield_final_qty,yield_final_unit FROM recipes WHERE id=?",
                (subrecipe_id,),
            ).fetchone()
            # Primero intentar consumir el elaborado como artículo de stock
            if sub and (sub["name"] or "").strip():
                sub_item = _resolve_item_for_production(cur, item_name=(sub["name"] or "").strip())
                if sub_item:
                    base_unit  = (sub_item["unit"] or "ud").strip() or "ud"
                    input_unit = (r["input_unit"] or r["unit"] or sub.get("yield_final_unit") or base_unit).strip() or base_unit
                    source_unit = _canonical_unit(input_unit or r["unit"] or sub.get("yield_final_unit") or base_unit)
                    try:
                        qty_base_for_stock = float(_convert_qty(qty_base, source_unit, base_unit))
                    except Exception:
                        qty_base_for_stock = float(qty_base)
                    try:
                        qty_input = float(_convert_qty(qty_base, source_unit, input_unit))
                    except Exception:
                        qty_input = float(qty_base)
                    out.append({
                        "item_id":    int(sub_item["id"]),
                        "qty_base":   float(qty_base_for_stock),
                        "input_unit": input_unit,
                        "qty_input":  float(qty_input),
                    })
                    continue

            # Si no existe artículo, expandir subreceta recursivamente
            if sub and float(sub["yield_final_qty"] or 0.0) > 0 and (sub["yield_final_unit"] or "").strip():
                sub_unit = (sub["yield_final_unit"] or "").strip()
                sub_can  = _canonical_unit(sub_unit)
                try:
                    sub_yield_base = float(_convert_qty(float(sub["yield_final_qty"] or 0.0), sub_unit, sub_can))
                except Exception:
                    sub_yield_base = 0.0
                if sub_yield_base > 0:
                    child_scale = float(qty_base) / float(sub_yield_base)
                    child_lines, child_pending = _collect_recipe_production_inputs(
                        cur, int(subrecipe_id), child_scale, depth + 1, visited)
                    out.extend(child_lines)
                    pending.extend(child_pending)
                    continue

            pending.append((sub["name"] if sub and sub["name"] else r["item_name"] or "subreceta").strip())
            continue

        if (r["item_name"] or "").strip():
            pending.append((r["item_name"] or "").strip())

    return out, pending
